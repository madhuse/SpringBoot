### Relevant articles

- [Introduction to Flowable](http://www.baeldung.com/flowable)
