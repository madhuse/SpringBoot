package com.baeldung.service;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import org.flowable.engine.HistoryService;
import org.flowable.engine.RuntimeService;
import org.flowable.engine.TaskService;
import org.flowable.task.api.Task;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.baeldung.domain.Article;
import com.baeldung.domain.VisaDetails;

@Service
public class VisaProcessWorkFlowService {
	 @Autowired
	    private RuntimeService runtimeService;
	    @Autowired
	    private TaskService taskService;
	    @Autowired
	    protected HistoryService historyService;
	    
	    @Transactional
	    public void startProcess(VisaDetails visaDetails) {
	        Map<String, Object> variables = new HashMap<String, Object>();
	        variables.put("name", visaDetails.getName());
	        variables.put("email", visaDetails.getEmail());
	        variables.put("aadhar", visaDetails.getAadhar());
	        variables.put("mobile", visaDetails.getMobileNumber());
	        variables.put("address", visaDetails.getAddress());
	        runtimeService.startProcessInstanceByKey("process_1", variables);
	        System.out.println("User Details was submitted");
	    }
	    
	    @Transactional
	    public List<VisaDetails> getTasks(String assignee) {
	        List<Task> tasks = taskService.createTaskQuery()
	          .taskCandidateGroup(assignee)
	          .list();
	        System.out.println(tasks.size());
	        List<VisaDetails> articles = tasks.stream()
	          .map(task -> {
	              Map<String, Object> variables = taskService.getVariables(task.getId());
	              return new VisaDetails(
	                (String) variables.get("name"),(String) variables.get("email"),(Long) variables.get("aadhar"),(Long) variables.get("mobile"),(String) variables.get("address"));
	              
	          })
	          .collect(Collectors.toList());
	       
	        return articles;
	    }
}
