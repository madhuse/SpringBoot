package com.baeldung.service;


import org.flowable.engine.delegate.DelegateExecution;
import org.flowable.engine.delegate.JavaDelegate;


import com.baeldung.MailUtility;

public class PublishArticleService implements JavaDelegate {
	public void execute(DelegateExecution execution) {
		 String author = (String)execution.getVariable("email");
		 Object url = execution.getVariable("name");
	     System.out.println("Sending approved mail to the "+author+" for the user::"+url);

	   //public static void sendMail(String toAddresses, String ccAddresses, String bccAddresses, String fromAddress, String subject, String body, String type){
	        MailUtility.sendMail(author, "", "", "madhu.akula61@gmail.com", "Flowable application status", "your application processed successfully", "text/html");
    }
	

	/*@Override
	public void notify(DelegateTask delegateTask) {
		if(delegateTask.getAssignee() != null) {
            String assignee = delegateTask.getAssignee();
            Object author = delegateTask.getVariableLocal("author");
            Object url=delegateTask.getVariableLocal("url");
            
            System.out.println("Editor "+assignee+"::has approved the url"+url+"for the author"+author);
            
            
            //log.info("The assignee for task " + delegateTask.getId() + " is: " + assignee);
        }
		
	}*/
   /* public void execute(DelegateExecution execution) {
        System.out.println("Publishing the approved article.");
        String variable = (String)execution.getVariable("author");
        String variable1 = (String)execution.getVariable("url");
        System.out.println("author::"+variable);
        System.out.println("url::"+variable1);
        execution.setVariable("author", "author");
        execution.setActive(true);
    }*/
      // 
       
      	 //public String saveLeave(HttpServletRequest req,HttpServletResponse res) {
      		/*String subject="ArticleRequest";
      		String body="Article was published successfully";
      		
        
   		final String USER_NAME = "madhu.akula61@gmail.com"; 
   		final String PASSWORD = "7893696789"; 
           //String []subject= {subject1,fromdate,toDate};
   		String RECIPIENT="madhu.akula@otsi.co.in";
   		
   		String from = USER_NAME;
   		String pass = PASSWORD;
   		String[] to = { RECIPIENT }; 

   		 Properties props = System.getProperties();
   		 String host = "smtp.gmail.com";
           //  String host="otsimail.otsi-usa.com";
   		    props.put("mail.smtp.starttls.enable", "true");

   		    props.put("mail.smtp.ssl.trust", host);
   		    props.put("mail.smtp.user", from);
   		    props.put("mail.smtp.password", pass);
   		    props.put("mail.smtp.port", "587");
   		    props.put("mail.smtp.auth", "true");

               Session session = Session.getDefaultInstance(props);
   		    MimeMessage message = new MimeMessage(session);

   		    try {


   		        message.setFrom(new InternetAddress(from));
   		        InternetAddress[] toAddress = new InternetAddress[to.length];

   		        // To get the array of addresses
   		        for( int i = 0; i < to.length; i++ ) {
   		            toAddress[i] = new InternetAddress(to[i]);
   		        }

   		        for( int i = 0; i < toAddress.length; i++) {
   		            message.addRecipient(Message.RecipientType.TO, toAddress[i]);
   		        }

   		        message.setSubject(subject);
   		        message.setText(body);


   		        Transport transport = session.getTransport("smtp");


   		        transport.connect(host, from, pass);
   		        transport.sendMessage(message, message.getAllRecipients());
   		        transport.close();

   		    }
   		    catch (AddressException ae) {
   		        ae.printStackTrace();
   		    }
   		    catch (MessagingException me) {
   		        me.printStackTrace();
   		    }
   		 
   		
   		 }*/

    

}