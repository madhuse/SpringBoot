package com.baeldung.service;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import org.flowable.engine.FormService;
import org.flowable.engine.HistoryService;
import org.flowable.engine.IdentityService;
import org.flowable.engine.ManagementService;
import org.flowable.engine.ProcessEngine;
import org.flowable.engine.ProcessEngines;
import org.flowable.engine.RuntimeService;
import org.flowable.engine.TaskService;
import org.flowable.engine.form.FormProperty;
import org.flowable.engine.form.TaskFormData;
import org.flowable.engine.history.HistoricActivityInstance;
import org.flowable.engine.history.HistoricProcessInstance;
import org.flowable.engine.history.HistoricProcessInstanceQuery;
import org.flowable.engine.runtime.ProcessInstance;
import org.flowable.idm.api.Group;
import org.flowable.idm.api.User;
import org.flowable.rest.service.api.RestResponseFactory;
import org.flowable.task.api.Task;
import org.flowable.task.api.history.HistoricTaskInstance;
import org.flowable.task.api.history.HistoricTaskInstanceQuery;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;


import com.baeldung.domain.Approval;
import com.baeldung.domain.Article;
import com.baeldung.domain.Resubmit;

@Service
public class ArticleWorkflowService {
    @Autowired
    private RuntimeService runtimeService;
    @Autowired
    private TaskService taskService;
    @Autowired
    protected HistoryService historyService;

    @Autowired
    private IdentityService identityservice;
    ProcessInstance startProcessInstanceByKey=null;
    @Transactional
    
    public void startProcess(Article article) {
        Map<String, Object> variables = new HashMap<String, Object>();
        variables.put("name", article.getName());
        variables.put("email", article.getEmail());
        variables.put("mobile", article.getMobile());
        variables.put("aadhar", article.getAadhar());
        variables.put("remarks", article.getRemarks());
        
        startProcessInstanceByKey = runtimeService.startProcessInstanceByKey("test", variables);
        System.out.println("Process instances running = " + runtimeService.createProcessInstanceQuery().count());  
        System.out.println("Number of tasks : " + taskService.createTaskQuery().count());
        System.out.println("Number of tasks after process start: "
                + taskService.createTaskQuery().count());
        System.out.println("Article was submitted");
        System.out.println("process Instance Id"+startProcessInstanceByKey.getProcessInstanceId());
        System.out.println("process Defination Id"+startProcessInstanceByKey.getProcessDefinitionId());
        System.out.println("process Tenant Id"+startProcessInstanceByKey.getTenantId());
        
        
    }

    @Transactional
    public List<Article> getTasks(String assignee) {
        List<Task> tasks = taskService.createTaskQuery()
          .taskCandidateGroup(assignee)
          .list();
        System.out.println(tasks.size());
        List<Article> articles = tasks.stream()
          .map(task -> {
              Map<String, Object> variables = taskService.getVariables(task.getId());
              return new Article(
                task.getId(), (String) variables.get("name"), (String) variables.get("email"),(String) variables.get("mobile"),(String) variables.get("aadhar"),(String) variables.get("remarks"));
              
          })
          .collect(Collectors.toList());
       
        return articles;
    }

    
    
    @Transactional
    public void resubmit(Resubmit resubmit) {
    	 Map<String, Object> variables = new HashMap<String, Object>();
    	 variables.put("status", resubmit.getStatus());
    	 variables.put("name", resubmit.getName());
    	 variables.put("email", resubmit.getEmail());
    	 variables.put("mobile", resubmit.getMobile());
    	 variables.put("aadhar", resubmit.getAadhar());
    	 variables.put("remarks", resubmit.getRemarks());
    	 
    	 taskService.complete(resubmit.getId(), variables);
    }
    
    @Transactional
    public void submitReview(Approval approval) {
        Map<String, Object> variables = new HashMap<String, Object>();
        variables.put("status", approval.getStatus());
        variables.put("remarks", approval.getRemarks());
       // taskService.addComment(approval.getId(), processInstance.getId(), approval.getRemarks());
        taskService.complete(approval.getId(), variables);
        System.out.println("approved");
       // HistoryService historyService = processEngine.getHistoryService();
        HistoricProcessInstanceQuery desc = historyService.createHistoricProcessInstanceQuery()
  			  .finished().processDefinitionKey("test")
  			  .orderByProcessInstanceDuration().desc();
        
  			System.out.println("main query"+desc.count());
  			List<HistoricTaskInstance> taskquery=historyService.createHistoricTaskInstanceQuery().finished().processDefinitionKey("test").orderByHistoricTaskInstanceDuration().asc().list();
  			for(HistoricTaskInstance single:taskquery) {
  				System.out.println("task duration"+single.getDurationInMillis());
  				System.out.println("task creation time"+single.getCreateTime());
  				System.out.println("task ended time"+single.getEndTime());
  				System.out.println("task name"+single.getName());
  				System.out.println("task process variable"+single.getProcessVariables());
  				System.out.println("task local variable"+single.getTaskLocalVariables());
  				
  			}

  			
  			
  			/*List<HistoricActivityInstance> activityInstances = historyService
  				    .createHistoricActivityInstanceQuery()
  				    .processInstanceId(startProcessInstanceByKey.getProcessInstanceId())
  				    .orderByHistoricActivityInstanceStartTime().asc()
  				    .list();
  			for (HistoricActivityInstance activity : activityInstances) {
  			  System.out.println("id"+activity.getActivityId());
  			System.out.println("start time"+activity.getStartTime());
  			System.out.println("end time"+activity.getEndTime());
  			
  			   System.out.println("time"+activity.getDurationInMillis());
  			  }*/
		    }
    
    /*public void getHistory() {
    	List<HistoricActivityInstance> activities =
    			  historyService.createHistoricActivityInstanceQuery()
    			   .processInstanceId(processInstance.getId())
    			   .finished()
    			   .orderByHistoricActivityInstanceEndTime().asc()
    			   .list();

    			for (HistoricActivityInstance activity : activities) {
    			  System.out.println(activity.getActivityId() + " took "
    			    + activity.getDurationInMillis() + " milliseconds");
    			}
    			HistoricProcessInstanceQuery desc = historyService.createHistoricProcessInstanceQuery()
    			  .finished().processDefinitionKey("test")
    			  .orderByProcessInstanceDuration().desc();
    			System.out.println("task query"+desc.count());
    			HistoricTaskInstanceQuery taskquery=historyService.createHistoricTaskInstanceQuery().finished().processDefinitionKey("test").asc();
    			System.out.println("task query"+taskquery.count());
    			 List<HistoricProcessInstance> processInstances =
    				        historyService.createHistoricProcessInstanceQuery()
    				            .processDefinitionId(myProcessDefinition.getId())
    				           
    				            .finished() // we only want the finished process instances
    				            .list();

    }*/
    /*public void task2() {
    	org.flowable.task.api.TaskQuery createTaskQuery = taskService.createTaskQuery();
		Task task = createTaskQuery.singleResult();
		 Map<String, Object> vars = new HashMap<String, Object>();
		 vars.put("author", "madhu");
		 vars.put("url", "sekar");
	        taskService.newTask();
		taskService.setVariables(task.getId(), vars);
		
        // Set form key
        task = taskService.createTaskQuery().singleResult();
        Map<String, Object> variables = taskService.getVariables(task.getId());
        System.out.println(variables+"variables");
        taskService.setAssignee(task.getId(), "officer");
       // task.setFormKey("test123");
        taskService.saveTask(task);
        FormService.submitStartFormData("", variables);
        // Verify query and check form key
        task = taskService.createTaskQuery().includeProcessVariables().singleResult();
    	TaskFormData taskfo = formService.getTaskFormData(task.getId());
    	List<FormProperty> formProperties = formService.getTaskFormData(task.getId()).getFormProperties();
    	formProperties.
    }*/
        /*ProcessEngine processEngine = ProcessEngines.getDefaultProcessEngine();
        HistoryService historyService = processEngine.getHistoryService();
        TaskService taskService2 = processEngine.getTaskService();
        FormService formService = processEngine.getFormService();
        ManagementService managementService = processEngine.getManagementService();
        
        HistoricTaskInstanceQuery taskQuery = historyService.createHistoricTaskInstanceQuery().orderByProcessDefinitionId().asc();
        HistoricTaskInstance taskObject =  taskQuery.singleResult();
        System.out.println("taskObject.getDurationInMillis():"+taskObject.getDurationInMillis()); 
        System.out.println("taskObject.getName::"+taskObject.getName()); 
        System.out.println("Finished all tasks. Finished process instances = "
        	    + historyService.createHistoricProcessInstanceQuery().finished().count());*/
       /* HistoricTaskInstanceQuery taskQuery = historyService.createHistoricTaskInstanceQuery().taskId("reviewArticle");
        HistoricTaskInstance taskObject = taskQuery.singleResult();
       System.out.println("taskObject.getAssignee():"+ taskObject.getAssignee());
       System.out.println("taskObject.getDurationInMillis():"+taskObject.getDurationInMillis()); 
       System.out.println("taskObject.getName::"+taskObject.getName()); 
      */
public User createUser() {
	
	//System.out.println(taskQuery.count());
	User first=identityservice.newUser("sekar1885");
	first.setEmail("sekar@gmail.com");
	first.setFirstName("sekar");
	first.setLastName("akula");
	first.setPassword("12345");
	identityservice.saveUser(first);
	Group group=identityservice.newGroup("management-group");
	group.setName("management");
	identityservice.saveGroup(group);
	identityservice.createMembership(first.getId(), group.getId());
	return first;
	
}
        
    
}