package com.baeldung;
import java.util.List;

import org.flowable.dmn.api.DmnDeployment;
import org.flowable.dmn.api.DmnManagementService;
import org.flowable.dmn.api.DmnRepositoryService;
import org.flowable.dmn.api.DmnRuleService;
import org.flowable.dmn.engine.DmnEngine;
import org.flowable.dmn.engine.DmnEngineConfiguration;
import org.flowable.dmn.engine.DmnEngines;
import org.flowable.dmn.engine.impl.persistence.entity.DecisionTableEntity;
import org.flowable.dmn.engine.impl.persistence.entity.DmnDeploymentEntity;
import org.flowable.engine.ProcessEngineConfiguration;
import org.flowable.engine.impl.cfg.StandaloneProcessEngineConfiguration;

public class DMNEngine 
{
/*    public static void main( String[] args )
    {
    	DmnEngine dmnEngine1 = DmnEngineConfiguration.createStandaloneInMemDmnEngineConfiguration()
    			  .setDatabaseSchemaUpdate(DmnEngineConfiguration.DB_SCHEMA_UPDATE_FALSE)
    			  .setJdbcUrl("jdbc:h2:mem:my-own-db;DB_CLOSE_DELAY=1000")
    			  .buildDmnEngine();

    	DmnEngine dmnEngine = DmnEngines.getDefaultDmnEngine();
    	DmnRuleService dmnRuleService = dmnEngine.getDmnRuleService();
    	DmnRepositoryService dmnRepositoryService = dmnEngine.getDmnRepositoryService();
    	DmnManagementService dmnManagementService = dmnEngine.getDmnManagementService();
    	List<DmnDeployment> dmnDeployments = dmnRepositoryService.createDeploymentQuery()
    		    .deploymentNameLike("deployment%")
    		    
    		    .list();
    	long count = dmnRepositoryService.createNativeDeploymentQuery()
    		    .sql("SELECT count(*) FROM " + dmnManagementService.getTableName(DmnDeploymentEntity.class) + " D1, "
    		        + dmnManagementService.getTableName(DecisionTableEntity.class) + " D2 "
    		        + "WHERE D1.ID_ = D2.DEPLOYMENT_ID_ "
    		        + "AND D1.ID_ = #{deploymentId}")
    		    .parameter("deploymentId", deployment.getId())
    		    .count();
    	
}*/
    }