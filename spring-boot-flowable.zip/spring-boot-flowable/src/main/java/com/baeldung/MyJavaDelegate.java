package com.baeldung;

import org.flowable.cmmn.api.delegate.DelegatePlanItemInstance;
import org.flowable.cmmn.api.delegate.PlanItemJavaDelegate;

public class MyJavaDelegate implements PlanItemJavaDelegate {

    public void execute(DelegatePlanItemInstance planItemInstance) {
        String value = (String) planItemInstance.getVariable("someVariable");
       
    }

	

}