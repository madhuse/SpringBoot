package com.baeldung;

import java.io.IOException;
import java.io.InputStream;
import java.util.Map;
import java.util.Properties;

import javax.mail.Message;
import javax.mail.MessagingException;
import javax.mail.PasswordAuthentication;
import javax.mail.Session;
import javax.mail.Transport;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeMessage;

/**
 * 
 * @author samba siva
 */
public class MailUtility {
	
	public static void sendMail(String toAddresses, String ccAddresses, String bccAddresses, String fromAddress, String subject, String body, String type){
		
		
		final String username = "madhu.akula61@gmail.com";
		final String password ="7893696789";
		/*System.out.println(username+""+encodedPwd);
		byte[] actualByte = Base64.getDecoder() 
                .decode(encodedPwd); 

		String password = new String(actualByte); */
		fromAddress ="madhu.akula61@gmail.com";
		Properties props = null;
		Session session = null;
		Message message = null;
		try{		
			props = new Properties();
			 props.put("mail.smtp.host", "smtp.gmail.com");
			    props.put("mail.smtp.ssl.trust", "smtp.gmail.com");
			    props.put("mail.smtp.socketFactory.port", "465");
				 props.put("mail.smtp.socketFactory.class", "javax.net.ssl.SSLSocketFactory");
			    props.put("mail.smtp.starttls.enable", "true");
			    props.put("mail.smtp.socketFactory.class",
			            "javax.net.ssl.SSLSocketFactory");
			    props.put("mail.smtp.ssl.enable", "true");
			    props.put("mail.smtp.auth", "true");
			    props.put("mail.smtp.port", "465"); 
			
			session = Session.getInstance(props,
					  new javax.mail.Authenticator() {
						protected PasswordAuthentication getPasswordAuthentication() {
							return new PasswordAuthentication(username, password);
						}
					  });
			
			message = new MimeMessage(session);
			message.setFrom(new InternetAddress(fromAddress));
			message.setRecipients(Message.RecipientType.TO,	InternetAddress.parse(toAddresses));
			message.setRecipients(Message.RecipientType.CC,	InternetAddress.parse(ccAddresses));
			message.setRecipients(Message.RecipientType.BCC, InternetAddress.parse(bccAddresses));
			message.setSubject(subject);
			
			if(null!= type && type.equals("html"))
				message.setContent(body, "text/html");
			else
				message.setContent(body, "text/html");
			
			Transport.send(message); 			
		}catch (MessagingException mex) {
			mex.printStackTrace();
			//logger.error("Exception in sendMail " + mex);
			while (mex.getNextException() != null) {
				Exception ex = mex.getNextException();
				ex.printStackTrace();
				if (!(ex instanceof MessagingException)) break;
				else mex = (MessagingException)ex;
			}
		} catch(Exception e) {
			e.printStackTrace();
			//logger.error("Exception in sendMail " + e);
		}finally{
			props = null;session=null;message=null;
		}
	}	
	/*
	 * public static void main(String[] args) throws Exception { Properties props =
	 * new Properties(); props.put("mail.smtp.host", "smtp.gmail.com");
	 * props.put("mail.smtp.ssl.trust", "smtp.gmail.com");
	 * props.put("mail.smtp.socketFactory.port", "465");
	 * props.put("mail.smtp.socketFactory.class", "javax.net.ssl.SSLSocketFactory");
	 * props.put("mail.smtp.starttls.enable", "true");
	 * props.put("mail.smtp.socketFactory.class", "javax.net.ssl.SSLSocketFactory");
	 * props.put("mail.smtp.ssl.enable", "true"); props.put("mail.smtp.auth",
	 * "true"); props.put("mail.smtp.port", "465"); System.out.println("Sessison");
	 * Session session = Session.getDefaultInstance(props, new
	 * javax.mail.Authenticator() {
	 * 
	 * @Override protected PasswordAuthentication getPasswordAuthentication() {
	 * return new
	 * PasswordAuthentication("srinivas.kompella01@gmail.com","Srinivas0001"); } });
	 * 
	 * try { Message message = new MimeMessage(session); message.setFrom(new
	 * InternetAddress("srinivas.kompella01@gmail.com"));
	 * message.setRecipients(Message.RecipientType.TO,
	 * InternetAddress.parse("sudhanshu.gouda@otsi.co.in"));
	 * message.setSubject("Testing Subject"); message.setText("Test Mail");
	 * 
	 * Transport.send(message);
	 * 
	 * System.out.println("Done");
	 * 
	 * } catch (MessagingException e) { throw new RuntimeException(e); } }
	 */
	
	public Properties getProperties() {
		InputStream inputStream = getClass().getClassLoader().getResourceAsStream("application.properties");
		Properties prop = new Properties();
		if (inputStream != null) {
			try {
				prop.load(inputStream);
			} catch (IOException e) {
				e.printStackTrace();
			}
		}
		return prop;
	}
}

