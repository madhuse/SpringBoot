package com.baeldung.domain;

public class Resubmit {
	 private String id;
	 private String status;
	 private String name;
	 private String email;
	 private String mobile;
	 private String aadhar;
	 private String remarks;
	 public String getRemarks() {
	 	return remarks;
	 }
	 public void setRemarks(String remarks) {
	 	this.remarks=remarks;
	 }
	 public String getId() {
	        return id;
	    }

	    public void setId(String id) {
	        this.id = id;
	    }

	    public String getStatus() {
	        return status;
	    }

	    public void setStatus(String status) {
	        this.status = status;
	    }
	    public String getName() {
	        return name;
	    }

	    public void setName(String name) {
	        this.name = name;
	    }

	    public String getEmail() {
	        return email;
	    }

	    public void setEmail(String email) {
	        this.email = email;
	    }
	    public String getMobile() {
		return mobile;
	}
	      public void setMobile(String mobile) {
		  this.mobile = mobile;
	}
	      public void setAadhar(String aadhar) {
	    	  this.aadhar=aadhar;
	      }
	      public String getAadhar() {
	    	  return aadhar;
	    	  
	      }

}
