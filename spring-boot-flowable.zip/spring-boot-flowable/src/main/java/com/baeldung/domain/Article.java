package com.baeldung.domain;

public class Article {

    private String id;
    private String name;
    private String email;
    private String mobile;
    private String aadhar;
    private String remarks;

    public Article() {
    }

    public Article(String name, String email,String mobile,String aadhar,String remarks) {
        this.name = name;
        this.email = email;
        this.mobile = mobile;
        this.aadhar = aadhar;
        this.remarks=remarks;
    }

    public Article(String id, String name, String email,String mobile,String aadhar,String remarks) {
        this.id = id;
        this.name = name;
        this.email = email;
        this.mobile = mobile;
        this.aadhar = aadhar;
        this.remarks=remarks;
    }
    public String getRemarks() {
    	return remarks;
    }
    public void setRemarks(String remarks) {
    	this.remarks=remarks;
    }
      
    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }
    public String getMobile() {
	return mobile;
}
      public void setMobile(String mobile) {
	  this.mobile = mobile;
}
      public void setAadhar(String aadhar) {
    	  this.aadhar=aadhar;
      }
      public String getAadhar() {
    	  return aadhar;
    	  
      }
      
    @Override
    public String toString() {
        return ("[" + this.name + " " + this.email + "]");
    }

}
