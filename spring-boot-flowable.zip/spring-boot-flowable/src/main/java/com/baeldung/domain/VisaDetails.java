package com.baeldung.domain;

import org.springframework.web.multipart.MultipartFile;



import lombok.Data;
import lombok.Getter;
import lombok.Setter;

@Data
@Setter
@Getter
public class VisaDetails {
private String Name;
private String email;
private Long mobileNumber;
private Long aadhar;
private String address;
public VisaDetails(String name,String email,Long mobileNumber,Long aadhar,String address) {
}
}
