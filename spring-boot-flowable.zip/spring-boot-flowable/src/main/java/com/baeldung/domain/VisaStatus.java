package com.baeldung.domain;

import org.springframework.web.multipart.MultipartFile;



import lombok.Data;
import lombok.Getter;
import lombok.Setter;

@Data
@Setter
@Getter
public class VisaStatus {

}
