package com.baeldung;

public class JavaMail {
public static void main(String[] args) {
	MailUtility.sendMail("madhu.akula61@gmail.com", "", "", "madhu.akula61@gmail.com", "flowable", "hai", "text/html");
}
}
