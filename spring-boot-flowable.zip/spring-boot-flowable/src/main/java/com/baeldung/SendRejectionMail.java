package com.baeldung;

import org.flowable.engine.delegate.DelegateExecution;
import org.flowable.engine.delegate.JavaDelegate;

public class SendRejectionMail implements JavaDelegate{

	@Override
	public void execute(DelegateExecution execution) {
		System.out.println("your request has beem cancelled");
		 System.out.println("Calling the rejection mail to the employee "
		            + execution.getVariable("employee"));
		
	}

}
