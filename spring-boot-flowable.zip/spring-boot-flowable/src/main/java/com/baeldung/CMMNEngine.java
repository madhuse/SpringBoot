/*package com.baeldung;
import java.util.List;

import org.flowable.cmmn.api.CmmnHistoryService;
import org.flowable.cmmn.api.CmmnRepositoryService;
import org.flowable.cmmn.api.CmmnRuntimeService;
import org.flowable.cmmn.api.CmmnTaskService;
import org.flowable.cmmn.api.history.HistoricCaseInstance;
import org.flowable.cmmn.api.repository.CaseDefinition;
import org.flowable.cmmn.api.repository.CmmnDeployment;
import org.flowable.cmmn.api.runtime.CaseInstance;
import org.flowable.cmmn.api.runtime.PlanItemInstance;
import org.flowable.cmmn.engine.CmmnEngine;
import org.flowable.cmmn.engine.CmmnEngineConfiguration;
import org.flowable.cmmn.engine.impl.cfg.StandaloneInMemCmmnEngineConfiguration;
import org.flowable.task.api.Task;
import org.flowable.task.api.history.HistoricTaskInstance;


public class CMMNEngine 
{
    public static void main( String[] args )
    {
    	CmmnEngine cmmnEngine = ((CmmnEngineConfiguration) CmmnEngineConfiguration.createStandaloneInMemCmmnEngineConfiguration()
    			  .setDatabaseSchemaUpdate(CmmnEngineConfiguration.DB_SCHEMA_UPDATE_TRUE)
    			  .setJdbcUrl("jdbc:h2:mem:my-own-db;DB_CLOSE_DELAY=1000"))
    			
    			  .buildCmmnEngine();
    	 CmmnEngine cmmnEngine
         = new StandaloneInMemCmmnEngineConfiguration().buildCmmnEngine();
    	 CmmnRepositoryService cmmnRepositoryService = cmmnEngine.getCmmnRepositoryService();
    	 CmmnDeployment cmmnDeployment = cmmnRepositoryService.createDeployment()
    	     .addClasspathResource("cases/my-case.cmmn.xml")
    	     .deploy();
    	 List<CaseDefinition> caseDefinitions = cmmnRepositoryService.createCaseDefinitionQuery().list();
    	 System.out.println("Found " + caseDefinitions.size() + " case definitions");
    	 
    	 CmmnRuntimeService cmmnRuntimeService = cmmnEngine.getCmmnRuntimeService();
    	 CaseInstance caseInstance = cmmnRuntimeService.createCaseInstanceBuilder()
    	     .caseDefinitionKey("employeeOnboarding")
    	     .variable("potentialEmployee", "johnDoe")
    	     .start();
    	 List<PlanItemInstance> planItemInstances = cmmnRuntimeService.createPlanItemInstanceQuery()
    			    .caseInstanceId(caseInstance.getId())
    			    .orderByName().asc()
    			    .list();

    	 for (PlanItemInstance planItemInstance : planItemInstances) {
    		    System.out.println(planItemInstance.getName()
    		        + ", state=" + planItemInstance.getState()
    		        + ", parent stage=" + planItemInstance.getStageInstanceId());
    		}
    	 CmmnTaskService cmmnTaskService = cmmnEngine.getCmmnTaskService();
    	 List<Task> hrTasks = cmmnTaskService.createTaskQuery()
    	     .taskCandidateGroup("hr")
    	     .caseInstanceId(caseInstance.getId())
    	     .orderByTaskName().asc()
    	     .list();
    	 for (Task task : hrTasks) {
    	     System.out.println("Task for HR : " + task.getName());
    	 }

    	 List<Task> employeeTasks = cmmnTaskService.createTaskQuery()
    	     .taskAssignee("johndoe")
    	     .orderByTaskName().asc()
    	     .list();
    	 for (Task task : employeeTasks) {
    	     System.out.println("Task for employee: " + task);
    	 }
    	 for (Task task : hrTasks) {
    		    cmmnTaskService.complete(task.getId());
    		}

    		hrTasks = cmmnTaskService.createTaskQuery()
    		    .taskCandidateGroup("hr")
    		    .caseInstanceId(caseInstance.getId())
    		    .orderByTaskName().asc()
    		    .list();

    		for (Task task : hrTasks) {
    		    System.out.println("Task for HR : " + task.getName());
    		}
    		List<Task> tasks = cmmnTaskService.createTaskQuery().caseInstanceId(caseInstance.getId()).listPage(0, 1);
    		while (!tasks.isEmpty()) {
    		    cmmnTaskService.complete(tasks.get(0).getId());
    		    tasks = cmmnTaskService.createTaskQuery()
    		        .caseInstanceId(caseInstance.getId())
    		        .listPage(0, 1);
    		}
    		CmmnHistoryService cmmnHistoryService = cmmnEngine.getCmmnHistoryService();
    		HistoricCaseInstance historicCaseInstance = cmmnHistoryService.createHistoricCaseInstanceQuery()
    		    .caseInstanceId(caseInstance.getId())
    		    .singleResult();

    		System.out.println("Case instance execution took "
    		    + (historicCaseInstance.getEndTime().getTime() - historicCaseInstance.getStartTime().getTime()) + " ms");

    		List<HistoricTaskInstance> historicTaskInstances = cmmnHistoryService.createHistoricTaskInstanceQuery()
    		    .caseInstanceId(caseInstance.getId())
    		    .orderByTaskCreateTime().asc()
    		    .list();

    		for (HistoricTaskInstance historicTaskInstance : historicTaskInstances) {
    		    System.out.println("Task completed: " + historicTaskInstance.getName());
    		}

}}*/