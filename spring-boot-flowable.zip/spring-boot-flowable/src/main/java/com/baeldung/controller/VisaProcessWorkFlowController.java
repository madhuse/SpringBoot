package com.baeldung.controller;

import java.util.List;

import org.flowable.engine.TaskService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.baeldung.domain.VisaDetails;
import com.baeldung.service.VisaProcessWorkFlowService;

@RestController
public class VisaProcessWorkFlowController {
	 private VisaProcessWorkFlowService service;
	    
	    @Autowired
	    private TaskService taskService;
	    @PostMapping("/visasubmit")
	    public void submit(@RequestBody VisaDetails visaDetails) {
	        service.startProcess(visaDetails);
	    }
	    @GetMapping("/visatasks")
	    public List<VisaDetails> getTasks(@RequestParam(value = "assignee") String assignee) {
	        return service.getTasks(assignee);
	    }
}
