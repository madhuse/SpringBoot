package com.baeldung.controller;

import java.util.List;

import org.flowable.engine.TaskService;
import org.flowable.idm.api.User;
import org.flowable.task.api.Task;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.baeldung.domain.Approval;
import com.baeldung.domain.Article;
import com.baeldung.domain.Resubmit;
import com.baeldung.service.ArticleWorkflowService;

@RestController
public class ArticleWorkflowController {
    @Autowired
    private ArticleWorkflowService service;
    
    @Autowired
    private TaskService taskService;
    @PostMapping("/submit")
    public void submit(@RequestBody Article article) {
        service.startProcess(article);
    }
    @GetMapping("/tasks")
    public List<Article> getTasks(@RequestParam(value = "assignee") String assignee) {
        return service.getTasks(assignee);
    }
    @PostMapping("/review")
    public void review(@RequestBody Approval approval) {
        service.submitReview(approval);
    }
    
    @PostMapping("/resubmit")
    public void ressubmit(@RequestBody Resubmit resubmit) {
    	service.resubmit(resubmit);
    }
    /*@GetMapping("/test")
    public Article getTask() {
    	Task task = taskService.createTaskQuery().singleResult();
    	 System.out.println(task.getId());
    	 return new Article(
                 task.getId(), null, null);
    	
       
    }*/
    @GetMapping("/user")
    public User task2() {
    	System.out.println(service.createUser());
		return service.createUser();
    	
    
    	
       
    }
}