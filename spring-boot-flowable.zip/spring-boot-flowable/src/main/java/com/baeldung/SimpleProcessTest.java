/*package com.baeldung;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.logging.LogManager;
import java.util.logging.Logger;

import org.activiti.engine.FormService;
import org.activiti.engine.RuntimeService;
import org.activiti.engine.TaskService;
import org.activiti.engine.form.FormProperty;
import org.activiti.engine.form.TaskFormData;
import org.activiti.engine.runtime.Execution;
import org.activiti.engine.runtime.ProcessInstance;
import org.activiti.engine.task.Task;
import org.activiti.engine.task.TaskQuery;
import org.junit.Test;
public class SimpleProcessTest {
	@Autowired
	private RuntimeService runtimeService;

	@Autowired
	private TaskService taskService;
	
	@Autowired
	private FormService formService;

	Logger rootLogger = LogManager.getLogManager().getLogger("");

	@Test
	public void startSimpleProcess() {

		// Set process variables
		Map<String, Object> variableMap = new HashMap<String, Object>();
		variableMap.put("caseId", "");
		variableMap.put("caseName", "");
		variableMap.put("isbn", 0);
		variableMap.put("validationResult", false);
		variableMap.put("bookOrder", new BookOrder());

		// Initiate process with initial process variables
		ProcessInstance processInstance = runtimeService
				.startProcessInstanceByKey("myProcess", variableMap);
		

		// When process is started, it will firstly get to node1, the init
		// service task

		// Check instance variables
		// Process execution
		List<Execution> executions = runtimeService.createExecutionQuery()
				.processInstanceId(processInstance.getId()).list();
		for (Execution execution : executions) {
			rootLogger.info("Process execution: " + " id: " + execution.getId()
					+ " and current activity id= " + execution.getActivityId());
			rootLogger.info("Execution variables: "
					+ runtimeService.getVariables(execution.getId()));
		}
		
		// Task
		TaskQuery taskQuery = taskService.createTaskQuery();
		Task task = taskQuery.singleResult();
	    TaskFormData taskFormData = formService.getTaskFormData(task.getId());
	    rootLogger.info("Task form: " + taskFormData.getFormKey());
	    List<FormProperty> formProperties = taskFormData.getFormProperties();
	    for (int i = 0; i < formProperties.size(); i++) {
	    	FormProperty formProperty = formProperties.get(i);
	    	rootLogger.info("REVIEW FORM -- property id = " + formProperty.getId() + " value = " + formProperty.getValue());
	    }
	    
	    // Completing the task continues the process which leads to calling the next user task
	    // Submit the form and complete user task 1
	    rootLogger.info("Submit Review");
	    taskService.complete(task.getId());
	    
	    
	    
	    executions = runtimeService.createExecutionQuery()
				.processInstanceId(processInstance.getId()).list();
		for (Execution execution : executions) {
			rootLogger.info("Process execution: " + " id: " + execution.getId()
					+ " and current activity id= " + execution.getActivityId());
			rootLogger.info("Execution variables: "
					+ runtimeService.getVariables(execution.getId()));
		}
		
		TaskQuery taskQuery2 = taskService.createTaskQuery();
		Task task2 = taskQuery2.singleResult();
	    TaskFormData taskFormData2 = formService.getTaskFormData(task2.getId());
	    rootLogger.info("Task 2 form: " + taskFormData2.getFormKey());
	    List<FormProperty> formProperties2 = taskFormData2.getFormProperties();
	    for (int i = 0; i < formProperties2.size(); i++) {
	    	FormProperty formProperty = formProperties2.get(i);
	    	rootLogger.info("APPROVAL FORM -- property id = " + formProperty.getId() + " value = " + formProperty.getValue());
	    }
	    
	    // Submit the form and complete user task 1
	    rootLogger.info("Submit Final Approval");
	    taskService.complete(task2.getId());
	    

		// Checking the other running process instances
		List<ProcessInstance> instanceList = runtimeService
				.createProcessInstanceQuery()
				.processDefinitionKey("myProcess").list();
		rootLogger.info("Running processes: " + instanceList.size());
		for (ProcessInstance queryProcessInstance : instanceList) {
			assertEquals(false, queryProcessInstance.isEnded());
			System.out.println("id " + queryProcessInstance.getId()
					+ ", ended=" + queryProcessInstance.isEnded());
		}
	    
	}
}
}
*/