	getProcessedFiles();
	validateCharacter();
	
function getProcessedFiles(){
	$.ajax({
		type: 'GET',
		url: "getProcessFiles",
		async: false,
		success : function(response){
						if(response.length >0 ){
							insertProcessedFiles(response);
						}
						else{
							$(".containerr").empty();
							$(".containerr").addClass('align_center_parent');
							$(".containerr").html("<div class='align_center error'>No files to show status</div>");
						}
			
				}
			      
	 });//ajax
}
var uploadTable;
function insertProcessedFiles(filesArray){
	var headerNames = Object.keys(filesArray[0]);
	var idName = headerNames[0];
	var statusMessages = {"success":"file uploaded sucessfully","pending":"click to upload file","failed":"click to view failed reason"};
	var head='<thead><tr><th>S.No</th>';
	var footer='<tfoot><tr><th>S.No</th>';
	var data='';
	$.each(headerNames, function(i, name) {
		if(name=='fileName'){
			name='File Names';
		}else if (name == 'status'){
			name = 'Status';
		}
		if(i > 2){
			 head=head+'<th class="none">'+name+'</th>'; 
			 }
		 else{
			 head=head+'<th>'+name+'</th>';
		 }
		footer=footer+'<th>'+name+'</th>';
	});
	head+='</tr></thead><tbody>';
	footer+='</tr></tfoot>';
	var files =[{"fileName":"file1.xls","status":"pending"},{"fileName":"file2.csv","status":"pending"},{"fileName":"file3","status":"success"}]
		$.each(filesArray,function(index,file){
			data=data+'<tr class="'+file[headerNames[2]]+'">'+'<td>'+(index+1)+'</td>';
			$.each(file,function(key,val){
				
				if(key.indexOf('Date') != -1)
					val = new Date(val).toLocaleString(); 
				 if(key == "status"){
					var titleMsg = statusMessages[val];
					data=data+'<td class="'+val+'"><button class="file_status_btn" title ="'+titleMsg+'">'+val+'</button></td>';
				}
				else{
					data=data+'<td>'+val+'</td>';
				}
			});
			
		//data=data+'<td>'+(index+1)+'</td>'+'<td>'+file.filename+'</td>'+'<td class="'+fileStaus+'" title ="'+titleMsg+'"><button class="file_status_btn">'+fileStaus+'</button></td>';
		data=data+'</tr>';
	});
	tableData='<table class="table table-striped table-bordered" style="width:100%" id="processFileTable" >'+head+data+'</tbody>'+footer+'</table>';

	$("#processFileDiv").append('<div>'+tableData+'</div>');

	uploadTable =	$('#processFileTable').DataTable( {
		 order: [ [ 3, "asc" ] ],//desc
		 responsive: {
            details: {
                type: 'column',
                target: 'td.failed > button',
                renderer: function ( api, rowIdx, columns ) {
                	var failedBtn = this;
                	var removeFileBtn = false, failedFileId, duplicateFileBtn = false;
                    var data = $.map( columns, function ( col, i ) {
                    	var dataa = '';
                    	if(col.hidden){
                    		if($.isNumeric(col.data)){
                    			var res = parseInt(col.data);
                        		failedFileId = col.data;
                        		var btns = '';
                        		if(removeFileBtn){
                        			btns = '<button id= "'+res+'" class="btn btn-danger" onclick="failedFileBtnAction(\'remove\','+res+',this)">Remove File</button>';
                            	}
                        		else if(duplicateFileBtn){
                        			btns = '<button id= "'+res+'" class="btn btn-success" onclick="renameBtn(this,'+res+',this)">Rename File</button><button id= "'+res+'" class="btn btn-warning" style="margin: 0px 5px;" onclick="failedFileBtnAction(\'replace\','+res+',this)">Replace File</button><button id= "'+res+'" class="btn btn-danger" onclick="failedFileBtnAction(\'remove\','+res+',this)">Remove File</button>';
                            	}
                    			dataa =  '<tr data-dt-row="'+col.rowIndex+'" data-dt-column="'+col.columnIndex+'"><td colspan="2" style="text-align:center">'+btns+
                            '</td></tr>' ;
                    		}
                    		else{
                    			dataa =  '<tr data-dt-row="'+col.rowIndex+'" data-dt-column="'+col.columnIndex+'">'+
                                '<td style="font-weight: bold;">'+col.title+': '+'</td> '+
                                '<td>'+col.data+'</td>'+
                            '</tr>' ;
                    			if(col.data == 'File name already existed'){
                        			duplicateFileBtn = true;
                        		}
                    			else{//'File fields are lessthan Table Fields' , 'Unexpeted Error'
                        			removeFileBtn = true;
                        		}
                        		 
                    		}
                    	}
                    	return dataa;
                       
                    } ).join('');
     
                    if(data){
                     return $('<table/>').append( data );
                    }
                    else{
                    return false;	
                    }
                  
                }
            }
        },
        columnDefs: [{
            className: 'control',
            orderable: false,
            targets:  'td.failed'
        } ]
    } );
	//$(".upload-url").removeClass("btn-default");
	upload();
	filterStatus();

}
function failedFileBtnAction(actionName,id,btn){
	const confirmationMsg = PNotify.alert({
		  title: 'Confirmation Needed',
		  text: "Are you sure,you want to "+actionName+" file",
		  stack: centerModalStack,
		  hide: false,
		  modules: {
		    Confirm: {
		      confirm: true
		    }
		  }
		});
	confirmationMsg.on('pnotify.confirm', () => {
		var url = actionName+"file";
			$.ajax({
				type:"POST",
				url:url,
				data:{
					"failedFileId":id
				},
				success: function (response){
					notifyMsg("success","File "+actionName+"ed Sucessfully");	
					location.reload();
				/*	$(thisbtn).trigger('click');
					$(thisbtn).parent().removeClass('failed');
					$(thisbtn).parent().addClass('success');
					$(thisbtn).html('success');*/
				}
			});
		});
	confirmationMsg.on('pnotify.cancel', () => {
			
		});
	
	
	
	
}
function renameBtn(obj,id,btn){
	const promptNotice = PNotify.alert({
		  title: 'Confirmation Needed',
		  text: "Are you sure,you want cancel uploading file "+fileName+"\n you want to upload "+fileName+" file",
		  stack: centerModalStack,
		  hide: false,
		  modules: {
		    Confirm: {
		      prompt: true
		    }
		  }
		});
	promptNotice.on('pnotify.confirm', (val) => {
			var newName = val.value;
			renameAjax(newName,id,btn);
			
		});
	promptNotice.on('pnotify.cancel', () => {
			
		});
	 
}
function renameAjax(filename,id,btn){
	$.ajax({
		type:"POST",
		url:"getfileinfo",
		data:{
			"filename":filename
		},
		success:function(response){
			var fileId = response.processedfileid;
			if(fileId == undefined){
				$.ajax({
					type:"POST",
					url:"renamefile",
					data:{
						"failedFileId":id,
						"newFileName":filename
					},
					success: function (response){
						notifyMsg("success","Filename updated Sucessfully");
						location.reload();
						/*$(thisbtn).trigger('click');
						$(thisbtn).parent().removeClass('failed');
						$(thisbtn).parent().addClass('success');
						$(thisbtn).html('success');*/
						
					}
				});
			}
			else{
				notifyMsg("info","Give another name",filename+" Filename already existed");
			}
		}
	});
	
}
var fileName = "";var rowNo;var thisbtn;
function upload(){

/*	$('#processFileTable tr').find('td:nth-last-child(2)').on('click', function (e) {
		var currentRow = $(this).closest('tr');
		 uploadTable.row(currentRow).nodes().to$().find('td.control').trigger('click');
	});*/
	$('td.failed button').click( function () {
		var currentRow = $(this).closest('tr');
		thisbtn = this;
		 uploadTable.row(currentRow).nodes().to$().find('td.control').trigger('click');
		 var title = $(this).attr("title") == "click to view failed reason" ? "click to close reason" : "click to view failed reason";
		 $(this).attr("title",title);
	});
	
	$('td.pending button').click( function () {
		var btnDisabled = $(this).hasClass("disabled");
		
		
				if(!btnDisabled){
					 fileName  = uploadTable.row($(this).closest('tr')).data()[1];
					 
					 var boolean = true;
					 var curBtn = this;
					 if($(".fa-spinner").length == 1){
						 
						 const notice = PNotify.alert({
							  title: 'Confirmation Needed',
							  text: "Are you sure,you want cancel uploading file "+fileName+"\n you want to upload "+fileName+" file",
							  stack: centerModalStack,
							  hide: false,
							  modules: {
							    Confirm: {
							      confirm: true
							    }
							  }
							});
							notice.on('pnotify.confirm', () => {
								$(thisbtn).css("pointer-events","unset");
								$(thisbtn).css("pointer", "cursor");
								$(thisbtn).html('Pending');
								$("#delimeter").removeAttr("readOnly");
					     		$("#delimeter").css({"cursor":"pointer","border-color":"unset"});
					     		$("#fileTableMappingDivsContainer div").not(':first').remove();
								aa(curBtn);
							});
							notice.on('pnotify.cancel', () => {
								boolean = false;
							});
						 
						
					 }
					 else{
						 aa(this);
					 }
					 function aa(thiss){
						 if(boolean){
							 var rowNo = uploadTable.row($(thiss).closest('tr')).index();
							 $(thiss).css("pointer-events", "none");
							 $(thiss).html('<i class="fa fa-spinner fa-spin"></i>Processing');
					     	  thisbtn = thiss ;
					     	 
					     	 if(fileName.endsWith(".csv")){
					     		$("#delimeter").val(",");
					     		upload_file(fileName,",");
					     	 }
					     	 else{
					     		$("#delimeter").val("");
					     		txtFileSubmitBtn(fileName);
					     		 }
					      } 
					 }
					 
				}	 
		 } );
}


function txtFileSubmitBtn(fileName){
	$("#fileTableMappingContainer").show();
	$("#fileTableMappingDivsContainer").append('<div style="text-align: center;"><button id="continueProcess" class="btn btn-success">Continue Process</button></div>');
	$('#continueProcess').click(function () {
		if($("#delimeter").val() != ""){
			$("#fileTableMappingDivsContainer div").not(':first').remove();
			upload_file(fileName,$("#delimeter").val());
			}
			else{
				$("#delimeter").css("border-color","red");
				//$("#delimeter").next().text('Please Enter Delimeter').show().fadeOut(6000);
			}
	});
	$( "#continueProcess" ).focus();
}
function upload_file(fileName,delimeter){
	
	 checkFields(fileName,delimeter).done(function (data){
		 if(data != null){
				 if(data.filetableMappingId != null && data.filetableMappingId != 0){
			 			$(thisbtn).addClass("btn-success");
			           	$(thisbtn).removeClass("upload-url");
			            $(thisbtn).html("uploaded sucessfully");
			            $("#fileTableMappingContainer").hide();
			 	 }
			 	 else if(data.csvFields.length < data.hiveFields.length){
			 		$("#fileTableMappingDivsContainer div").not(':first').remove();
			 		$("#delimeter").attr("readOnly","true");
			 		$("#delimeter").css("cursor","not-allowed");
			 		$("#fileTableMappingDivsContainer").append('<div class="error">File fields are lessthan Table Fields</div><br> <div style="text-align: center;"><button id="changeDelimeter" class="btn btn-warning" delimeter="'+delimeter+'">Change Delimeter</button>&nbsp&nbsp<button id="updateFileFailed" class="btn btn-success">Continue Process</button></div>');
			 		$("#changeDelimeter").click(function(){
			 			$("#delimeter").val("");
			 			$("#delimeter").removeAttr("readOnly");
				 		$("#delimeter").css("cursor","pointer");
			 			$("#fileTableMappingDivsContainer div").not(':first').remove();
			 			txtFileSubmitBtn(fileName);
			 		});
			 		$("#updateFileFailed").click(function () {
			 			updateFileAsFailed(fileName,"File fields are lessthan Table Fields");
			 		})	 
			 	 }else{
			 			$("#fileTableMappingContainer").show();
			 			csvFields = data.csvFields;
			 			fileTableMappingContainer(fileName,data.csvFields,data.hiveFields,data.mobileNumber);
			 		 } 
		 }else{
			  $(thisbtn).html("IOException- File Related Error");
				$(thisbtn).addClass("error");
		 }
 		 
 		});
}


function checkFields(fileName,delimeter){
	return $.ajax({
		type: 'POST',
		url: "checkfields",
		async: false,
		data:{
			"fileName":fileName,
			"delimeter":delimeter
		},
		success : function(response){
						return response;
				}
			      
	 });//ajax
}
function updateFileAsFailed(fileName,failedMsg){
	 $.ajax({
		type: 'POST',
		url: "updateFileAsFailed",
		async: false,
		data:{
			"fileName":fileName,
			"failedMessage":failedMsg
		},
		success : function(response){
			fileUploadResultHandler("error",response);
				}
			      
	 });//ajax
}

function fileTableMappingContainer(fileName,fields,hiveFields,mobileNumber){
	$("#delimeter").attr("readOnly","true");
	$("#delimeter").css("cursor","not-allowed");
	if(mobileNumber == null){
		mobileNumber = '';
		}
	
	/*$( "#DelimeterDiv" ).after( '<div class="content-box scroll" id="fileTableMappingDiv"></div>'+
			'<div class="content-box scroll" id = "removedValuesDiv">'+
			'<input type="checkbox" id="extraDelimeter">Characters to remove from values'+
							'<div id="addExtraDelimters">'+ 
									 '<div id="extraDelDiv">'+
									 '<div class="row"><input class="extra-delimeters" type="text" maxlength="1" size="1"><span class="errorMsg"></span><span class="fa fa-plus-circle" onclick ="addDelimeters()" title="add new character to remove from values"></span></div>'	+
									 '</div></div></div>'+
									 '<div style="text-align: center;"><button id="uploadbtn">Submit</button></div>');
	*/
	mobileNumber = '<br><div id="MobNumDiv"><h4>CDR for Mobile:&nbsp</h4> <input type="text" maxlength="10" size=10  value="'+mobileNumber+'" title="Please enter valid 10 digits mobile number" id="mobileNo"></div>';
	$( "#DelimeterDiv" ).after(mobileNumber+'<div class="table_mapping_selection"><h4>Table Mapping :</h4><div class="content-box scroll" id="fileTableMappingDiv"></div></div>'+
			'<div><label style="margin-left: 18px;"><input type="checkbox" id="extraDelimeter"> Characters to remove from values</label>'+
			'<div class="content-box scroll" id = "removedValuesDiv" style="display:none">'+
							'<div id="addExtraDelimters">'+ 
									 '<div id="extraDelDiv">'+
									 '<div class="row"><input class="extra-delimeters" type="text" maxlength="1" size="1"><span class="errorMsg"></span><span class="fa fa-plus-circle" onclick ="addDelimeters()" title="add new character to remove from values"></span></div>'	+
									 '</div></div></div></div>'+
									 '<div style="text-align: center;"><button id="uploadbtn">Submit</button></div>');
	
	
	validateMobileNUmber();
	prepareFileTableMapping(hiveFields,fields);
	submitFileUpload(fileName);
	$($( ".fileFields" )[0]).focus();
}
var fileTableMapping_Table;
function prepareFileTableMapping(hiveTableFields,fileFields){
	var headerNames = ["hivetable","fileFields"];
	var head='<thead><tr><th>Table Fields</th><th>File Fields</th></tr></thead>';
	var footer='<tfoot><tr><th>Table Fields</th><th>File Fields</th></tr></tfoot>';
	var data='';
	var dropdown = '<select class="fileFields">';
	$.each(fileFields,function(i,field){
		dropdown += "<option value='"+i+"'>"+field+"</option>";
	});
	dropdown += "</select>";
	$.each(hiveTableFields,function(index,field){
		data=data+'<tr>';
	    data=data+'<td>'+field+'</td>'+'<td>'+dropdown+'<span class="error"></span></td>';
	    data=data+'</tr>';
    });
	
	tableData='<table class="table table-striped table-bordered" style="width:100%" id="fileTableMapping" >'+head+data+'</tbody>'+footer+'</table>';

	$("#fileTableMappingDiv").append('<div>'+tableData+'</div>');

	fileTableMapping_Table =	$('#fileTableMapping').DataTable({
		   "ordering": false
	});
	onChangeSelectBox();
}

var selectedVal = [];
function onChangeSelectBox(){
	
$('.fileFields').change(function(){
	$(this).addClass($(this).val()+"sel");
	selectedVal = [];
	$('.fileFields').each(function(){
		if($(this).hasClass($(this).val()+"sel")){
			selectedVal.push($(this).val());
		}
	});
	
if(selectedVal.filter(item => item == $(this).val()).length == 1){
$("."+$(this).val()+"sel").removeClass("errorOutline");
}
else{
$("."+$(this).val()+"sel").addClass("errorOutline");
}
 valiadationsSelectBox();
	});
}
function valiadationsSelectBox(){
var selVal = [];
var errorOutline = $('.errorOutline');
errorOutline.each(function(i,val){
if(selectedVal.filter(item => item == $(this).val()).length == 1){
$(this).removeClass("errorOutline");
}
else{
$("."+$(this).val()+"sel").addClass("errorOutline");
}
});


}
var isFirstTime = true;
function validateMobileNUmber(){
	var initalMobileNumber = $('#mobileNo').val();
	if(initalMobileNumber == ''){
		isFirstTime = false;
	}
	else{
		$('#mobileNo').keypress(function () {
			 if(isFirstTime){//mobile number 
				 notification();
			 }		
		});
	}
	$('#mobileNo').on("keyup", function(event){
	if(isFirstTime && event.keyCode == 8 ){
		notification();
	}
		var exp = /([1-9]{1}[0-9]{9})/;
		 var phoneno = /^\d{10}$/;
	if(! $.isNumeric($('#mobileNo').val())){
		var value = $(this).val();
		$(this).val(value.substr(0, value.length - 1));
	}
	
	if(event.keyCode == 8 || $('#mobileNo').val().length == 10){
		if($('#mobileNo').val().match(exp) != null){
			$("#mobileNo").css({"border-color":"unset"});	
		}else{
			$("#mobileNo").css({"border-color":"red"});
		}
	}
	});
	function notification(){
		isFirstTime = false;
		const noticeChangeNum = PNotify.alert({
			  title: 'Confirmation Needed',
			  text: "Are you sure,you want to change mobile Number",
			  stack: centerModalStack,
			  hide: false,
			  modules: {
			    Confirm: {
			      confirm: true
			    }
			  }
			});
		 noticeChangeNum.on('pnotify.confirm', () => {
				});
		 noticeChangeNum.on('pnotify.cancel', () => {
			 $("#mobileNo").css({"border-color":"unset"});
			 $('#mobileNo').val(initalMobileNumber);
			 isFirstTime = true;
			});
	}
}
function validateCharacter(){
	$('#delimeter, .extra-delimeters').keyup(function () {
		  const key = event.key; // const
		if( !(key === "Backspace") ){
		if(this.value.length == 1){
		if(!validateCharacter(this.value)){
		$(this).val("");
		$(this).next().text( "special characters only allowed");
		$(this).next().show().fadeOut(6000);
		}
		}
		else if(this.value.length > 1){
		console.log(this.value);
		this.value = this.value[0];
		$(this).next().text( "max 1 character only allowed");
		$(this).next().show().fadeOut(6000);
		//alert("max 1 character only allowed");
		}
		
		}
		else{
		}
		});
		function validateCharacter(char){
		     if (!char.match(/^(\d|[a-zA-z])+$/) || char.match(/\\/)) {
		     return true;
		    }
		}
}
function addDelimeters(){
	$("#extraDelDiv").append('<div class="row"><input class="extra-delimeters" type="text" maxlength="1" size="1"><span class="errorMsg"></span><span class="fa fa-minus-circle" aria-hidden="true" onclick ="removeDelimeter(this)" title="remove delimeter"></span><div>');
	validateCharacter();
}
function removeDelimeter(obj){
	$(obj).parent().remove();
}


function submitFileUpload(fileName) {
	$('#extraDelimeter').change(function(){
		if(this.checked){
			 $('#removedValuesDiv').show();
			 //$("#addExtraDelimters").show();
		 }else{
			 $("#extraDelDiv div").not(':first').remove();
			 $(".extra-delimeters").val("");
			 $('#removedValuesDiv').hide();
			 //$("#addExtraDelimters").hide();
			  }  
	});
	$("#uploadbtn").unbind("click");
	$("#uploadbtn").click(function () {
			var isValid = validationsToSubmit();
			if(isValid){
					var fileObj = {
							//"filetable_mapping_id":fileTblMapId,
							"fileName": fileName,
							"delimeter":delimiter,
							"removedValues":removed_values,
							"csvmappedIndex":csvmapped_index,
							"csvFields": csvFields,
							"mobileNumber":$('#mobileNo').val()
					};
					$.ajax({
						type:"POST",
						url:"upload",
						contentType:'application/json',
						async:false,
						data: JSON.stringify(fileObj),
						success: function (response){
							//alert(response);
							type = "success";msg = "Uploaded Successfully";
							if(response != "success"){
								type = "error";
								msg = "Not Uploaded, please try again";
							}
							fileUploadResultHandler(type,msg);
							filterStatus();
						}
					});
			}
		
	});
}

function fileUploadResultHandler(status,msg){
	notifyMsg(status,msg);	//$(thisbtn).closest('tr').addClass("success");
	if(status == "error"){
		status = "failed"
	}
	$(thisbtn).closest('td').removeClass("pending");
	$(thisbtn).closest('td').addClass(status);
	$(thisbtn).html(msg);
	$("#fileTableMappingDivsContainer div").not(':first').remove();
	$("#fileTableMappingContainer").hide();
}
var csvmapped_index = [];
var removed_values;
var delimiter = "";var csvFields = [];
function validationsToSubmit() {
	delimiter = $("#delimeter").val();
	
	var fieldsLength = $(".fileFields").length;
	var fileFields = [];var dupFiledIndex = [];
	$(".fileFields").each(function(i,val){
		var val = $(this).val();
		$(this).addClass($(this).val()+"sel");
		var textContent = $("option:selected", $(this)).text();
		if(fileFields.indexOf(val) == -1){
			fileFields.push($(this).val());
		}
		else{
			$("."+$(this).val()+"sel").addClass("errorOutline");
			dupFiledIndex.push(i);
		}
	 });
	
	var extraDelimeters;
	var extraDelimeter = false;
	var extraDelimetersLength;
	if($("#extraDelimeter").prop('checked')==true){
		extraDelimeter = true;
		extraDelimeters = [];
		extraDelimetersLength = $(".extra-delimeters").length;
		$(".extra-delimeters").each(function(){
			var val = $(this).val();
			if(val != "" && fileFields.indexOf(val) == -1){
				extraDelimeters.push($(this).val());
			}
		 });
	}
	var exp = /([1-9]{1}[0-9]{9})/;
	var isMobileNumbValid = $('#mobileNo').val().match(exp) != null;
	if( isMobileNumbValid && delimiter != "" && fieldsLength == fileFields.length && (!extraDelimeter || (extraDelimeter && extraDelimeters.length == $(".extra-delimeters").length))){
		csvmapped_index = fileFields;
		removed_values = extraDelimeters;
		return true;
	}
	else{
		if(!isMobileNumbValid){
			$("#mobileNo").css({"border-color":"red"});
			notifyMsg("error","please enter valid 10 digit Mobile Number");
		}
		if(delimiter == ""){
			notifyMsg("error","please enter delimeter");
			
		}
		if(fieldsLength != fileFields.length){
			notifyMsg("error","please select one unique fileFields for hiveTable coloumns");
		}
		if(extraDelimeter && extraDelimeters.length != extraDelimetersLength){
			notifyMsg("error","please fill extra delimeters");
		}
		return false;
	}
}
window.centerModalStack = {
	      'dir1': 'down',
	      'dir2': 'right',
	      'firstpos1': 70,
	      'firstpos2': 500,
	      'modal': true,
	      'overlayClose': true
	     
	    };
function notifyMsg(type,msg,title){

	if(type == "error"){
		PNotify.error({
		      title: 'Oh No!',
		      text: msg,
		      hide: false,
		      stack: centerModalStack
		    });
	}
	else if(type == "info"){
		PNotify.info({
		      title: title,
		      text: msg,
		      hide: false,
		      stack: centerModalStack
		    });
	}
	else{
		PNotify.success({
		      title: 'Success!',
		      text: msg,
		      hide: false,
		      stack: centerModalStack
		    });
	}
	
}

function filterStatus(){
	
	  var status = $('input:checkbox[name="type"]:checked').map(function() {
		    return '^' + this.value + '\$';
		  }).get().join('|');
	  
	  uploadTable.column( 2 ).search(status, true, false).draw();

}