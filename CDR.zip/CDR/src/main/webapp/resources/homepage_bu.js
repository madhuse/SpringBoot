	getProcessedFiles();
	validateCharacter();
	
function getProcessedFiles(){
	$.ajax({
		type: 'GET',
		url: "getProcessFiles",
		async: false,
		success : function(response){
			insertProcessedFiles(response);
				}
			      
	 });//ajax
}
var uploadTable;
function insertProcessedFiles(filesArray){
	var headerNames = Object.keys(filesArray[0]);
	var idName = headerNames[0];
	headerNames[0] = "s.no";
	var statusMessages = {"success":"file uploaded sucessfully","pending":"click button to upload file"};
	var head='<thead><tr>';
	var footer='<tfoot><tr>';
	var data='';
	$.each(headerNames, function(i, name) {
		head=head+'<th>'+name+'</th>';
		footer=footer+'<th>'+name+'</th>';
	});
	head+='</tr></thead><tbody>';
	footer+='</tr></tfoot>';
	var files =[{"fileName":"file1.xls","status":"pending"},{"fileName":"file2.csv","status":"pending"},{"fileName":"file3","status":"success"}]
		$.each(filesArray,function(index,file){
			data=data+'<tr class="'+file[headerNames[2]]+'" filetable_mapping_id = "'+file[idName]+'">';
			$.each(file,function(key,val){
				if(key == idName){
					data=data+'<td>'+(index+1)+'</td>';
				}else if(key.indexOf("status")!= -1){
					var titleMsg = statusMessages[val];
					data=data+'<td class="'+val+'" title ="'+titleMsg+'"><button class="file_status_btn">'+val+'</button></td>';
				}
				else{
					data=data+'<td>'+file.filename+'</td>';
				}
			});
			
		//data=data+'<td>'+(index+1)+'</td>'+'<td>'+file.filename+'</td>'+'<td class="'+fileStaus+'" title ="'+titleMsg+'"><button class="file_status_btn">'+fileStaus+'</button></td>';
		data=data+'</tr>';
	});
	tableData='<table class="table table-striped table-bordered" style="width:100%" id="processFileTable" >'+head+data+'</tbody>'+footer+'</table>';

	$("#processFileDiv").append('<div>'+tableData+'</div>');

	uploadTable =	$('#processFileTable').DataTable();
	//$(".upload-url").removeClass("btn-default");
	upload();

}
var fileName = "";var rowNo;var thisbtn;
function upload(){

	$('td.pending button').click( function () {
		var btnDisabled = $(this).hasClass("disabled");
		
		
				if(!btnDisabled){
					// $(this).addClass("disabled");
					 fileName  = uploadTable.row($(this).closest('tr')).data()[1];
					 var boolean = true;
					 var curBtn = this;
					 if($(".fa-spinner").length == 1){
							/*var r = confirm("Are you sure,you want cancel uploading file "+fileName+"\n you want to upload "+fileName+" file");
							if (r == true) {
								$(thisbtn).css("pointer-events","unset");
								$(thisbtn).css("pointer", "cursor");
								$(thisbtn).html('Pending');
								originalFileTableMappingContainer();
							 } else {
								boolean = false;
							    // txt = "You pressed Cancel!";
							}*/
							
							var lobibox = Lobibox.confirm({
								title: "Confirmation Needed",
								msg         : "Are you sure,you want cancel uploading file "+fileName+"\n you want to upload "+fileName+" file",
								//buttons: ['ok', 'cancel'],//, 'yes', 'no'
								callback: function(lobibox, type){
								if (type === 'no'){
									   boolean = false;
								    }else if (type === 'yes'){
								    	$(thisbtn).css("pointer-events","unset");
										$(thisbtn).css("pointer", "cursor");
										$(thisbtn).html('Pending');
										originalFileTableMappingContainer();
								    }/*else if (type === 'ok'){
								        btnType = 'info';
								    }else if (type === 'cancel'){
								        btnType = 'error';
								    }*/
								aa(curBtn);
								}
								});
					 }
					 else{
						 aa(this);
					 }
					 function aa(thiss){
						 if(boolean){
							 var rowNo = uploadTable.row($(thiss).closest('tr')).index();
							 $(thiss).css("pointer-events", "none");
							 $(thiss).html('<i class="fa fa-spinner fa-spin"></i>Processing');
					     	  thisbtn = thiss ;
					     	 
					     	 if(fileName.endsWith(".csv")){
					     		$("#delimeter").val(",");
					     		$("#delimeter").attr("readOnly","true");
					     		$("#delimeter").css("cursor","not-allowed");
					     		$("#uploadbtn").removeClass("continueProcess");
					     		upload_file(fileName,",");
					     		$("#uploadbtn").text("Submit");
					     	 }
					     	 else{
					     		$("#delimeter").removeAttr("readOnly");
					     		$("#delimeter").css("cursor","pointer");
					     		$("#fileTableMappingContainer").show();
					     		$("#uploadbtn").removeClass("finalUpload");
					     		$("#uploadbtn").addClass("continueProcess");
					     		$("#uploadbtn").text("continueProcess");
					     		$("#uploadbtn").attr("fileName",fileName);
					     		$('.continueProcess').click(function () {
					     			if($(this).hasClass("continueProcess")){
					     				if($("#delimeter").val() != ""){
					     					$("#uploadbtn").removeClass("continueProcess");
							     			$("#uploadbtn").text("Submit");
							     			upload_file(fileName,$("#delimeter").val());
					     				}
					     				else{
					     					$("#delimeter").next().text('Please Enter Delimeter').show().fadeOut(6000);
					     				}
					     			}
					     			
					     		});
					     		 }
					       /* setTimeout( 
					            function  (){  
					               	$(thisbtn).addClass("btn-success");
					               	$(thisbtn).removeClass("upload-url");
					                 $(thisbtn).html("uploaded sucessfully");
					                 if($('.upload-url').length == 0){
					                	 $(".uploadall").css("pointer-events", "none");
					                	 $(".uploadall").addClass("btn-success");
					                	 $(".uploadall").html("Uploaded all sucessfully");
					                 }
					            }, 7000);*/
					     
						 } 
					 }
					 
								 
							
						
					
				}	 
		 } );
}

function upload_file(fileName,delimeter){
	
	 checkFields(fileName,delimeter).done(function (data){
 		 if(data.filetable_mapping_id != null && data.filetable_mapping_id != 0){
 			$(thisbtn).addClass("btn-success");
           	$(thisbtn).removeClass("upload-url");
            $(thisbtn).html("uploaded sucessfully"); 
 		 }else{
 			$("#fileTableMappingContainer").show();
 			$("#fileTableMappingDiv").show();
 			$("#removedValuesDiv").show();
 			$("#uploadbtn").addClass("finalUpload");
 			csvFields = data.csvfields;
 			submitFileUpload();
 			fileTableMappingContainer(fileName,data.csvfields);
 		 }
 		});
}


function checkFields(fileName,delimeter){
	return $.ajax({
		type: 'POST',
		url: "checkfields",
		async: false,
		data:{
			"filename":fileName,
			"delimeter":delimeter
		},
		success : function(response){
						return response;
				}
			      
	 });//ajax
}

function fileTableMappingContainer(fileName,fields){
	$("#extraDelDiv div").not(':first').remove();
	//$("#fileInfo").attr("fileTblMapId",filetable_mapping_id);
	$("#fileInfo").attr("fileName",fileName);
	 
	
	var hiveTable = ["col1","col2","col3","col4"];
	var fileFields = ["f1","f2","f3","f4","f5"];
	prepareFileTableMapping(hiveTable,fields);
	/*$.ajax({
		type: 'POST',
		url: "getcsvfieldsbyid",
		async: false,
		data:{
			"filetable_mapping_id":filetable_mapping_id
		},
		success : function(response){
						if(response.csvfields != null && response.csvfields != undefined){
							prepareFileTableMapping(hiveTable,response.csvfields);
						}
						else{
							alert(fileName+" file data not available");
						}
				}
			      
	 });//ajax
*/	
}
var fileTableMapping_Table;
function prepareFileTableMapping(hiveTableFields,fileFields){
	var headerNames = ["hivetable","fileFields"];
	var head='<thead><tr><th><input type="checkbox" name="select_all" value="1" id="example-select-all"></th><th>hivetable</th><th>fileFields</th></tr></thead>';
	var footer='<tfoot><tr><th></th><th>hivetable</th><th>fileFields</th></tr></tfoot>';
	var data='';
	var dropdown = '<select class="fileFields">';
	$.each(fileFields,function(i,field){
		dropdown += "<option value='"+i+"'>"+field+"</option>";
	});
	dropdown += "</select>";
	$.each(hiveTableFields,function(index,field){
		data=data+'<tr><td></td>';
	    data=data+'<td>'+field+'</td>'+'<td>'+dropdown+'</td>';
	    data=data+'</tr>';
    });
	
	tableData='<table class="table table-striped table-bordered" style="width:100%" id="fileTableMapping" >'+head+data+'</tbody>'+footer+'</table>';

	$("#fileTableMappingDiv").append('<div>'+tableData+'</div>');

	fileTableMapping_Table =	$('#fileTableMapping').DataTable({
		"columnDefs": [ {
			"targets": 0,
			'searchable': false,
	         'orderable': false,
	         'className': 'dt-body-center',
			"data": null,
			"defaultContent": '<input type="checkbox" class="row-checkbox">'
			} ]
	,
    'order': [1, 'asc']
	});
			/*{
									//scrollY: 300,
								//	dom: 'Bfrtip',
									 // dom: 'lBrtip', //show length of entries
									"columnDefs": [ {
													"targets": -1,
													"data": ""+dropdown,
													"defaultContent": ""+dropdown
													} ]
									}); */
	$("#fileTableMappingDiv").show();
	$("#removedValuesDiv").show();
    	// Handle click on "Select all" control
	   $('#example-select-all').on('click', function(){
	      // Get all rows with search applied
	      var rows = fileTableMapping_Table.rows({ 'search': 'applied' }).nodes();
	      // Check/uncheck checkboxes for all rows in the table
	      $('input[type="checkbox"]', rows).prop('checked', this.checked);
	   });
	   
	   // Handle click on checkbox to set state of "Select all" control
	   $('#fileTableMapping tbody').on('change', 'input[type="checkbox"]', function(){
	      // If checkbox is not checked
	      if(!this.checked){
	         var el = $('#example-select-all').get(0);
	         // If "Select all" control is checked and has 'indeterminate' property
	         if(el && el.checked && ('indeterminate' in el)){
	            // Set visual state of "Select all" control
	            // as 'indeterminate'
	            el.indeterminate = true;
	         }
	      }
	else{
	 var el = $('#example-select-all').get(0);
	  if($(".row-checkbox").length == $(".row-checkbox:checked").length){
	    el.indeterminate = false;
	  }
	}
	   });
}
function validateCharacter(){
	//$('#delimeter, .extra-delimeters').unbind("click");
	$('#delimeter, .extra-delimeters').keyup(function () {
		  const key = event.key; // const
		if( !(key === "Backspace") ){
		if(this.value.length == 1){
		if(!validateCharacter(this.value)){
		$(this).val("");
		/*$.bootstrapGrowl("special characters only allowed122",{
            ele:$(this),//'#downloadmessage',
			type: 'danger',
            delay: 5000,
            // offset: {from: 'top', amount: 30},
            
        });*/
		$(this).next().text( "special characters only allowed");
		$(this).next().show().fadeOut(6000);
		}
		}
		else if(this.value.length > 1){
		console.log(this.value);
		this.value = this.value[0];
		$(this).next().text( "max 1 character only allowed");
		$(this).next().show().fadeOut(6000);
		//alert("max 1 character only allowed");
		}
		
		}
		else{
		}
		});
		function validateCharacter(char){
		     if (!char.match(/^(\d|[a-zA-z])+$/) || char.match(/\\/)) {
		     return true;
		    }
		}
}
function addDelimeters(){
	$("#extraDelDiv").append('<div class="row"><input class="extra-delimeters" type="text" maxlength="1" size="1"><span class="errorMsg"></span><span class="fa fa-minus-circle" aria-hidden="true" onclick ="removeDelimeter(this)" title="remove delimeter"></span><div>');
	validateCharacter();
}
function removeDelimeter(obj){
	$(obj).parent().remove();
}
$('#extraDelimeter').change(function(){
	 if(this.checked){
		 $("#addExtraDelimters").show();
	 }else{
		 $("#extraDelDiv div").not(':first').remove();
		 $(".extra-delimeters").val("");
		 $("#addExtraDelimters").hide();
		  } 
	});

function submitFileUpload() {
	$("#uploadbtn").unbind("click");
	$("#uploadbtn").click(function () {
			var isValid = validationsToSubmit();
			if(isValid){
					//var fileTblMapId = $("#fileInfo").attr("fileTblMapId");
					var fileName = $("#fileInfo").attr("fileName");
					
					var fileObj = {
							//"filetable_mapping_id":fileTblMapId,
							"filename": fileName,
							"delimeter":delimiter,
							"removed_values":removed_values,
							"csvmapped_index":csvmapped_index,
							"csvfields": csvFields
					};
					$.ajax({
						type:"POST",
						url:"upload",
						contentType:'application/json',
						async:false,
						data: JSON.stringify(fileObj),
						success: function (response){
							//alert(response);
							type = "success";msg = "Uploaded Sucessfully";
							if(response != "success"){
								type = "error";
								msg = "Not Uploaded, please try again";
							}
							Lobibox.alert(type, //AVAILABLE TYPES: "error", "info", "success", "warning"
									{
									msg: msg
									});
							
							originalFileTableMappingContainer(true);
							
						}
					});
			}
		
	});
}
var csvmapped_index = [];
var removed_values;
var delimiter = "";var csvFields = [];
function validationsToSubmit() {
	delimiter = $("#delimeter").val();
	
	var fieldsLength = $(".fileFields").length;
	var fileFields = [];
	$(".fileFields").each(function(){
		var val = $(this).val();
		var textContent = $("option:selected", $(this)).text();
		if(fileFields.indexOf(val) == -1){
			fileFields.push($(this).val());
			csvFields.push(textContent);
		}
	 });
	
	var extraDelimeters;
	var extraDelimeter = false;
	var extraDelimetersLength;
	if($("#extraDelimeter").prop('checked')==true){
		extraDelimeter = true;
		extraDelimeters = [];
		extraDelimetersLength = $(".extra-delimeters").length;
		$(".extra-delimeters").each(function(){
			var val = $(this).val();
			if(val != "" && fileFields.indexOf(val) == -1){
				extraDelimeters.push($(this).val());
			}
		 });
	}
	
	if(delimiter != "" && fieldsLength == fileFields.length && (!extraDelimeter || (extraDelimeter && extraDelimeters.length == $(".extra-delimeters").length))){
		csvmapped_index = fileFields;
		removed_values = extraDelimeters;
		return true;
	}
	else{
		if(delimiter == ""){
			alert("please enter delimeter");
		}
		if(fieldsLength != fileFields.length){
			alert("please select one unique fileFields for hiveTable coloumns");
		}
		if(extraDelimeter && extraDelimeters.length != extraDelimetersLength){
			alert("please fill extra delimeters");
		}
		return false;
	}
}
function originalFileTableMappingContainer(isUploaded){
	 $("#extraDelDiv div").not(':first').remove();
	 $(".extra-delimeters").val("");
	 $("#fileTableMappingDiv").empty();
	 $("#extraDelimeter").removeAttr("checked");
	 $("#delimeter").val("");
	 $("#addExtraDelimters, #fileTableMappingDiv, #removedValuesDiv").hide();
	 if(isUploaded){
		 	$(thisbtn).closest('tr').addClass("success");
			$(thisbtn).closest('td').removeClass("pending");
			$(thisbtn).closest('td').addClass("success");
			$(thisbtn).html('Uploaded Sucessfully');
			$("#fileTableMappingContainer").hide();
	 }
	 
}