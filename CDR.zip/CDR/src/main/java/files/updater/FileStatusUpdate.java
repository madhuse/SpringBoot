package files.updater;

import java.io.IOException;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import files.dao.FilesDAO;
import files.fileRead.FileRead;
import files.model.FileMapping;
import files.model.FilesLocation;
import files.model.ProcessFiles;
import files.services.FileService;
import files.vo.FileMappingVO;

@Service
public class FileStatusUpdate {
	private @Autowired FilesDAO filesDAO;
	private @Autowired FilesLocation location;
	private @Autowired FileService fileService;
	public void updateFileStatus(FileMapping fileMapping, String fileName) throws IOException {
		fileName="State Wise Colleges and Universities .csv";
		String to = location.getSuccessFiles() + fileName;
		String filePendingLocation = location.getPendingFiles() + fileName;

		fileMapping = new FileMapping();
		fileMapping.setFiletable_mapping_id(163);

		

		if (fileMapping.getFiletable_mapping_id() != null) {

			fileMapping.setDelimiter(',');
			fileMapping.setRemoved_values(new String[] { "d", "k" });
			fileMapping.setCsvmapped_index(new Integer[] { 3, 1 });

			fileMapping = filesDAO.updateFileMapping(fileMapping);
			List<ProcessFiles> processFiless=filesDAO.updateAllProcessFiles(fileMapping);
			for(ProcessFiles processFiles : processFiless){
				
				filePendingLocation = location.getPendingFiles() + processFiles.getFilename();
				
				FileRead.filesMoveing(filePendingLocation, to);
			
			}
			
			
		} else {
			
			FileRead.filesMoveing(filePendingLocation, to);
			
			fileMapping = filesDAO.fileMapping(fileMapping);

			fileService.setProcessFilesStatus(fileName, "success", fileMapping, "user",null);
		}
	}
	
	



}
