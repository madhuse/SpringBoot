package files.vo;

import java.util.Date;

public class ProcessFilesVO {
	private String fileName;
	private String status;
	private Date processedDate;
	private String statusMessage;
	private int failedFileIid;
	
	public String getFileName() {
		return fileName;
	}
	public void setFileName(String fileName) {
		this.fileName = fileName;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	public String getStatusMessage() {
		return statusMessage;
	}
	public void setStatusMessage(String statusMessage) {
		this.statusMessage = statusMessage;
	}
	public int getFailedFileIid() {
		return failedFileIid;
	}
	public Date getProcessedDate() {
		return processedDate;
	}
	public void setProcessedDate(Date processedDate) {
		this.processedDate = processedDate;
	}
	public void setFailedFileIid(int failedFileIid) {
		this.failedFileIid = failedFileIid;
	}
	@Override
	public String toString() {
		return "ProcessFilesVO [fileName=" + fileName + ", status=" + status + ", statusMessage=" + statusMessage
				+ ", processedDate=" + processedDate + ", failedFileIid=" + failedFileIid + "]";
	}
	
	
	
	
	
}
