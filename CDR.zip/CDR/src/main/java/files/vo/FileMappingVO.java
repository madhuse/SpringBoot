package files.vo;

import java.util.Arrays;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import org.hibernate.annotations.DynamicUpdate;
import org.hibernate.annotations.Type;
import org.hibernate.annotations.TypeDef;
import org.hibernate.annotations.TypeDefs;
import org.hibernate.type.CharacterArrayType;
import com.vladmihalcea.hibernate.type.array.IntArrayType;
import com.vladmihalcea.hibernate.type.array.StringArrayType;

public class FileMappingVO {
	private Integer filetableMappingId;
	private String fileName;
	private String[] csvFields;
	private Character delimeter;
	private Integer[] csvmappedIndex;
	private String[] removedValues;
	private String[] hiveFields;
	private String mobileNumber;
	public Integer getFiletableMappingId() {
		return filetableMappingId;
	}
	public void setFiletableMappingId(Integer filetableMappingId) {
		this.filetableMappingId = filetableMappingId;
	}
	public String getFileName() {
		return fileName;
	}
	public void setFileName(String fileName) {
		this.fileName = fileName;
	}
	public String[] getCsvFields() {
		return csvFields;
	}
	public void setCsvFields(String[] csvFields) {
		this.csvFields = csvFields;
	}
	public Character getDelimeter() {
		return delimeter;
	}
	public void setDelimeter(Character delimeter) {
		this.delimeter = delimeter;
	}
	public Integer[] getCsvmappedIndex() {
		return csvmappedIndex;
	}
	public void setCsvmappedIndex(Integer[] csvmappedIndex) {
		this.csvmappedIndex = csvmappedIndex;
	}
	public String[] getRemovedValues() {
		return removedValues;
	}
	public void setRemovedValues(String[] removedValues) {
		this.removedValues = removedValues;
	}
	public String[] getHiveFields() {
		return hiveFields;
	}
	public void setHiveFields(String[] strings) {
		this.hiveFields = strings;
	}
	public String getMobileNumber() {
		return mobileNumber;
	}
	public void setMobileNumber(String mobileNumber) {
		this.mobileNumber = mobileNumber;
	}
	@Override
	public String toString() {
		return "FileMappingVO [filetableMappingId=" + filetableMappingId + ", fileName=" + fileName + ", csvFields="
				+ Arrays.toString(csvFields) + ", delimeter=" + delimeter + ", csvmappedIndex="
				+ Arrays.toString(csvmappedIndex) + ", removedValues=" + Arrays.toString(removedValues)
				+ ", hiveFields=" + Arrays.toString(hiveFields) + ", mobileNumber=" + mobileNumber + "]";
	}
	
	

}
