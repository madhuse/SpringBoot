package files.model;

import java.util.Date;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import org.hibernate.annotations.DynamicUpdate;

@Entity
@Table(name = "failed_files")
@DynamicUpdate
public class FailedFiles {
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private Integer failed_file_id;
	private String failed_message;
	private Integer file_id;
	private Date failed_date;
	private String filename;
	private String duplicate_filename;
	
	
	
	public FailedFiles() {
		super();
		// TODO Auto-generated constructor stub
	}
	public FailedFiles(Integer failed_file_id, String failed_message, Integer file_id, Date failed_date,
			String filename, String duplicate_filename) {
		super();
		this.failed_file_id = failed_file_id;
		this.failed_message = failed_message;
		this.file_id = file_id;
		this.failed_date = failed_date;
		this.filename = filename;
		this.duplicate_filename = duplicate_filename;
	}
	public Integer getFailed_file_id() {
		return failed_file_id;
	}
	public void setFailed_file_id(Integer failed_file_id) {
		this.failed_file_id = failed_file_id;
	}
	public String getFailed_message() {
		return failed_message;
	}
	public void setFailed_message(String failed_message) {
		this.failed_message = failed_message;
	}
	public Integer getFile_id() {
		return file_id;
	}
	public void setFile_id(Integer file_id) {
		this.file_id = file_id;
	}
	public Date getFailed_date() {
		return failed_date;
	}
	public void setFailed_date(Date failed_date) {
		this.failed_date = failed_date;
	}
	public String getFilename() {
		return filename;
	}
	public void setFilename(String filename) {
		this.filename = filename;
	}
	public String getDuplicate_filename() {
		return duplicate_filename;
	}
	public void setDuplicate_filename(String duplicate_filename) {
		this.duplicate_filename = duplicate_filename;
	}
	@Override
	public String toString() {
		return "FailedFiles [failed_file_id=" + failed_file_id + ", failed_message=" + failed_message + ", file_id="
				+ file_id + ", failed_date=" + failed_date + ", filename=" + filename + ", duplicate_filename="
				+ duplicate_filename + "]";
	}
	
	
	

}
