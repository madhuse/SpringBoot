package files.model;

import java.util.Arrays;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import org.hibernate.annotations.DynamicUpdate;
import org.hibernate.annotations.Type;
import org.hibernate.annotations.TypeDef;
import org.hibernate.annotations.TypeDefs;
import org.hibernate.type.CharacterArrayType;
import com.vladmihalcea.hibernate.type.array.IntArrayType;
import com.vladmihalcea.hibernate.type.array.StringArrayType;

@Entity
@Table(name = "filetable_mapping")
@TypeDefs({ @TypeDef(name = "string-array", typeClass = StringArrayType.class),
		@TypeDef(name = "Integer-array", typeClass = IntArrayType.class),
		@TypeDef(name = "Character-array", typeClass = CharacterArrayType.class)
		})
@DynamicUpdate
public class FileMapping {
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private Integer filetable_mapping_id;

	@Type(type = "string-array")
	@Column(name = "csvfields", columnDefinition = "text[]")
	
	private String[] csvfields;

	private Character delimiter;

	@Type(type = "Integer-array")
	@Column(name = "csvmapped_index", columnDefinition = "Integereger[]")
	private Integer[] csvmapped_index;
	
	@Type(type = "string-array")
	@Column(name = "removed_values", columnDefinition = "text[]")
	private String[] removed_values;
	
	

	public String[] getRemoved_values() {
		return removed_values;
	}

	public void setRemoved_values(String[] removed_values) {
		this.removed_values = removed_values;
	}

	public Integer getFiletable_mapping_id() {
		return filetable_mapping_id;
	}

	public void setFiletable_mapping_id(Integer filetable_mapping_id) {
		this.filetable_mapping_id = filetable_mapping_id;
	}

	public String[] getCsvfields() {
		return csvfields;
	}

	public void setCsvfields(String[] csvfields) {
		this.csvfields = csvfields;
	}

	public Character getDelimiter() {
		return delimiter;
	}

	public void setDelimiter(Character delimiter) {
		this.delimiter = delimiter;
	}

	public Integer[] getCsvmapped_index() {
		return csvmapped_index;
	}

	public void setCsvmapped_index(Integer[] csvmapped_index2) {
		this.csvmapped_index = csvmapped_index2;
	}

	@Override
	public String toString() {
		return "FileMapping [filetable_mapping_id=" + filetable_mapping_id + ", csvfields=" + Arrays.toString(csvfields)
				+ ", delimiter=" + delimiter + ", csvmapped_index=" + Arrays.toString(csvmapped_index)
				+ ", removed_values=" + Arrays.toString(removed_values) + "]";
	}

	

	/*@ManyToOne
	@JoinColumn(name = "processedfileid")
	private ProcessFiles processFiles;*/
	// private Integer fileid;

	/*public ProcessFiles getProcessFiles() {
		return processFiles;
	}

	public void setProcessFiles(ProcessFiles processFiles) {
		this.processFiles = processFiles;
	}*/
	/*
	 * public Integer getFileid() { return fileid; }
	 * 
	 * public void setFileid(Integer fileid) { this.fileid = fileid; }
	 */

}
