package files.model;

import java.util.Date;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Transient;

import org.hibernate.annotations.DynamicUpdate;

@Entity
@Table(name = "processed_files")
@DynamicUpdate
public class ProcessFiles {
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private Integer processedfileid;
	private String filename;
	private String status;
	private Date processedtime;
	private String createdby;
	private Integer filetable_mapping_id;
	private String mobilenumber;
	@Transient
	private String failedMsg;
	
	public String getMobilenumber() {
		return mobilenumber;
	}
	public void setMobilenumber(String mobilenumber) {
		this.mobilenumber = mobilenumber;
	}
	public Integer getFiletable_mapping_id() {
		return filetable_mapping_id;
	}

	public void setFiletable_mapping_id(Integer filetable_mapping_id) {
		this.filetable_mapping_id = filetable_mapping_id;
	}

	public Integer getProcessedfileid() {
		return processedfileid;
	}

	public void setProcessedfileid(Integer processedfileid) {
		this.processedfileid = processedfileid;
	}

	public String getFilename() {
		return filename;
	}

	public void setFilename(String filename) {
		this.filename = filename;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public Date getProcessedtime() {
		return processedtime;
	}

	public void setProcessedtime(Date processedtime) {
		this.processedtime = processedtime;
	}

	public String getCreatedby() {
		return createdby;
	}

	public void setCreatedby(String createdby) {
		this.createdby = createdby;
	}
	public String getFailedMsg() {
		return failedMsg;
	}

	public void setFailedMsg(String failedMsg) {
		this.failedMsg = failedMsg;
	}
	@Override
	public String toString() {
		return "ProcessFiles [processedfileid=" + processedfileid + ", filename=" + filename + ", status=" + status
				+ ", processedtime=" + processedtime + ", createdby=" + createdby + ", filetable_mapping_id="
				+ filetable_mapping_id + ", mobilenumber=" + mobilenumber + ", failedMsg=" + failedMsg + "]";
	}

	
	

}
