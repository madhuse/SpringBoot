package files.model;



public class FilesLocation {
	private String officeLoc;
	private String dumpedFiles;
	private String csvFiles;
	private String excelFiles;
	private String testFiles;
	private String pendingFiles;
	private String successFiles;
	private String failedFiles;
	private String csvfilesToUpload;
	private String processedFiles;
	public String getOfficeLoc() {
		return officeLoc;
	}

	public void setOfficeLoc(String officeLoc) {
		this.officeLoc = officeLoc;
	}

	public String getDumpedFiles() {
		return dumpedFiles;
	}

	public void setDumpedFiles(String dumpedFiles) {
		this.dumpedFiles = dumpedFiles;
	}

	public String getCsvFiles() {
		return csvFiles;
	}

	public void setCsvFiles(String csvFiles) {
		this.csvFiles = csvFiles;
	}

	public String getExcelFiles() {
		return excelFiles;
	}

	public void setExcelFiles(String excelFiles) {
		this.excelFiles = excelFiles;
	}

	public String getTestFiles() {
		return testFiles;
	}

	public void setTestFiles(String testFiles) {
		this.testFiles = testFiles;
	}

	public String getPendingFiles() {
		return pendingFiles;
	}

	public void setPendingFiles(String pendingFiles) {
		this.pendingFiles = pendingFiles;
	}

	public String getSuccessFiles() {
		return successFiles;
	}

	public void setSuccessFiles(String successFiles) {
		this.successFiles = successFiles;
	}

	public String getFailedFiles() {
		return failedFiles;
	}

	public void setFailedFiles(String failedFiles) {
		this.failedFiles = failedFiles;
	}

	public String getCsvfilesToUpload() {
		return csvfilesToUpload;
	}

	public void setCsvfilesToUpload(String csvfilesToUpload) {
		this.csvfilesToUpload = csvfilesToUpload;
	}

	public String getProcessedFiles() {
		return processedFiles;
	}

	public void setProcessedFiles(String processedFiles) {
		this.processedFiles = processedFiles;
	}

	
}
