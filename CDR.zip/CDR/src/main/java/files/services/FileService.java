package files.services;

import java.io.File;
import java.io.IOException;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import files.dao.FilesDAO;
import files.dao.HiveDao;
import files.exception.FieldsLengthException;
import files.fileRead.FileRead;
import files.model.FailedFiles;
import files.model.FileMapping;
import files.model.FilesLocation;
import files.model.ProcessFiles;
import files.vo.FileMappingVO;
import files.vo.ProcessFilesVO;

@Repository
public class FileService {
	private  	@Autowired FileRead fileRead;
	private 	@Autowired FilesLocation location;
	private 	@Autowired HiveDao hiveDao;
	private 	@Autowired FilesDAO filesDAO;
	
	
	
	public List<ProcessFilesVO> getProcessFiles() {
		List<ProcessFilesVO> filesInfo =  new ArrayList<>();
		
		List<ProcessFiles> files = filesDAO.getFileNames();
		for (ProcessFiles file : files) {
			ProcessFilesVO newFile =new ProcessFilesVO();
			newFile.setFileName(file.getFilename());
			newFile.setStatus(file.getStatus());
			newFile.setStatusMessage(file.getFailedMsg());
			newFile.setProcessedDate(file.getProcessedtime());
			filesInfo.add(newFile);
		}
		
		List<ProcessFilesVO> failedFiels = filesDAO.getFailedFiels();
		filesInfo.addAll(failedFiels);
		
		return filesInfo;
	}
	
	public void updateFileAsFailed(String fileName,String failedMsg) throws IOException{
		ProcessFiles processFile =new ProcessFiles();
		processFile.setFilename(fileName);
		processFile.setStatus("failed");
		processFile.setCreatedby("user");
		//ProcessFiles updatedProcessFile = filesDAO.updateProcessFilesStatus(processFile);
		ProcessFiles fileInfo = filesDAO.getFileInfo(fileName);
		filesDAO.deleteObjById(ProcessFiles.class, fileInfo.getProcessedfileid());
		String duplicateFilename = fileRead.getFileName(location.getFailedFiles(), fileName);
		String to = location.getFailedFiles() + duplicateFilename;
		FailedFiles failedFilesStatus = filesDAO.failedFilesStatus(failedMsg, fileName,duplicateFilename);
		FileRead.filesMoveing(location.getPendingFiles()+fileName,  to);
	}
	
	public FileMappingVO 	uploadFile(String fileName,char delimeter) throws IOException{
		String from = location.getPendingFiles()+fileName;
		System.out.println("from "+from+" delimeter "+delimeter);
		ArrayList<Object> displayInfo = fileRead.displayInfo(from, delimeter);
		String[] fields = (String[]) displayInfo.get(0);
		String mobileNumber =  (String) displayInfo.get(1);
		
		System.out.println(fields+" fields");
		System.out.println(fields.length);
		FileMappingVO fileVO = new FileMappingVO();
		try {
			FileMapping	 existedCSVFields = fileRead.getExistedCSVFields(fields);
			Integer filetable_mapping_id = existedCSVFields.getFiletable_mapping_id();
			if(filetable_mapping_id != null && filetable_mapping_id != 0){
				FileMappingVO  fileMappingVO = new FileMappingVO();
				fileMappingVO.setFiletableMappingId(filetable_mapping_id);
				fileMappingVO.setFileName(fileName);
				updateFileStatus(fileMappingVO);
				//return "Uploaded sucessfully";
				fileVO.setFiletableMappingId(filetable_mapping_id);
			}
			else{
				fileVO.setMobileNumber(mobileNumber);
				fileVO.setCsvFields(fields);
				}
			fileVO.setHiveFields(hiveDao.getColumns());
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return fileVO;
	}
	public void updateFileStatus(FileMappingVO  fileMappingVO) throws IOException {
		String fileName = fileMappingVO.getFileName();
		String to = location.getSuccessFiles() + fileName;
		String filePendingLocation = location.getPendingFiles() + fileName;
		
		if(fileMappingVO.getDelimeter() != null && fileMappingVO.getFiletableMappingId() == null || fileMappingVO.getFiletableMappingId() == 0){
			FileMapping fileMapping = new FileMapping();
			fileMapping = new FileMapping();
		    fileMapping.setCsvmapped_index(fileMappingVO.getCsvmappedIndex());
			fileMapping.setDelimiter(fileMappingVO.getDelimeter());
			fileMapping.setRemoved_values(fileMappingVO.getRemovedValues());
			fileMapping.setCsvfields(fileMappingVO.getCsvFields());
			fileMapping = filesDAO.fileMapping(fileMapping);
			fileMappingVO.setFiletableMappingId(fileMapping.getFiletable_mapping_id());
		}
		
		
			ProcessFiles processFile =new ProcessFiles();
			processFile.setFilename(fileName);
			processFile.setFiletable_mapping_id(fileMappingVO.getFiletableMappingId());
			processFile.setStatus("success");
			processFile.setCreatedby("user");
			processFile.setMobilenumber(fileMappingVO.getMobileNumber());
			filesDAO.updateProcessFilesStatus(processFile);
			//String to = fileRead.getFilesDirectory(location.getSuccessFiles(), fileName);
			FileRead.filesMoveing(filePendingLocation, to);
			
	}	

	/*public ProcessFiles setProcessFilesStatus(String fileName, String processFileStatus, FileMapping fileMapping,String updatedBy) {
		ProcessFiles processFiles = new ProcessFiles();

		ProcessFiles fileInfo = filesDAO.getFileInfo(fileName);
		if(fileInfo != null){
			processFiles.setProcessedfileid(fileInfo.getProcessedfileid());//in order to update existing file
		}
		processFiles.setCreatedby(updatedBy);
		processFiles.setFilename(fileName);
		processFiles.setStatus(processFileStatus);
		processFiles.setFiletable_mapping_id(fileMapping.getFiletable_mapping_id());
		processFiles.setProcessedtime(new Date());

		return filesDAO.processFiles(processFiles);
	}*/

	public ProcessFiles setProcessFilesStatus(String fileName, String processFileStatus, FileMapping fileMapping,String updatedBy ,String mobileNumber) {
		ProcessFiles processFiles = new ProcessFiles();

		/*ProcessFiles fileInfo = filesDAO.getFileInfo(fileName);
		if(fileInfo != null){
			processFiles.setProcessedfileid(fileInfo.getProcessedfileid());//in order to update existing file
		}*/
		processFiles.setCreatedby(updatedBy);
		processFiles.setFilename(fileName);
		processFiles.setStatus(processFileStatus);
		processFiles.setFiletable_mapping_id(fileMapping.getFiletable_mapping_id());
		processFiles.setProcessedtime(new Date());
		processFiles.setMobilenumber(mobileNumber);
		return filesDAO.processFiles(processFiles);
	}
	
	public ProcessFiles getFileInfo(String fileName){
		return filesDAO.getFileInfo(fileName);
	}
	public String replaceFile(int failedFileId) {
		//get original filename from failedfile by id
		FailedFiles replacedFile = (FailedFiles) filesDAO.getObjById(FailedFiles.class, failedFileId);
		
		String fileName = replacedFile.getFilename();
		//get that processed file
		ProcessFiles existingFile = (ProcessFiles) filesDAO.getFileInfo(fileName);
		String currentFileLocation =  location.getFailedFiles()+replacedFile.getDuplicate_filename();
		String toLocation =  location.getProcessedFiles()+existingFile.getStatus()+"_files/"+fileName;
		
		Character delimeter = null;
		
		Boolean updateTime = false;
			
		
		if(existingFile.getStatus().equals("success")){
			String oldFileCsvFields[] = null;
			FileMapping fileMapping = (FileMapping) filesDAO.getObjById(FileMapping.class, existingFile.getFiletable_mapping_id());
			oldFileCsvFields = fileMapping.getCsvfields();
			delimeter = fileMapping.getDelimiter();
			String[] currentFileFields = (String[]) fileRead.displayInfo(currentFileLocation, delimeter).get(0);
			if(currentFileFields!=null && Arrays.equals(currentFileFields, oldFileCsvFields)){
				//data updation code comes here
				updateTime = true;
			}
			else if(currentFileFields!=null && currentFileFields.length >= hiveDao.getColumns().length){
				try {
					FileRead.filesMoveing(currentFileLocation, toLocation);
					filesDAO.deleteObjById(ProcessFiles.class, existingFile.getProcessedfileid());
					fileRead.fileMapping(fileName, location.getProcessedFiles()+existingFile.getStatus()+"_files/", delimeter);
				
				} catch (IOException | SQLException | FieldsLengthException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
					return fileName+" File Not replaced ..Due to some errors";
				}
					
			}
			
		}
		else{
			//file in pending status
			updateTime = true;
		}
		
		if(updateTime){
			existingFile.setProcessedtime(new Date());
			existingFile.setCreatedby("user");
			System.out.println(existingFile);
			filesDAO.saveOrUpdate(existingFile);
			try {
				FileRead.filesMoveing(currentFileLocation, toLocation);
				
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
				return fileName+" File Not replaced ..Due to some errors";
			}
		}
		
		/*return  fileName+" File Replaced sucessfully";
		} catch (IOException | SQLException | FieldsLengthException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			return fileName+" File Not replaced ..Due to some errors";
		}*/
		filesDAO.deleteObjById(FailedFiles.class, failedFileId);
		return  fileName+" File Replaced sucessfully";	
	}

	public void removeFailedFile(int failedFileId) throws IOException {
		FailedFiles failedFile = (FailedFiles) filesDAO.getObjById(FailedFiles.class, failedFileId);
			filesDAO.deleteObjById(FailedFiles.class,failedFileId);
			String fileLocation = location.getFailedFiles()+failedFile.getDuplicate_filename();
			fileRead.fileDeletion(fileLocation);
	}
	public void renameFile(String newName,int failedFileId) throws IOException{
		FailedFiles failedFile = (FailedFiles) filesDAO.getObjById(FailedFiles.class, failedFileId);
		String fileName = failedFile.getFilename();
		newName = newName+fileName.substring(fileName.lastIndexOf("."));
		System.out.println("new Name "+newName);
		//filesDAO.deleteObjById(FailedFiles.class, failedFileId);
		String duplicateName = failedFile.getDuplicate_filename();
		String oldFileNameWithLocation= location.getFailedFiles()+duplicateName;
		fileRead.fileRename(oldFileNameWithLocation, newName);
		if(duplicateName.endsWith(".txt")){
			setProcessFilesStatus(newName, "pending", new FileMapping(), "system",null);
			String pendingFileLocation = location.getPendingFiles() + newName;
			String fileNewLocation =  location.getFailedFiles()+duplicateName;
			FileRead.filesMoveing(fileNewLocation, pendingFileLocation);
		}
		else{
			try {
				fileRead.fileMapping(newName, location.getFailedFiles(), ',');
				filesDAO.deleteObjById(FailedFiles.class, failedFileId);
			} catch (SQLException e) {
				e.printStackTrace();
				FailedFiles file= new FailedFiles(failedFileId,"other Exception",null,new Date(),newName,newName);
				file =  filesDAO.saveOrUpdate(file);
				System.out.println("Rename file Updated "+file);
				//filesDAO.failedFilesStatus("other Exception",newName, newName);
			} catch (FieldsLengthException e) {
				FailedFiles file= new FailedFiles(failedFileId,"File fields are lessthan Table Fields",null,new Date(),newName,newName);
				file =  filesDAO.saveOrUpdate(file);
				System.out.println("Rename file Updated "+file);
				e.printStackTrace();
			}
		}
		
		
	}
	
	

	
}
