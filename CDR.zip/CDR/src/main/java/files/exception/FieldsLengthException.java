package files.exception;



public class FieldsLengthException extends Exception {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	@Override
	public String getMessage() {
		
		return "File Feilds < Hive Fields ";
	}
}
