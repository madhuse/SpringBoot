package files.controller;

import java.io.IOException;
import java.sql.SQLException;
import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.ResponseBody;

import files.exception.FieldsLengthException;
import files.model.ProcessFiles;
import files.services.FileService;
import files.updater.FileStatusUpdate;
import files.vo.FileMappingVO;
import files.vo.ProcessFilesVO;

@Controller
public class FilesController {
	private  @Autowired FileService  fileService;
	private  @Autowired FileStatusUpdate fileStatusUpdate;
	
	@GetMapping("/getProcessFiles")
	public @ResponseBody List<ProcessFilesVO> getProcessFiles() {
		
		List<ProcessFilesVO> processFiles = fileService.getProcessFiles();
		
		return processFiles;
	}
	@PostMapping("/checkfields")
	public @ResponseBody FileMappingVO checkFields(HttpServletRequest servletRequest) {
		
		
		String fileName = servletRequest.getParameter("fileName");
		char delimeter = servletRequest.getParameter("delimeter").charAt(0);
		
		FileMappingVO file;
		try {
			file = fileService.uploadFile(fileName, delimeter);
			return file;
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			return null;
		}
		
	}
	
	@PostMapping("/upload") // new annotation since 4.3
	public @ResponseBody String singleFileUpload( @RequestBody FileMappingVO fileMappingVO){
		try {
			fileService.updateFileStatus(fileMappingVO);
			return "success";
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			return "failed";
		}
		
	}
	
	@PostMapping("/updateFileAsFailed")
	public @ResponseBody String updateFileAsFailed(HttpServletRequest servletRequest) {
		
		String fileName = servletRequest.getParameter("fileName");
		String failedMsg  = servletRequest.getParameter("failedMessage");
		
		try {
			fileService.updateFileAsFailed(fileName, failedMsg);
			return failedMsg;
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			return "File Related Error";
		}
		
	}
	
	@PostMapping("/getfileinfo") // new annotation since 4.3
	public @ResponseBody ProcessFiles singleFileUpload( HttpServletRequest httpServletRequest){
		String fileName = httpServletRequest.getParameter("filename");
		return fileService.getFileInfo(fileName);
	}
	
	
	
	@PostMapping("/renamefile")
	public @ResponseBody String renameFile(HttpServletRequest servletRequest) throws NumberFormatException, IOException, SQLException, FieldsLengthException {
		
		
		String fileName = servletRequest.getParameter("newFileName");
		String failedFileId = servletRequest.getParameter("failedFileId");
		
		fileService.renameFile(fileName,Integer.parseInt(failedFileId));
		return "File Related Error";
	}
	@PostMapping("/replacefile")
	public @ResponseBody String replaceFile(HttpServletRequest servletRequest){
		
		
		String failedFileId = servletRequest.getParameter("failedFileId");
		
		
			return fileService.replaceFile(Integer.parseInt(failedFileId));
		
		
	}
	@PostMapping("/removefile")
	public @ResponseBody String removeFile(HttpServletRequest servletRequest) {
		
		
		String fileName = servletRequest.getParameter("fileName");
		String failedFileId = servletRequest.getParameter("failedFileId");
		try {
			fileService.removeFailedFile(Integer.parseInt(failedFileId));
			return "File Removed Successfully";
		} catch (NumberFormatException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return "Failed To Remove File";
		
		
	}
	
	
}
