package files.dao;

import java.util.Arrays;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.PropertySource;

@Configuration
@PropertySource(value="classpath:hive.properties")
public class HiveDao {
	@Value("#{'${hive.columns}'}") //.split(',')
	private String [] columns;
	
	
	public String[] getColumns() {
		return columns;
	}
	public void setColumns(String[] columns) {
		this.columns = columns;
	}


	@Override
	public String toString() {
		return "HiveDao [columns=" + Arrays.toString(columns) + "]";
	}
	
	
}
