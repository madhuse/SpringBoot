package files.dao;

import java.util.List;


import org.hibernate.Criteria;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.criterion.Restrictions;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import files.model.FileMapping;

@Transactional
@Repository
public class FileTableMappingDAO {
	private @Autowired JdbcTemplate jdbcTemplate;
	private @Autowired SessionFactory sessionFactory;
	private Session session;

	
	public List<FileMapping> 	getCsvFieldsById(int filetable_mapping_id){
		session = sessionFactory.getCurrentSession();
		Criteria cr = session.createCriteria(FileMapping.class);
		cr.add(Restrictions.eq("filetable_mapping_id", filetable_mapping_id));
		List<FileMapping> filetable_mapping = cr.list();
		
			return filetable_mapping;
	}

}
