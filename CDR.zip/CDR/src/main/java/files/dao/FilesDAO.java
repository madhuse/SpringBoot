package files.dao;

import java.io.Serializable;
import java.sql.Array;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.stream.Collectors;

import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaUpdate;
import javax.persistence.criteria.Predicate;
import javax.persistence.criteria.Root;

import org.apache.poi.ss.formula.functions.T;
import org.hibernate.Criteria;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.criterion.Restrictions;
import org.hibernate.mapping.Collection;
import org.hibernate.query.Query;
import org.hibernate.transform.Transformers;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataAccessException;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.PreparedStatementCallback;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import files.model.FailedFiles;
import files.model.FileMapping;
import files.model.ProcessFiles;
import files.vo.ProcessFilesVO;

@Transactional
@Repository
public class FilesDAO {
	private @Autowired JdbcTemplate jdbcTemplate;
	private @Autowired SessionFactory sessionFactory;
	private Session session;

	public ProcessFiles processFiles(ProcessFiles processFiles) {

		session = sessionFactory.getCurrentSession();
		session.saveOrUpdate(processFiles);
		return processFiles;

	}

	public FileMapping fileMapping(FileMapping fileMapping) {

		session = sessionFactory.getCurrentSession();
		session.saveOrUpdate(fileMapping);		
		return fileMapping;

	}

	public <T> T saveOrUpdate(Object obj){
		 T  originalObject = (T) obj;
		 System.out.println(originalObject);
		session = sessionFactory.getCurrentSession();
		session.saveOrUpdate(originalObject);
		return originalObject;
	} 

	public FileMapping getDBCSVFields(String[] csvFields) throws SQLException {

		FileMapping fileMapping = null;
		
			Connection con = jdbcTemplate.getDataSource().getConnection();

			Array dbCsvFields = con.createArrayOf("text", csvFields);

			String SELECT_QUERY = "SELECT csvfields,delimiter,csvmapped_index,removed_values,filetable_mapping_id "
					+ " FROM public.filetable_mapping where csvfields = ? ";

			System.out.println(csvFields);
			System.out.println(SELECT_QUERY);

			PreparedStatement pstmt = con.prepareStatement(SELECT_QUERY);

			pstmt.setArray(1, dbCsvFields);

			ResultSet rs = pstmt.executeQuery();

			fileMapping = new FileMapping();

			while (rs.next()) {
				String[] dbCSVFields = (String[]) rs.getArray(1).getArray();
				char delimiter = 0;
				Integer[] csvmapped_index = null;
				String[] removed_values = null;
				if (rs.getString(2) != null) {
					delimiter = rs.getString(2).charAt(0);

					csvmapped_index = (Integer[]) rs.getArray(3).getArray();
					if(rs.getArray(4) != null){
					removed_values = (String[]) rs.getArray(4).getArray();
					}
				}
				int filetable_mapping_id = rs.getInt(5);

				fileMapping.setFiletable_mapping_id(filetable_mapping_id);
				fileMapping.setCsvfields(dbCSVFields);
				fileMapping.setCsvmapped_index(csvmapped_index);
				fileMapping.setDelimiter(delimiter);
				fileMapping.setRemoved_values(removed_values);
			}
			pstmt.close();
			rs.close();
			con.close();

		

		return fileMapping;
	}

	public List<ProcessFiles> updateAllProcessFiles(FileMapping fileMapping) {
		
		session = sessionFactory.getCurrentSession();
		
	String UPDATE_QUERY="UPDATE public.processed_files "+
							"SET status='success' , createdby='user' WHERE filetable_mapping_id = "+fileMapping.getFiletable_mapping_id();
		System.out.println(UPDATE_QUERY);
		
		Query query =session.createQuery(UPDATE_QUERY).setResultTransformer(Transformers.aliasToBean(ProcessFiles.class));	
					
		List<ProcessFiles> ProcessFiless=query.list();
		
		
		return ProcessFiless;
	}
	
	public FileMapping updateFileMapping(FileMapping fileMapping){
		
		session = sessionFactory.getCurrentSession();
		
		CriteriaBuilder builder = session.getCriteriaBuilder();
		CriteriaUpdate<FileMapping> criteria = builder.createCriteriaUpdate(FileMapping.class);
		Root<FileMapping> root = criteria.from(FileMapping.class);
		criteria.set(root.get("delimiter"), fileMapping.getDelimiter());
		criteria.set(root.get("csvmapped_index"), fileMapping.getCsvmapped_index());
		criteria.set(root.get("removed_values"), fileMapping.getRemoved_values());
		criteria.where(builder.equal(root.get("filetable_mapping_id"),fileMapping.getFiletable_mapping_id()));
		
		session.createQuery(criteria).executeUpdate();
		
		return fileMapping;
	}

	public List<ProcessFiles> getFileNames(){
		session = sessionFactory.getCurrentSession();
		Criteria cr = session.createCriteria(ProcessFiles.class);
		List<ProcessFiles> processed_files = cr.list();
		return processed_files;
	}
	
	public List<ProcessFilesVO> getFailedFiels(){
		List<ProcessFilesVO> failedFiles = new ArrayList<>();
		String getDuplicateFiles = "SELECT prosf.filename AS \"fileName\", COALESCE( 'failed') as status, failed_message AS \"statusMessage\",failed_date AS \"processedDate\",failed_file_id AS \"failedFileIid\" FROM processed_files  prosf JOIN failed_files penf ON prosf.processedfileid = penf.file_id order by failed_date";
		String getFailedFiles = "SELECT filename AS \"fileName\", COALESCE('failed') as \"status\", failed_message AS \"statusMessage\",failed_date AS \"processedDate\",failed_file_id AS \"failedFileIid\" FROM failed_files";
		session = sessionFactory.getCurrentSession();
		Query duplicateFilesQuery = session.createSQLQuery(getDuplicateFiles).setResultTransformer(Transformers.aliasToBean(ProcessFilesVO.class));
		List<ProcessFilesVO> duplicateFilesQueryList = duplicateFilesQuery.list();
		
		Query failedFilesQuery = session.createSQLQuery(getFailedFiles).setResultTransformer(Transformers.aliasToBean(ProcessFilesVO.class));
		List<ProcessFilesVO> failedFilesList = failedFilesQuery.list();
		
		failedFiles.addAll(duplicateFilesQueryList);
		failedFiles.addAll(failedFilesList);
		
		return failedFiles;
	}

	public ProcessFiles getFileInfo(String fileName){
		ProcessFiles list = null;
		session = sessionFactory.getCurrentSession();
		Criteria cr = session.createCriteria(ProcessFiles.class);
		cr.add(Restrictions.eq("filename", fileName));
		
		Object uniqueResult = cr.uniqueResult();
		if(uniqueResult != null){
			 list = (ProcessFiles) uniqueResult;
		}
		return list;
	}
	public ProcessFiles updateProcessFilesStatus(ProcessFiles processFile){
		session = sessionFactory.getCurrentSession();
		Criteria cr = session.createCriteria(ProcessFiles.class);
		cr.add(Restrictions.eq("filename", processFile.getFilename()));
		List<ProcessFiles> list = cr.list();
		ProcessFiles processFiles = list.get(0);
		processFiles.setStatus(processFile.getStatus());
		processFiles.setCreatedby(processFile.getCreatedby());
		processFiles.setFiletable_mapping_id(processFile.getFiletable_mapping_id());
		processFiles.setMobilenumber(processFile.getMobilenumber());
		processFiles.setProcessedtime(new Date());
		return processFiles;
	}
	public void updateFileTableMapping(FileMapping updateFileMapping){
		 FileMapping fileMapping = session.get(FileMapping.class, updateFileMapping.getFiletable_mapping_id());
		 fileMapping.setDelimiter(updateFileMapping.getDelimiter());
		 fileMapping.setRemoved_values(updateFileMapping.getRemoved_values());
		 fileMapping.setCsvmapped_index(updateFileMapping.getCsvmapped_index());
		 session.update(fileMapping);
	}
	/*public List<FailedFiles> getFailedFile_byId(Integer file_id){
		session = sessionFactory.getCurrentSession();
		Criteria cr = session.createCriteria(FailedFiles.class);
		cr.add(Restrictions.eq("file_id", file_id));
		List<FailedFiles> list = cr.list();
		return list;
	}*/
	public FailedFiles failedFilesStatus(String message,String fileName,String duplicateFilename) {
		
		FailedFiles failedFile=new FailedFiles();
		
		failedFile.setFilename(fileName);
		failedFile.setFailed_date(new Date());
		failedFile.setFailed_message(message);
		//failedFile.setFile_id(processFiles.getProcessedfileid());
		failedFile.setDuplicate_filename(duplicateFilename);
		session = sessionFactory.getCurrentSession();
		session.saveOrUpdate(failedFile);		
		return failedFile;
	}

	public Object getObjById(Class obj, int id) {
		session = sessionFactory.getCurrentSession();
		Object object = session.get(obj,id);
		 return  object;
		 }
	public void deleteObjById(Class removedObj, int fileId) {
		session = sessionFactory.getCurrentSession();
		 Object object = session.get(removedObj,fileId);
		 session.delete(object);
	}
	
	
	
	public boolean removeFailedFile(int failedFileId) {
		// TODO Auto-generated method stub
		session = sessionFactory.getCurrentSession();
		FailedFiles failedFile = session.get(FailedFiles.class, failedFileId);
		String failedMessage = failedFile.getFailed_message();
		if(failedMessage.equals("File fields are lessthan Table Fields")){
			deleteObjById(ProcessFiles.class,failedFile.getFile_id());
			//that file related data also deletion required
			return true;
		}
		else{
			session.delete(failedFile);
			return true;	
		}
		
	}
	
}
