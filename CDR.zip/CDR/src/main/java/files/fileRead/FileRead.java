package files.fileRead;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.StandardCopyOption;
import java.sql.SQLException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.Iterator;

import org.apache.poi.hssf.usermodel.HSSFCell;
import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.openxml4j.exceptions.InvalidFormatException;
import org.apache.poi.openxml4j.opc.OPCPackage;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import au.com.bytecode.opencsv.CSVReader;
import files.dao.FilesDAO;
import files.dao.HiveDao;
import files.exception.FieldsLengthException;
import files.model.FailedFiles;
import files.model.FileMapping;
import files.model.FilesLocation;
import files.model.ProcessFiles;
import files.services.FileService;

@Service
public class FileRead {
	private @Autowired FilesLocation location;
	private @Autowired FilesDAO filesDAO;
	private @Autowired FileService fileService;
	private @Autowired HiveDao hiveDao;

	public  ArrayList<Object> displayInfo(String fileName, char delimiter) {
		String nextLine[] = null;
		String[] columns = null;
		String mobileNumber = null;
		String[] coloumnsList = null;
		int maxColomn = 0;
		int row = 1;
		try (CSVReader reader = new CSVReader(new FileReader(fileName), delimiter, '"', '\'', 0)) {

			int maxCol = 0;
			int count = 1;
			outerloop: while ((nextLine = reader.readNext()) != null) {

				if ((nextLine.length > maxCol && !(nextLine[nextLine.length - 1].trim() == null
						|| nextLine[nextLine.length - 1].trim().isEmpty()))) {
					maxCol = nextLine.length;

					columns = nextLine;
					maxColomn = row;
					count = 1;
					// System.out.println("count ::"+count);
					// System.out.println("row ::"+row);
				} else {
					// System.out.println("count ::"+count);
					if (maxCol == nextLine.length) {
						count++;
					}
					if (count == 100) {
						break outerloop;
					}
				}
				row++;
			}

		} catch (FileNotFoundException e) {
			e.printStackTrace();
			System.out.println("file not fond");
		} catch (IOException e) {
			e.printStackTrace();
			System.out.println("IOException");
		}

		try (CSVReader reader = new CSVReader(new FileReader(fileName), delimiter, '"', '\'', 0)) {
			ArrayList<String> numbers = new ArrayList<>();
			row = 1;
			outerloop: while ((nextLine = reader.readNext()) != null) {
				if (row < maxColomn) {
					// System.out.println("if ::"+row);
					for (String line : nextLine) {

						if (!line.trim().isEmpty()) {

							String[] values = line.trim().split(" ");
							for (String value : values) {

								if (value.length() >= 10) {
									try {
										value = value.substring(value.length() - 10);
										Long mobileNum = Long.valueOf(value);
										numbers.add(value);
									} catch (Exception e) {

									}
								}
							}
						}
					}

				} else {
					// System.out.println("else ::"+row);
					for (String line : nextLine) {
						if (!line.trim().isEmpty()) {
							String[] values = line.trim().split(" ");
							for (String value : values) {
								if (value.length() >= 10) {
									try {
										value = value.substring(value.length() - 10);
										Long mobileNum = Long.valueOf(value);
										for (String num : numbers) {
											if (num.equals(value)) {
												System.out.println("num " + num + " mobile " + mobileNum);
												mobileNumber = num;
												break outerloop;
											}
										}
									} catch (Exception e) {

									}
								}
							}
						}
					}

				}
				row++;
			}
		} catch (Exception e) {
			e.printStackTrace();
		}

		if (columns != null) {
			coloumnsList = new String[columns.length];

			for (int i = 0; i < columns.length; i++) {
				coloumnsList[i] = columns[i].trim();
				System.out.println(coloumnsList[i]);
			}
		}

		ArrayList<Object> list = new ArrayList<>();

		list.add(coloumnsList);
		list.add(mobileNumber);

		return list;
	}
	public void filesReader() throws IOException, SQLException, InvalidFormatException {
		String failedFileLocations = null;
		String fromLocation = location.getDumpedFiles();

		File folder = new File(fromLocation);
		File[] listOfFiles = folder.listFiles();

		for (File file : listOfFiles) {
			if (file.isFile()) {

				String filename = file.getName();
				String from = fromLocation + filename;

				try {

					if ((filename.endsWith(".xlsx") || filename.endsWith(".xls")) && isExcelEmpty(file)) {

						boolean flag = convertXlsToCsv(from, location);

						// String to = location.getExcelFiles() + filename;
						String to = getFilesDirectory(location.getExcelFiles(), filename);
						if (flag) {

							filesMoveing(from, to);

							filename = filename.endsWith(".xls") ? filename.replace(".xls", ".csv")
									: filename.replace(".xlsx", ".csv");
							System.out.println("excel converted");
							fileMapping(filename, location.getCsvfilesToUpload(), ',');

						}

					} else if (filename.endsWith(".csv") && isCSVEmpty(file)) {

						String to = getFilesDirectory(location.getCsvFiles(), filename);

						filesMoveing(from, to);

						String csvfileName = location.getCsvfilesToUpload() + filename;

						fiesCopy(to, csvfileName);
						failedFileLocations = csvfileName;
						fileMapping(filename, location.getCsvfilesToUpload(), ',');

					} else if (filename.endsWith(".txt") && file.length() != 0) {

						String to = getFilesDirectory(location.getTestFiles(), filename);

						fiesCopy(from, to);

						failedFileLocations = to;
						if (isFileExisting(filename, from, null)) {
							fileService.setProcessFilesStatus(filename, "pending", new FileMapping(), "system", null);

							String pendingFileLocation = location.getPendingFiles() + filename;
							filesMoveing(from, pendingFileLocation);
							failedFileLocations = pendingFileLocation;
						}

					} else {

						String duplicateFilename = getFileName(location.getFailedFiles(), filename);
						String to = location.getFailedFiles() + duplicateFilename;
						/*
						 * ProcessFiles processFiles = new ProcessFiles();
						 * processFiles.setFilename(filename);
						 */
						filesDAO.failedFilesStatus("File is Empty", filename, duplicateFilename);

						filesMoveing(from, to);
					}
				} catch (FieldsLengthException e) {
					try {
						failedFileLocations = location.getCsvfilesToUpload() + filename;
						String duplicateFilename = getFileName(location.getFailedFiles(), filename);
						System.out.println("duplicateFilename ::" + duplicateFilename);
						System.out.println("failedFileLocations ::" + failedFileLocations);
						/*
						 * ProcessFiles processFiles = new ProcessFiles();
						 * processFiles.setFilename(filename);
						 */
						FailedFiles failedFiles = filesDAO.failedFilesStatus("File fields are lessthan Table Fields",
								filename, duplicateFilename);
						System.out.println(failedFiles);
						filesMoveing(failedFileLocations, location.getFailedFiles() + duplicateFilename);
					} catch (Exception ev) {
						ev.printStackTrace();
					}
				} catch (Exception e) {
					try {
						String duplicateFilename = getFileName(location.getFailedFiles(), filename);

						/*
						 * ProcessFiles processFiles = new ProcessFiles();
						 * processFiles.setFilename(filename);
						 */
						filesDAO.failedFilesStatus("Unexpeted Error", filename, duplicateFilename);
						filesMoveing(failedFileLocations, location.getFailedFiles() + duplicateFilename);

					} catch (Exception ev) {
						ev.printStackTrace();
					}
				}

			}
		}
	}

	boolean temp;

	public boolean isExcelEmpty(File file) throws InvalidFormatException, IOException {

		if (file.getPath().endsWith(".xlsx")) {

			try (XSSFWorkbook xsswb = new XSSFWorkbook(OPCPackage.open(file))) {

				xsswb.iterator().forEachRemaining(sheet -> {

					Iterator<Row> rows = sheet.rowIterator();

					temp = rows.hasNext();

				});

			}
			return temp;

		} else {
			HSSFWorkbook workbook = new HSSFWorkbook(new FileInputStream(file));

			for (int i = 0; i < workbook.getNumberOfSheets(); i++) {
				HSSFSheet sheet = workbook.getSheetAt(i);
				Row row;
				Iterator<Row> rowIterator = sheet.iterator();
				while (rowIterator.hasNext()) {
					row = rowIterator.next();
					Iterator<Cell> cells = row.cellIterator();
					while (cells.hasNext()) {
						HSSFCell cell = (HSSFCell) cells.next();
						if (!cell.getStringCellValue().isEmpty()) {
							return true;
						}
					}
				}
			}

			return false;
		}
	}
	public void fileMapping(String fileName, String csvLocation, char deLimiter)
			throws IOException, SQLException, FieldsLengthException {

		String[] tableFields = null;

		Integer[] csvmapped_index = null;

		String csvfileName = csvLocation + fileName;
		System.out.println("Mappping method");
		ArrayList<Object> list = displayInfo(csvfileName, deLimiter);
		String[] csvFields = (String[]) list.get(0);
		String mobileNumber = (String) list.get(1);
		System.out.println("hiveDao.getColumns() ::" + hiveDao.getColumns().length);
		if (csvFields != null && csvFields.length >= hiveDao.getColumns().length) {
			System.out.println("length success");

			if (isFileExisting(fileName, csvfileName, mobileNumber)) {
				FileMapping fileMapping = getExistedCSVFields(csvFields);

				tableFields = fileMapping.getCsvfields();
				csvmapped_index = fileMapping.getCsvmapped_index();

				String to = location.getPendingFiles() + fileName;

				if (tableFields != null && csvmapped_index != null && mobileNumber != null) {

					to = location.getSuccessFiles() + fileName;

					System.out.println(csvfileName + " " + to);

					fileService.setProcessFilesStatus(fileName, "success", fileMapping, "system", mobileNumber);

					filesMoveing(csvfileName, to);

				} else if (tableFields != null && csvmapped_index == null) {

					fileService.setProcessFilesStatus(fileName, "pending", fileMapping, "system", mobileNumber);
					filesMoveing(csvfileName, to);

				} else {

					fileMapping = new FileMapping();

					fileService.setProcessFilesStatus(fileName, "pending", fileMapping, "system", mobileNumber);

					filesMoveing(csvfileName, to);
				}
			}
		} else {
			throw new FieldsLengthException();
		}
	}

	public boolean isFileExisting(String fileName, String csvfilesToUpload) throws IOException {
		ProcessFiles processFiles = filesDAO.getFileInfo(fileName);
		// String status = pf.getStatus();
		System.out.println("status:::>>" + processFiles);
		if (processFiles != null) {

			String from = csvfilesToUpload;

			String duplicateFilename = getFileName(location.getFailedFiles(), fileName);

			String to = location.getFailedFiles() + duplicateFilename;

			// ProcessFiles processFiles = filesDAO.getFileInfo(fileName);
			filesDAO.failedFilesStatus("File name already existed", processFiles.getFilename(), duplicateFilename);
			filesMoveing(from, to);

			return false;
		} else {
			return true;
		}

	}

	public String getFileName(String directory, String fileName) {

		boolean flag = new File(directory, fileName).exists();
		if (flag) {
			String date = new SimpleDateFormat("yyyy_MM_dd HH_mm_ss_SSSSSSS").format(new Date()).toString();

			int lastDot = fileName.lastIndexOf('.');
			return fileName.substring(0, lastDot) + date + fileName.substring(lastDot);
		} else {
			return fileName;
		}
	}

	public String getFilesDirectory(String directory, String filename) {

		String folderName = getFileName(directory, filename);
		if (!(folderName.equalsIgnoreCase(filename))) {
			String tempFolderName = folderName.substring(0, folderName.lastIndexOf("."));
			new File(directory + tempFolderName).mkdirs();
			return directory + tempFolderName + "/" + filename;
		} else {
			return directory + filename;
		}

	}

	public boolean isFileExisting(String fileName, String csvfilesToUpload, String mobileNumber) throws IOException {
		ProcessFiles processFiles = filesDAO.getFileInfo(fileName);
		// String status = pf.getStatus();
		System.out.println("status:::>>" + processFiles);
		if (processFiles != null) {

			String from = csvfilesToUpload;

			String duplicateFilename = getFileName(location.getFailedFiles(), fileName);

			String to = location.getFailedFiles() + duplicateFilename;

			// ProcessFiles processFiles = filesDAO.getFileInfo(fileName);
			filesDAO.failedFilesStatus("File name already existed", fileName, duplicateFilename);
			filesMoveing(from, to);

			return false;
		} else {
			return true;
		}

	}

	public FileMapping getExistedCSVFields(String[] csvFields) throws SQLException {

		return filesDAO.getDBCSVFields(csvFields);
	}

	public static void filesMoveing(String fromLocation, String toLocation) throws IOException {

		Path move = Files.move(Paths.get(fromLocation), Paths.get(toLocation), StandardCopyOption.REPLACE_EXISTING);

		System.out.println("filesMoving " + move.getFileName());

	}

	public static void fiesCopy(String fromLocation, String toLocation) throws IOException {
		Path move = Files.copy(Paths.get(fromLocation), Paths.get(toLocation), StandardCopyOption.REPLACE_EXISTING);
		System.out.println("copy " + move.getFileName());
	}

	public static boolean convertXlsToCsv(String inputFile, FilesLocation locations) {
		try {

			String[] cmdnew = new String[] { locations.getOfficeLoc(), "--headless", "--convert-to", "csv", inputFile,
					"--outdir", locations.getCsvfilesToUpload() };
			Process p = Runtime.getRuntime().exec(cmdnew);
			BufferedReader inputStream = new BufferedReader(new InputStreamReader(p.getInputStream()));
			String s = "";

			while ((s = inputStream.readLine()) != null) {
				System.out.println("type in which to which need to convert :: " + s);
			}
			return true;
		} catch (Exception e) {
			e.printStackTrace();
			return false;
		}
	}

	public boolean isCSVEmpty(File file) throws IOException {
		try (BufferedReader reader = new BufferedReader(new FileReader(file.getPath()))) {
			String temp = reader.readLine();
			return temp != null && !temp.equalsIgnoreCase("") ? true : false;
		}
	}

	public void fileDeletion(String fromLocation) throws IOException {

		Files.deleteIfExists(Paths.get(fromLocation));
		System.out.println("successfully deleted");
	}

	public void fileRename(String oldFileNameWithLocation, String newFileName) throws IOException {
		Path oldFile = Paths.get(oldFileNameWithLocation);
		Files.move(oldFile, oldFile.resolveSibling(newFileName), StandardCopyOption.REPLACE_EXISTING);

	}
}
