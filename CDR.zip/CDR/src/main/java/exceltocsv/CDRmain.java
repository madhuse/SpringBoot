package exceltocsv;

import java.io.BufferedReader;
import java.io.File;
import java.io.IOException;
import java.io.InputStreamReader;
import java.nio.file.DirectoryStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.StandardCopyOption;
import java.nio.file.attribute.FileAttribute;
import java.sql.Connection;
import java.sql.SQLException;
import java.text.SimpleDateFormat;
import java.util.Arrays;
import java.util.Date;
import java.util.Properties;
import java.util.stream.Stream;

import org.apache.commons.codec.binary.StringUtils;
import org.apache.commons.io.FileUtils;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Service;

import exceltocsv.utils.ScriptRunner;
import files.dao.FilesDAO;
import files.fileRead.FileRead;
import files.model.FilesLocation;

@Service
public class CDRmain {
	// private static @Autowired ScriptRunner scriptRunner;
	private static FilesLocation location;
	private static FileRead fileRead; 
	private static FilesDAO filesDAO;
	private static JdbcTemplate jdbcTemplate;
	
	
	/*private @Autowired SessionFactory sessionFactory;
	private Session session;*/
	
	public static void main(String[] args) throws IOException {
		
		String from="F:/changes/CDR/data_dump/xlsOTSi1.csv";
		String to ="F:/changes/CDR/x/xlsOTSi1.csv";
		

		//filesMoveing(from, to);
		
		System.out.println(new SimpleDateFormat("yyyy-MM-dd HH:mm:ss:SSSSSSS").format(new Date()).toString());
		
		/*System.out.println(new SimpleDateFormat("yyyyMMddHHmmssSSSSSSS").format(new Date()));
		int a=0;
		for(int i=0;i<1000;i++)
		{
			a=a+i;
		}
		System.out.println(new SimpleDateFormat("yyyyMMddHHmmssSSSSSSS").format(new Date()));*/
		
		
		
	}
	
	
	
	public static void filesMoveing(String fromLocation, String toLocation) throws IOException {

		Files.move(Paths.get(fromLocation), Paths.get(toLocation), StandardCopyOption.ATOMIC_MOVE);
		
		System.out.println("success");
		
	}
	
	
	
	
	
	

	public void processFiles(String fileName,String status) {
		
		String sql="insert into processfiles values('"+fileName+"','"+status+"',"+ new Date() +"'system')";
		
		jdbcTemplate.execute(sql);
		
		
		
	}

	public static void fileMapping(String fileName,String csvLocation,String deLimiter) throws IOException{
		
		fileName= fileName.endsWith(".xls") ? fileName.replace(".xls", ".csv") :fileName.replace(".xlsx", ".csv");	
		
		
		String[] tableFields={"col_013_14_children","s_no_",
				"col_014_15_children"	,"col_013_14_institutions",
				"col_015_16__1st_quarter_institutions","states_or_uts","col_015_16_1st_quarter_children",
				"col_014_15_institutions"};
		
		String csvfileName=csvLocation+"/"+fileName;		
		
		String[] csvFields=(String[]) fileRead.displayInfo(csvfileName ,',').get(0);
		
		
		boolean isFieldsEqual=Arrays.equals(tableFields, csvFields);
		
		String to=location.getPendingFiles()+fileName;
		
		if(isFieldsEqual){
			to=location.getSuccessFiles()+fileName;
			
			System.out.println(csvfileName+" "+ to);
			
			filesMoveing(csvfileName, to);		
			
			System.out.println("file moved in success folder");
		}else {			
			filesMoveing(csvfileName, to);			
			
			System.out.println("file moved in pending folder");
		}
	}
	
	
	
	
	public static void filesReader() throws IOException {

		String fromLocation = location.getDumpedFiles();

		File folder = new File(fromLocation);
		File[] listOfFiles = folder.listFiles();

		for (File file : listOfFiles) {
			if (file.isFile()) {
				String filename = file.getName();
				if (filename.endsWith(".xlsx") || filename.endsWith(".xls")) {

					String from = fromLocation + filename;

					boolean flag=convertXlsToCsv(from, location,filename);

					String to = location.getExcelFiles() + filename;
					if(flag){
						filesMoveing(from, to);	
						
						fileMapping(filename,location.getCsvfilesToUpload(),"");
					}

				} else if (filename.endsWith(".csv")) {

					String from = fromLocation + filename;
					String to = location.getCsvFiles() + filename;
					
					filesMoveing(from, to);
					
					String csvfileName=location.getCsvfilesToUpload()+"/"+filename;
					
					fiesCopy(to,csvfileName);
					
					fileMapping(filename,location.getCsvfilesToUpload(),"");
				}				
				else if (filename.endsWith(".txt")) {

					String from = fromLocation + filename;
					String to = location.getTestFiles() + filename;
					filesMoveing(from, to);

				}
			}
		}
	}

	
	
	public static void fiesCopy(String fromLocation, String toLocation) throws IOException{
		Files.copy(Paths.get(fromLocation), Paths.get(toLocation),  StandardCopyOption.REPLACE_EXISTING);
	}

	public static boolean convertXlsToCsv(String inputFile, FilesLocation locations,String fileName) {
		try {

			String[] cmdnew = new String[] { locations.getOfficeLoc(), "--headless", "--convert-to", "csv", inputFile,
					"--outdir", locations.getCsvfilesToUpload() + "/" };
			Process p = Runtime.getRuntime().exec(cmdnew);
			BufferedReader inputStream = new BufferedReader(new InputStreamReader(p.getInputStream()));
			String s = "";

			while ((s = inputStream.readLine()) != null) {
				System.out.println("type in which to which need to convert :: " + s);
			}
			
			//fileread.displayInfo(fileName);
			
			
			return true;
		} catch (Exception e) {
			e.printStackTrace();
			return false;
		}
	}
}
