package exceltocsv.utils;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import exceltocsv.model.Locations;



@Service
public class ScriptRunner {
	private @Autowired Locations locations;
	public boolean convertXlsToCsv(String inputFile) {
		try{
			
			System.out.println("locations.getOfficeLoc()::"+locations.getOfficeLoc());
			System.out.println("inputFile::"+inputFile);
			System.out.println("locations.getCsvFile()::"+locations.getCsvFile());
			
			//String[] cmd = new String[]{"wscript","D:/xtoc.vbs",inputFile, outputFile.replace("/", "\\")};
		String[] cmdnew=new String[]{locations.getOfficeLoc(),"--headless","--convert-to","csv",inputFile,"--outdir",locations.getCsvFile()+"/"};
		Process p = Runtime.getRuntime().exec(cmdnew);
		BufferedReader inputStream = new BufferedReader(
				new InputStreamReader(p.getInputStream()));
		String s = "";
		// reading output stream of the command
		while ((s = inputStream.readLine()) != null) {
			System.out.println("type in which to which need to convert :: "+s);
		}
		return true;
		}catch(Exception e)
		{
			e.printStackTrace();
			return false;
		}
  }

}