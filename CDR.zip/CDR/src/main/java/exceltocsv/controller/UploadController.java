package exceltocsv.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.ResponseBody;

import files.fileRead.FileRead;
import files.model.FilesLocation;
import files.services.FileService;
import files.updater.FileStatusUpdate;
import files.vo.FileMappingVO;
import java.io.IOException;


import javax.servlet.http.HttpServletRequest;

@Controller
public class UploadController {
	
	/*private @Autowired Locations locations;
	private @Autowired ScriptRunner scriptRunner;	*/
	private  @Autowired FileRead fileRead;
	private  @Autowired FileStatusUpdate fileStatusUpdate;
	private @Autowired FilesLocation location;
	private  @Autowired FileService  fileService;
	//private @Autowired JdbcTemplate jdbcTemplate;
	@GetMapping("/")
	public String index() {
		return "homepage";
	}
	
	/*// @RequestMapping(value = "/upload", method = RequestMethod.POST)
	@PostMapping("/upload") // new annotation since 4.3
	public String singleFileUpload(@RequestParam("file") MultipartFile file, HttpSession session,
			@RequestParam("tablename[]") ArrayList<String> fileNames, RedirectAttributes redirectAttributes)
			throws IllegalStateException, IOException, SQLException {
		//System.out.println("Name of the jdbcTemplate class :"+jdbcTemplate.getDataSource().getConnection().getMetaData().getDatabaseProductName());
		if (file.isEmpty()) {
			redirectAttributes.addFlashAttribute("message", "Please select a file to upload");
			return "redirect:uploadStatus";
		}
		List<String> savedFiles = new ArrayList<>();
		File convFile;
		int count = 1;
		if (!file.isEmpty()) {
			String fileName = StringFormatUtils.clearString(fileNames.get(count - 1));
			if (file.getOriginalFilename().toLowerCase().endsWith(".xlsx")
					|| file.getOriginalFilename().toLowerCase().endsWith(".xls")) {
				File excelFile = new File(locations.getExcelFile() + fileName + ".xlsx");
				file.transferTo(excelFile);
				scriptRunner.convertXlsToCsv(locations.getExcelFile() + fileName + ".xlsx");
			} else {
				System.out.println("else condition not a csv file");
				convFile = new File(locations.getCsvFile() +"//"+ fileName + ".csv");
				file.transferTo(convFile);
			}
			
			session.setAttribute("csvfileLocation", locations.getCsvFile()+"\\"+ fileName + ".csv");
			count++;
		}	
		
		session.setAttribute("message", "your csv file is uplaoded successfully");
		
		//cdmain.filesReader();
		
		
		return "redirect:/uploadStatus";
	}

	@GetMapping("/getColumns")
	public @ResponseBody String[] getColumns(HttpSession session) {
		
		String file=(String) session.getAttribute("csvfileLocation");
		
		String[] clname=fileRead.displayInfo(file,',');
		System.out.println("clname::"+clname);
		return clname;
	}

	@GetMapping("/uploadStatus")
	public String uploadStatus() {
		return "uploadStatus";
	}*/

	@GetMapping("/store")
	public @ResponseBody String storeFiles() throws IOException{
		
		//fileRead.filesReader();
		
		//fileStatusUpdate.updateFileStatus(null,null);
		
		return "success";
	}
	
	
	
	
	
}