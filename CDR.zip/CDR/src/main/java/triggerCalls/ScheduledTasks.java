package triggerCalls;

import java.io.IOException;
import java.sql.SQLException;
import java.text.SimpleDateFormat;
import java.util.Date;

import org.apache.poi.openxml4j.exceptions.InvalidFormatException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Lazy;
import org.springframework.context.annotation.PropertySource;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Service;

import files.fileRead.FileRead;



@Lazy(false)
@Component
@PropertySource("classpath:application.properties")
public class ScheduledTasks {
  public ScheduledTasks() {
	// TODO Auto-generated constructor stub
	  System.out.println("componet123 ");
}
	@Autowired FileRead fileRead;
    private static final Logger log = LoggerFactory.getLogger(ScheduledTasks.class);

    private static final SimpleDateFormat dateFormat = new SimpleDateFormat("HH:mm:ss");

   // @Scheduled(fixedRate = 5000)
    public void reportCurrentTime() {
        log.info("The time is now {}", dateFormat.format(new Date()));
    }
    @Scheduled(fixedDelayString = "${trigger.fixedDelay.in.milliseconds}" , initialDelayString = "${trigger.initialDelay.in.milliseconds}" )
    public void scheduleFixedDelayTask() throws IOException, SQLException {
    	 log.info("The time is now {}", dateFormat.format(new Date()));
    	 System.out.println("triggerCallsPak-----file processing start time..." + new Date());
    /*    System.out.println(
          "Fixed delay task123 - " + System.currentTimeMillis() / 1000);

	*/	
    	 try {
			fileRead.filesReader();
		} catch (InvalidFormatException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
    	 
    	 System.out.println("file processing end time..." + new Date());
    }
}