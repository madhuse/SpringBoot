package hive;

public class HiveDao {
	/*private HiveTemplate template;

	  public void setHiveTemplate(HiveTemplate template) { this.template = template; }

	  public List<String> getDbs() {
	      return hiveTemplate.execute(new HiveClientCallback<List<String>>() {
	         @Override
	         public List<String> doInHive(HiveClient hiveClient) throws Exception {
	            return hiveClient.get_all_databases();
	         }
	      }));
	  }*/
}
