package com.otsi.ApacheKafka;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.util.Collection;
import java.util.Date;

import org.elasticsearch.action.ActionFuture;
import org.elasticsearch.action.admin.indices.delete.DeleteIndexRequest;
import org.elasticsearch.action.admin.indices.mapping.put.PutMappingRequest;
import org.elasticsearch.action.delete.DeleteResponse;
import org.elasticsearch.action.search.SearchRequestBuilder;
import org.elasticsearch.action.search.SearchResponse;
import org.elasticsearch.action.support.master.AcknowledgedResponse;
import org.elasticsearch.client.Client;
import org.elasticsearch.index.query.QueryBuilders;
import org.elasticsearch.index.reindex.BulkByScrollResponse;
import org.elasticsearch.index.reindex.DeleteByQueryAction;
import org.elasticsearch.index.reindex.DeleteByQueryRequestBuilder;
import org.elasticsearch.index.reindex.ReindexAction;
import org.elasticsearch.index.reindex.ReindexRequestBuilder;
import org.elasticsearch.index.reindex.UpdateByQueryAction;
import org.elasticsearch.index.reindex.UpdateByQueryRequestBuilder;
import org.elasticsearch.script.Script;
import org.elasticsearch.script.ScriptType;
import org.elasticsearch.search.aggregations.Aggregation;
import org.elasticsearch.search.aggregations.AggregationBuilders;
import org.elasticsearch.search.aggregations.bucket.histogram.DateHistogramAggregationBuilder;
import org.elasticsearch.search.aggregations.bucket.histogram.DateHistogramInterval;
import org.elasticsearch.search.aggregations.bucket.histogram.Histogram;
import org.elasticsearch.search.aggregations.bucket.terms.Terms;
import org.elasticsearch.search.aggregations.metrics.min.Min;
import org.elasticsearch.search.aggregations.metrics.min.MinAggregationBuilder;
import org.joda.time.DateTime;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.time.LocalDateTime;
import java.time.ZoneId;
import java.time.format.DateTimeFormatter;
import java.util.Date;
public class DeleteIndex 
{
	//https://javagyanmantra.wixsite.com/website/single-post/2018/02/13/Micros-Services-Architecture

		//https://javagyanmantra.wixsite.com/website/single-post/2018/02/26/Spring-Cloud-Eureaka

		//https://javagyanmantra.wixsite.com/website/single-post/2018/02/14/Pivotal-Cloud-Foundry
	
	public static void main(String[] args) throws Exception {
		Client client = ESConnection.getConnection();
    	
	//	int increment=13;
		int extradate=15;
		int increment1=14;
		int addedint=15;
        
		
		
				
				/*SearchRequestBuilder searchprevious=client.prepareSearch("previousdaydata");
			    DateHistogramAggregationBuilder aggregationprevious =
					        AggregationBuilders
					        .dateHistogram("agg")
					        .dateHistogramInterval(DateHistogramInterval.DAY)
					        
			    .field("source_start_date");
			    searchprevious.addAggregation(aggregationprevious);
			    
		        SearchResponse searchResponseprevious=searchprevious.execute().actionGet();
				
				
		        Histogram aggprevious = searchResponseprevious.getAggregations().get("agg");
		        for (Histogram.Bucket entry : aggprevious.getBuckets()) {
		              // Key
		            String keyAsString = entry.getKeyAsString();
		            Date date = new Date();
		           // Date extra30 = new DateTime(date).minus(1).toDate();
		            DateFormat dateFormat1 = new SimpleDateFormat("dd-MM-YYYY");
				UpdateByQueryRequestBuilder ssislive = UpdateByQueryAction.INSTANCE.newRequestBuilder(client);
		        
				Script script1 = new Script("ctx._source.source_start_date = '"+dateFormat1.format(date)+"'");

				BulkByScrollResponse r1 = ssislive.source("previousdaydata")
				                                       //min date
				    .filter(QueryBuilders.termQuery("source_start_date", keyAsString))
				    .script(script1)  
				    .get();
				System.out.println(r1);
		        }
				Thread.sleep(60000);

				BulkByScrollResponse respprev =
						  new DeleteByQueryRequestBuilder(client, DeleteByQueryAction.INSTANCE)
						    .filter(QueryBuilders.matchAllQuery()) 
						    .source("currentdaydata")                         
						    .get();                                             
						long delprev = respprev.getDeleted();  
						System.out.println(delprev);
						Thread.sleep(3000);

		
						 BulkByScrollResponse finalre =
				    			  new ReindexRequestBuilder(client, ReindexAction.INSTANCE)
				    			    .source("previousdaydata")
				    			    .destination("currentdaydata")
				    			 .filter(QueryBuilders.matchAllQuery())
				    			    .get();
				    	System.out.println(finalre);
		
		SearchRequestBuilder searchlive=client.prepareSearch("ssislivedata");
	    DateHistogramAggregationBuilder aggregationlive =
			        AggregationBuilders
			        .dateHistogram("agg")
			        .dateHistogramInterval(DateHistogramInterval.DAY)
			        
	    .field("source_start_date");
	    searchlive.addAggregation(aggregationlive);
	    
        SearchResponse searchResponselive=searchlive.execute().actionGet();
        
        Histogram agglive = searchResponselive.getAggregations().get("agg");
        for (Histogram.Bucket entry : agglive.getBuckets()) {
              // Key
            String keyAsString = entry.getKeyAsString();
            Date date = new Date();
            DateFormat dateFormat1 = new SimpleDateFormat("dd-MM-YYYY");
		UpdateByQueryRequestBuilder ssislive = UpdateByQueryAction.INSTANCE.newRequestBuilder(client);
        
		Script script1 = new Script("ctx._source.source_start_date = '"+dateFormat1.format(date)+"'");

		BulkByScrollResponse r1 = ssislive.source("ssislivedata")
		                                       //min date
		    .filter(QueryBuilders.termQuery("source_start_date", keyAsString))
		    .script(script1)  
		    .get();
		System.out.println(r1);
        }*/
		//Thread.sleep(60000);
		
		
		SearchRequestBuilder searchlive=client.prepareSearch("ssislivedata");
	    DateHistogramAggregationBuilder aggregationlive =
			        AggregationBuilders
			        .dateHistogram("agg")
			        .dateHistogramInterval(DateHistogramInterval.DAY)
			        
	    .field("source_start_date");
	    searchlive.addAggregation(aggregationlive);
	    
        SearchResponse searchResponselive=searchlive.execute().actionGet();
        
        Histogram agglive = searchResponselive.getAggregations().get("agg");
        for (Histogram.Bucket entry : agglive.getBuckets()) {
              // Key
            String keyAsString = entry.getKeyAsString();
            Date date = new Date();
            DateFormat dateFormat1 = new SimpleDateFormat("dd-MM-YYYY");
		UpdateByQueryRequestBuilder ssislive = UpdateByQueryAction.INSTANCE.newRequestBuilder(client);
        
		Script script1 = new Script("ctx._source.source_start_date = '"+dateFormat1.format(date)+"'");

		BulkByScrollResponse r1 = ssislive.source("ssislivedata")
		                                       //min date
		    .filter(QueryBuilders.termQuery("source_start_date", keyAsString))
		    .script(script1)  
		    .get();
		System.out.println(r1);
        }
		
        Thread.sleep(60000);
		
    	SearchRequestBuilder searchbuilder=client.prepareSearch("xyz_new_backupdata");
	    DateHistogramAggregationBuilder aggregation =
			        AggregationBuilders
			        .dateHistogram("agg")
			        .dateHistogramInterval(DateHistogramInterval.DAY)
			        
	    .field("source_start_date");
		searchbuilder.addAggregation(aggregation);
        SearchResponse searchResponse=searchbuilder.execute().actionGet();
        Histogram agg = searchResponse.getAggregations().get("agg");
                for (Histogram.Bucket entry : agg.getBuckets()) {
                    DateTime key = (DateTime) entry.getKey();    // Key
                    String keyAsString = entry.getKeyAsString(); // Key as String
                   
                    Date date = new Date();
                	Date extra30 = new DateTime(date).plusDays(extradate).toDate();
                	DateFormat dateFormat1 = new SimpleDateFormat("dd-MM-YYYY");
                	System.out.println("Before Convertion"+dateFormat1.format(extra30));
                	
                	                	UpdateByQueryRequestBuilder ubqrb1 = UpdateByQueryAction.INSTANCE.newRequestBuilder(client);
    				                                                                       
    								Script script1 = new Script("ctx._source.source_start_date = '"+dateFormat1.format(extra30)+"'");

    								BulkByScrollResponse r1 = ubqrb1.source("xyz_new_backupdata")
    								                                       //min date
    								    .filter(QueryBuilders.termQuery("source_start_date", keyAsString))
    								    .script(script1)  
    								    .get();
    				
    				
    				System.out.println(r1);
    				Thread.sleep(60000);
   				//--increment;
    				++extradate;
    				System.out.println("extradate"+extradate);
    								
                }
               System.out.println("One Time convertion Done");
                SearchRequestBuilder searchbuilder1=client.prepareSearch("xyz_new_backupdata");
        	    DateHistogramAggregationBuilder aggregation1 =
        			        AggregationBuilders
        			        .dateHistogram("agg")
        			        .dateHistogramInterval(DateHistogramInterval.DAY)
        			        
        	    .field("source_start_date");
        		searchbuilder1.addAggregation(aggregation1);
                SearchResponse searchResponse1=searchbuilder1.execute().actionGet();
                
                Histogram agg1 = searchResponse1.getAggregations().get("agg");
                for (Histogram.Bucket entry : agg1.getBuckets()) {
                    DateTime key = (DateTime) entry.getKey();    // Key
                    String keyAsString = entry.getKeyAsString(); // Key as String
                   
                    Date date = new Date();
                	Date extra30 = new DateTime(date).plusDays(addedint).toDate();
                	//System.out.println("extra30"+extra30);
                	DateFormat dateFormat1 = new SimpleDateFormat("dd-MM-YYYY");
                	
                	Date daysAgo14 = new DateTime(date).minusDays(increment1).toDate();
                	
                	System.out.println("After convertion"+dateFormat1.format(extra30));
                	System.out.println("Actual convertion"+dateFormat1.format(daysAgo14));
                	
                
				UpdateByQueryRequestBuilder ubqrb = UpdateByQueryAction.INSTANCE.newRequestBuilder(client);
///                                                                         daysAgo14
				Script script = new Script("ctx._source.source_start_date = '"+dateFormat1.format(daysAgo14)+"'");

				BulkByScrollResponse r = ubqrb.source("xyz_new_backupdata")
				                                       //min date
				    .filter(QueryBuilders.termQuery("source_start_date", dateFormat1.format(extra30)))
				    .script(script)  
				    .get();
				System.out.println(r);
				Thread.sleep(60000);
			    --increment1;
				++addedint;
				System.out.println("Increment number"+increment1);
				if(increment1==0) {
					break;
				}
				//System.out.println(increment);
				
				
                }
		
	
               
	}
}