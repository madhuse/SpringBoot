package com.otsi.ApacheKafka;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Properties;

import org.apache.kafka.clients.producer.KafkaProducer;
import org.apache.kafka.clients.producer.ProducerRecord;
import org.apache.kafka.clients.producer.RecordMetadata;
import org.json.JSONObject;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;

import io.netty.util.concurrent.Future;



public class Producer 
{
	public static void main(String[] args)  {
		
		

		    Properties props = new Properties();
		    props.put("bootstrap.servers", "10.80.15.65:9092");
		    props.put("acks", "all");
		    props.put("retries", 0);
		    props.put("key.serializer", "org.apache.kafka.common.serialization.ByteArraySerializer");
		    props.put("value.serializer", "org.apache.kafka.connect.json.JsonSerializer");

		    KafkaProducer<String, String> producer = new KafkaProducer<String, String>(props);

		    try {
		        producer = new KafkaProducer<String, String>(props);
		    } catch (Exception e) {
		        e.printStackTrace();
		    }
		   
		    JsonData data=new JsonData();
		    data.setAmount("1000");
		    data.setItem_name("Vegetables");
		    data.setPayment_mode("Cash");
		    data.setLocation("Hyderabad");
		    
		    List<Map>list=new ArrayList<Map>();
		   
		   // list.add(map1);
		   
		   
		    ObjectMapper objectMapper = new ObjectMapper();
		    JsonNode  jsonNode = objectMapper.valueToTree(data);
		   // blobStorageChecker = new BlobStorageChecker();
		   // String folder = blobStorageChecker.getCurrentDateUTC();
		  
		    ProducerRecord<String, String> record = new ProducerRecord<String, String>("kafkastreaming", null, jsonNode.toString());
		    if (producer != null) {
		        try {
		        	 
		        	RecordMetadata future =producer.send(record).get();
		            System.out.println(future);
		        } catch (Exception e) {
		            System.err.println(e.getMessage());
		            e.printStackTrace();
		        }
		    }
		    producer.close();

	}}