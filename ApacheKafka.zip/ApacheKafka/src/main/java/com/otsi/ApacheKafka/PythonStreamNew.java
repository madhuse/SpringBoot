package com.otsi.ApacheKafka;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLDecoder;
import java.net.URLEncoder;
import java.nio.charset.Charset;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.List;

import org.elasticsearch.action.index.IndexResponse;
import org.elasticsearch.action.search.SearchRequestBuilder;
import org.elasticsearch.action.search.SearchResponse;
import org.elasticsearch.client.Client;
import org.elasticsearch.common.xcontent.XContentType;
import org.elasticsearch.index.query.QueryBuilders;
import org.elasticsearch.index.reindex.BulkByScrollResponse;
import org.elasticsearch.index.reindex.DeleteByQueryAction;
import org.elasticsearch.index.reindex.DeleteByQueryRequestBuilder;
import org.elasticsearch.search.SearchHit;
import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;

import net.minidev.json.parser.ParseException;



public class PythonStreamNew 
{
	//To schedule an jar file use:
	//program/script:"c/user/run.bat"
	//add argument:up to run.bat
	//start in optional :Folder name
	
	@SuppressWarnings("unchecked")
	public static void main(String[] args) throws Exception{
		
		Client client = ESConnection.getConnection();
		BulkByScrollResponse response1 =
				  new DeleteByQueryRequestBuilder(client, DeleteByQueryAction.INSTANCE)
				    .filter(QueryBuilders.matchAllQuery()) 
				    .source("forecasteddata")                         
				    .get();                                             
				long deleted1 = response1.getDeleted();  
				System.out.println(deleted1);
				Thread.sleep(3000);
				
	BulkByScrollResponse response =
			  new DeleteByQueryRequestBuilder(client, DeleteByQueryAction.INSTANCE)
			    .filter(QueryBuilders.matchAllQuery()) 
			    .source("currentdaydata")                         
			    .get();                                             
			long deleted = response.getDeleted();  
			System.out.println(deleted);
	
		Thread.sleep(3000);
		
		String recordsFile="\\\\192.168.1.33\\Datasets_For_ETL_Logs\\SSRS_Day21\\Datacount\\datafile.txt";
		String cpuFile="\\\\192.168.1.33\\Datasets_For_ETL_Logs\\SSRS_Day21\\CPU\\cpu_mem_log.txt";
		String indexname="xyz_new_backupdata";
		
		
		
		 DateFormat dateFormat = new SimpleDateFormat("dd-MM-YYYY");
	    	Date date = new Date();
	    	System.out.println(dateFormat.format(date));
	    	File folder=new File(recordsFile);
			//File tempcpufile=new File(recordsFile);
			Path path = Paths.get(cpuFile);
			List<String> allLines = Files.readAllLines(path);
			String cpurecords= allLines.get(allLines.size()-1);
			String []arrnew=cpurecords.split(",");
			String cpudata=null;
			String memorydata=null;
			Double memorydatanew=0.0;
			Double cpudatanew=0.0;
			for (int i = 0; i < arrnew.length; i++) {
				cpudata=arrnew[1].replaceAll("", "");
				cpudata = cpudata.replaceAll("^\"|\"$", "");
				cpudatanew=(Double.valueOf(cpudata));
				memorydata=arrnew[2];
				memorydata = memorydata.replaceAll("^\"|\"$", "");
				memorydatanew=(Double.valueOf(memorydata));
				
			}
				
			
			System.out.println(folder.getName());
			String nameOfFile=folder.getName();
			String[] filename=nameOfFile.split(".txt");
			
			String day="Day"+filename[0].replaceAll("datafile", "");
			System.out.println(day+"jjjjjjjjjj");
			System.out.println(folder.getAbsolutePath());
			
			BufferedReader br1=new BufferedReader(new FileReader(folder));
			String inputrecords=null;
			String []records=null;
			String table_name=null;
			String table_name_new=null;
			int recordscount=0;
			while ((inputrecords = br1.readLine()) != null) {
				if(!inputrecords.isEmpty()) {
				records=inputrecords.split(": ");
				table_name=records[0];
				recordscount=Integer.parseInt(records[1]);
				table_name=table_name.replaceAll("_DATASET.CSV", "");
				table_name=table_name.replaceAll("_DATA.CSV", "");
				table_name=table_name.replaceAll("---------- ", "");
				table_name=table_name.replaceAll("OLIST_", "");
				table_name=table_name.replaceAll("---------- OLIST_", "").toLowerCase();
				table_name_new="'"+table_name+"'";
				table_name_new=table_name_new.replaceAll("_", "%20");
				table_name=table_name.replaceAll("_", " ");
				JSONObject slatime=new JSONObject();
				slatime.put("slatime", 43);
				slatime.put("source_start_date","01-11-2019");
				slatime.put("elapsed_time",0.0);
				//List<Object>inputdata=new ArrayList<Object>(Arrays.asList(table_name_new,recordscount,cpudata,memorydata));
				JSONObject json = null;
				//String urlnew="http://10.80.2.9:1234/elapsed_time/"+URLEncoder.encode(inputdata.toString(), "UTF-8");
				String urlnew="http://10.80.2.214:1234/elapsed_time/["+table_name_new+","+recordscount+","+cpudata+","+memorydata+"]";
				
				//System.out.println(URLEncoder.encode(inputdata.toString(), "UTF-8"));
					
			        URL url = new URL(urlnew);//your url i.e fetch data from .
			        HttpURLConnection conn = (HttpURLConnection) url.openConnection();
			        
			        conn.setRequestMethod("GET");
			        
			        conn.setDoOutput(true);
			        
			        InputStreamReader in = new InputStreamReader(conn.getInputStream());
			      
			        BufferedReader br = new BufferedReader(in);
			        String output;
			        String [] arr=null;
			        String elapsed=null;
			        Float elapsednew=0.0F;
			       while ((output = br.readLine()) != null) {
			        	arr=output.split(" : ");
			        	elapsed=arr[1];
			        	elapsed = elapsed.replaceAll("\\[", "").replaceAll("\\]","");
			            json = new JSONObject();
			            elapsednew=Float.valueOf(elapsed);
			           // json.put("day", day);
			            json.put("source_start_date",dateFormat.format(date));
			            json.put("table", table_name);
			            json.put("forecastednoofrecords", recordscount);
			            json.put("cpu_usage", cpudatanew);
			            json.put("memory_usage", memorydatanew); //daynumber
			            json.put("forcasted_elapsed_time", elapsednew);
			           
			            IndexResponse response2=client.prepareIndex("forecasteddata", "doc")
			            		 .setSource(json, XContentType.JSON)
				        	        .get();
				            System.out.println(response2.getId());
				           
				            if(table_name.equals("customer")) {
				            IndexResponse response3=client.prepareIndex("xyz_new_backupdata", "doc")
				            		 .setSource(slatime, XContentType.JSON)
					        	        .get();
					            System.out.println(response3.getId());
				            }
			            
			             }
			        
			        conn.disconnect();

				
				}
				}
		
			br1.close();
			System.out.println("Total Batch was completed");
	}
}