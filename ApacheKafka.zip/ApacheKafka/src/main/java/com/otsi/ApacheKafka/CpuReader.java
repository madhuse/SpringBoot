package com.otsi.ApacheKafka;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.Map;

import org.elasticsearch.action.index.IndexResponse;
import org.elasticsearch.action.search.SearchRequestBuilder;
import org.elasticsearch.action.search.SearchResponse;
import org.elasticsearch.client.Client;
import org.elasticsearch.common.xcontent.XContentType;
import org.elasticsearch.index.query.BoolQueryBuilder;
import org.elasticsearch.index.query.QueryBuilder;
import org.elasticsearch.index.query.QueryBuilders;
import org.elasticsearch.index.reindex.BulkByScrollResponse;
import org.elasticsearch.index.reindex.ReindexAction;
import org.elasticsearch.index.reindex.ReindexRequestBuilder;
import org.elasticsearch.search.SearchHit;
import org.elasticsearch.search.SearchHits;
import org.elasticsearch.search.aggregations.AggregationBuilders;
import org.elasticsearch.search.aggregations.metrics.valuecount.ValueCount;
import org.elasticsearch.search.aggregations.metrics.valuecount.ValueCountAggregationBuilder;
import org.json.simple.JSONObject;




public class CpuReader 
{
	@SuppressWarnings({ "unchecked", "unchecked" })
	public static void main(String[] args) throws  FileNotFoundException ,IOException,InterruptedException{
		Client client = ESConnection.getConnection();
		DateFormat dateFormat = new SimpleDateFormat("dd-MM-YYYY");
    	Date date = new Date();
    	System.out.println(dateFormat.format(date));
		Calendar c = Calendar.getInstance();
		File  dir=new File("D:\\new\\logstash-7.1.1\\"+c.getTimeInMillis()+"_ssis");
		Process process = null;
		        try
		        {
		       String s = "";
		       String [] cmd=null;
		      // DateFormat dateFormat = new SimpleDateFormat("dd-MM-YYYY");
		   //	Date date = new Date();
		   	System.out.println(dateFormat.format(date));
		       cmd = new String[] { "D:\\new\\logstash-7.1.1\\bin\\logstash.bat","--path.data",dir.getAbsolutePath(),"--pipeline.workers","1","-f", "D:\\new\\logstash-7.1.1\\bin\\update_new_1.conf"};
		       process = Runtime.getRuntime().exec(cmd);
		       BufferedReader stdInput = new BufferedReader(new InputStreamReader(process.getInputStream()));
		      	while ((s = stdInput.readLine()) != null)
		       {
		      		System.out.println(s);

	   BoolQueryBuilder bool=QueryBuilders.boolQuery();
       SearchRequestBuilder searchbuilder22=client.prepareSearch("xyz_new_backupdata");
       ValueCountAggregationBuilder agg22=AggregationBuilders.count("count").field("elapsed_time");
        bool.must().add(QueryBuilders.matchQuery("source_start_date", dateFormat.format(date)));
        searchbuilder22.setQuery(bool);
        searchbuilder22.addAggregation(agg22);
        SearchResponse response=searchbuilder22.execute().actionGet();
        ValueCount agg11 = response.getAggregations().get("count");
       
        long value = agg11.getValue();
        System.out.println("Current count:"+value);
        if(value==7) {
        	System.out.println("stop the logstash processing");
            Process p = Runtime.getRuntime().exec( 
    				  new String[]{"cmd", "/c", "running.bat"},
    				  null, 
    				  new File("C:\\Users\\madhu.akula\\Documents\\Elastic\\aaa\\bat"));
    		  BufferedReader stdInput7 = new BufferedReader(new InputStreamReader(p.getInputStream()));
    		  String s1 = "";
    		  
    	   	while ((s1 = stdInput7.readLine()) != null)
    	    {
    	   		if(s1.contains("TCP")) {
    	   			s1=s1.substring(s1.lastIndexOf("LISTENING       ")+16,s1.length());
    	   			System.out.println("process id"+s1);
    	   			
    	   			System.out.println("here i nedd to write the shut down the logictaskkill  /F  /PID  "+s1);
    	   			
    	   			Process kill=Runtime.getRuntime().exec("taskkill  /F  /PID  "+s1);
    	   		BufferedReader std = new BufferedReader(new InputStreamReader(kill.getInputStream()));
    	   	String s2 = "";
    	  while ((s2 = std.readLine()) != null)
    	    {
    	   		System.out.println(s2);
    	   		}
    	   		}
    	    }
        	
        	
        }
        
		       }
		      	Thread.sleep(10000);
		        System.out.println("processed CPU Log files completed");
		        JSONObject slatime1=new JSONObject();
				slatime1.put("elapsed_time", 3.0);
				slatime1.put("source_start_date",dateFormat.format(date));
				slatime1.put("table","sellers");
				 IndexResponse res1=client.prepareIndex("xyz_new_backupdata", "doc")
		           		 .setSource(slatime1, XContentType.JSON)
			        	        .get();
			            System.out.println(res1.getId());
		      	Thread.sleep(10000);
		        System.out.println("processed CPU Log files completed");
		        JSONObject slatime2=new JSONObject();
				slatime2.put("noofrecords", 4489);
				slatime2.put("source_start_date",dateFormat.format(date));
				slatime2.put("table","sellers");
				 IndexResponse res22=client.prepareIndex("xyz_new_backupdata", "doc")
		           		 .setSource(slatime2, XContentType.JSON)
			        	        .get();
			            System.out.println(res22.getId());
			      
		}catch(Exception e ) {
			System.out.println("error");
		}
        
        
                Thread.sleep(10000);
               
       System.out.println("starting the cpu files");
                Process cpu = null;
            	
                try
                {
               String s = "";
               String [] cmd=null;
               int lines = 0;
               cmd = new String[] { "D:\\new\\logstash-7.1.1\\bin\\logstash.bat","--pipeline.workers","1","--pipeline.batch.size","1","-f", "D:\\new\\logstash-7.1.1\\bin\\cpu_usage_1.conf"};
               cpu = Runtime.getRuntime().exec(cmd);
               BufferedReader stdInput = new BufferedReader(new InputStreamReader(cpu.getInputStream()));
              	while ((s = stdInput.readLine()) != null)
               {
              		System.out.println(s);
                 System.out.println("within the loop");
                 
                  File f=new File("D:\\new\\logstash-7.1.1\\data\\plugins\\inputs\\file");
                  	File[] listFiles = f.listFiles();
                  	for(File file:listFiles) {
                  	System.out.println(file.getAbsolutePath());
                  	BufferedReader reader = new BufferedReader(new FileReader(file.getAbsolutePath()));
                  	Thread.sleep(30000);
                  	while (reader.readLine() != null) {
                  		
                  		lines++;
                  		//System.out.println(lines);
                  	}
                  	reader.close();
                   }
                 	  System.out.println("Total count"+lines);
                 	  if(lines==1) {
                 		  System.out.println("logstash was going to shut down");
                 		  System.out.println("ok need to shut");
                 		
                 		 // Thread.sleep(60000);
                 		  System.out.println("ok");
                 		//Thread.sleep(60000);
                 		  
                 		 Process p = Runtime.getRuntime().exec( 
                 				  new String[]{"cmd", "/c", "running.bat"},
                 				  null, 
                 				  new File("C:\\Users\\madhu.akula\\Documents\\Elastic\\aaa\\bat"));
                 		  BufferedReader stdInput7 = new BufferedReader(new InputStreamReader(p.getInputStream()));
                 		  String s1 = "";
                 		  
                 	   	while ((s1 = stdInput7.readLine()) != null)
                 	    {
                 	   		if(s1.contains("TCP")) {
                 	   			s1=s1.substring(s1.lastIndexOf("LISTENING       ")+16,s1.length());
                 	   			System.out.println("process id"+s1);
                 	   			
                 	   			System.out.println("here i nedd to write the shut down the logictaskkill  /F  /PID  "+s1);
                 	   			Process kill=Runtime.getRuntime().exec("taskkill  /F  /PID  "+s1);
                 	   		BufferedReader std = new BufferedReader(new InputStreamReader(kill.getInputStream()));
                 	   	String s2 = "";
                 	  while ((s2 = std.readLine()) != null)
                 	    {
                 	   		System.out.println(s2);
                 	   		}
                 	   		}
                 	    }
                 		  
                 	  }
                 	 
              
               }
              	
               System.out.println("processed CPU Log files completed");
               File directory = new File("D:\\new\\logstash-7.1.1\\data\\plugins\\inputs\\file");
             	 
             	 File[] files = directory.listFiles();
             	 
             	 for (File file : files){
             	 file.delete();
             	 }
            }catch(Exception e ) {
            System.out.println("error");
            }      

		
   }
	
	
}