package com.otsi.ApacheKafka;
import java.io.IOException;
import java.util.Timer;
import java.util.TimerTask;


public class AsynchronousProducer 
{
	static Timer t = new Timer();
	
	public static void main(String[] args)throws Exception {
	
		
		t.schedule(new TimerTask() {
		    @Override
		    public void run() {
		       System.out.println("Hello World");
		    }
		}, 0, 5000);	
		
		
		Thread.sleep(5000);
		System.out.println("dgsgg");
		
		
		//Thread.sleep(5000);
		System.out.println("sefsef");
		
		//Thread.sleep(5000);
		System.out.println("124");
		
		//Thread.sleep(1000);
		System.out.println("6565");
		t.cancel();
		
    }
}
		                 