package com.otsi.ApacheKafka;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;
import java.text.SimpleDateFormat;
import java.util.Date;

import org.elasticsearch.action.bulk.BulkRequestBuilder;
import org.elasticsearch.action.index.IndexAction;
import org.elasticsearch.action.index.IndexRequestBuilder;
import org.elasticsearch.action.index.IndexResponse;
import org.elasticsearch.client.Client;
import org.elasticsearch.common.xcontent.XContentFactory;
import org.elasticsearch.common.xcontent.XContentType;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import org.json.XML;

import com.fasterxml.jackson.databind.ObjectMapper;

///https://stackoverflow.com/questions/40952714/filebeat-5-0-output-to-kafka-multiple-topics
public class JdbcConn {

	

	public static void main(String[] args) throws JSONException, IOException {
		Client client = ESConnection.getConnection();

		File xmlFolder = new File("D:\\elastic latest versions\\kafka\\input");
		File[] xmlFilesList = xmlFolder.listFiles();
		for (File file : xmlFilesList) {
			if (file.isFile()&&file.getName().endsWith(".xml")) {
            System.out.println("File Name is::"+file.getName());
            String line = "", str = "";
				BufferedReader br = new BufferedReader(new FileReader(file));
				while ((line = br.readLine()) != null) {
					str += line;
				}
				
				JSONObject jsondata = XML.toJSONObject(str);
				FileWriter filewriter=new FileWriter(new File(xmlFolder+"//"+file.getName().split(".xml")[0]+".json"));
				filewriter.write(jsondata.toString());
				filewriter.flush();
				filewriter.close();
				String suitename = jsondata.getJSONObject("OTSISuite").getJSONObject("Name").getString("content");
				String suitetime = jsondata.getJSONObject("OTSISuite").getJSONObject("sttime").getString("content");
				String suiteend = jsondata.getJSONObject("OTSISuite").getJSONObject("edtime").getString("content");
				SimpleDateFormat suiteformat = new SimpleDateFormat("dd-MMM-yyyy HH:mm:ss.SSS -0400");
				Date suited1 = null;
				Date suited2 = null;
				Double SuitediffMinutes = 0.0;
				try {
					suited1 = suiteformat.parse(suitetime);
					suited2 = suiteformat.parse(suiteend);

					long Suite_diff = suited2.getTime() - suited1.getTime();
					SuitediffMinutes = Suite_diff / (60.0 * 60.0 * 1000) % 24.0;
					System.out.println("TestSuite elapsed time In Hours" + SuitediffMinutes);
				} catch (Exception e) {
					System.out.println(e.getMessage());
				}
				JSONArray string = jsondata.getJSONObject("OTSISuite").getJSONObject("TestCases").getJSONArray("TC");

				String TestcaseName = null;
				String Testcasesttime = null;
				String Testcaseedtime = null;

				for (int i = 0; i < string.length(); i++) {

					JSONObject objects = string.getJSONObject(i);
					TestcaseName = objects.getString("Name");
					Testcasesttime = objects.getString("sttime");
					Testcaseedtime = objects.getString("edtime");

					SimpleDateFormat format = new SimpleDateFormat("dd-MMM-yyyy HH:mm:ss.SSS -0400");
					Date testcased1 = null;
					Date testcased2 = null;
					Double testcasediffInMinutes = 0.0;
					try {
						testcased1 = format.parse(Testcasesttime);
						testcased2 = format.parse(Testcaseedtime);

						long diff = testcased2.getTime() - testcased1.getTime();
						testcasediffInMinutes = diff / (60.0 * 1000) % 60.0;

					} catch (Exception e) {
						System.out.println(e.getMessage());
					}

					JSONObject TCS = objects.getJSONObject("TCS");

					JSONArray TS = TCS.getJSONArray("TS");
					if (TS instanceof JSONArray) {

						for (int j = 0; j < TS.length(); j++) {

							JSONObject TSObj = TS.getJSONObject(j);
							String stkeyword = TSObj.getString("sttime");
							String endkeyword = TSObj.getString("edtime");
							String Keyword_Name = TSObj.getString("Name");
							SimpleDateFormat keywordformat = new SimpleDateFormat("dd-MMM-yyyy HH:mm:ss.SSS -0400");
							Date keydword1 = null;
							Date keydword2 = null;
							Double keywordifinfMin = 0.0;

							try {
								keydword1 = keywordformat.parse(stkeyword);
								keydword2 = keywordformat.parse(endkeyword);

								long keydiff = keydword2.getTime() - keydword1.getTime();
								keywordifinfMin = keydiff / (60.0 * 1000) % 60.0;

							} catch (Exception e) {
								System.out.println(e.getMessage());
							}
							IndexRequestBuilder indexRequestBuilder = new IndexRequestBuilder(client,
									IndexAction.INSTANCE);
							try {
								indexRequestBuilder.setSource(XContentFactory.jsonBuilder().startObject()
										//.field("TestSuite_diff_In_Hours", SuitediffMinutes)
										.field("TestSuite_End_Time", suiteend).field("TestSuite_Start_Time", suitetime)
										.field("TestSuite_Name", suitename).field("TestCase_Name", TestcaseName)
										.field("TestCase_Start_Time", Testcasesttime)
										.field("TestCase_End_Time", Testcaseedtime)
										//.field("Testcase_diff_In_Minutes", testcasediffInMinutes)
										.field("Keyword_Name", Keyword_Name)
									    .field("Keyword_Start_Time", stkeyword).field("Keyword_End_Time", endkeyword)
										.field("Keyword_diff_In_Minutes", keywordifinfMin).endObject())
										.setIndex("twoxmlfiles");

							} catch (IOException e) {
								// TODO Auto-generated catch block
								e.printStackTrace();
							}
							indexRequestBuilder.execute().actionGet();
						}
					}
				}
				System.out.println("File is processed successfully::"+file.getName());
				br.close();
			}
			

		}
		

	}
}
