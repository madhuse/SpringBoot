package com.otsi.ApacheKafka;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.HashMap;
import java.util.Map;

import org.elasticsearch.action.index.IndexAction;
import org.elasticsearch.action.index.IndexRequestBuilder;
import org.elasticsearch.action.index.IndexResponse;
import org.elasticsearch.client.Client;
import org.elasticsearch.common.xcontent.XContentFactory;
import org.elasticsearch.common.xcontent.XContentType;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import org.json.XML;



public class XmlToJson
{
	
    public static void main(String[] args) throws JSONException, IOException {
    	Client client = ESConnection.getConnection();
        //String link = "D:\\elastic latest versions\\sprint\\cpu log day1.xml";
        File xmlFolder = new File("D:\\elastic latest versions\\sprint\\ssis xml file");
		File[] xmlFilesList = xmlFolder.listFiles();
		for (File file : xmlFilesList) {
			if (file.isFile()&&file.getName().endsWith(".txt")) {
        
				String [] filesss=file.getName().split(" ");
				String day=filesss[0]+""+filesss[1];
				System.out.println(day);
        String line="",str="";
        BufferedReader br = new BufferedReader(new FileReader(file));
        while ((line = br.readLine()) != null) 
        {   
            str+=line;  
        }
        JSONObject jsondata = XML.toJSONObject(str);
        
        JSONArray JSONObject= jsondata.getJSONObject("OBJECT").getJSONArray("PARAM");
        Float string=0.0f;
        String value=null;
        String key=null;
        Map<String,String>mymap=new HashMap<String,String>();
        
        for (int i = 50; i < JSONObject.length(); i++) {
        	JSONObject object = (org.json.JSONObject) JSONObject.get(i);
        	
        	try {
        		string = object.getFloat("VALUE");
        		value=Float.toString(string);
        	}catch(JSONException e) {
        		value=object.getString("VALUE");
        		
        	}
        	key = object.getString("NAME");
        	key = key.replaceAll("[^a-zA-Z0-9]", "_");
        	mymap.put(key, value);
        // System.out.println(mymap);
        	//IndexResponse response = client.prepareIndex("xml_ssis", "doc")
        	        //.setSource(mymap, XContentType.JSON)
        	       // .get();
         // System.out.println(response);
          //value = value.replaceAll("[^a-zA-Z0-9]", " ");
        //  key = key.replaceAll("[^a-zA-Z0-9]", " ");
         /* System.out.println("Value:: "+value);
          System.out.println("Key:: "+key);
			IndexRequestBuilder indexRequestBuilder = new IndexRequestBuilder(client,
					IndexAction.INSTANCE);
			try {
				indexRequestBuilder.setSource(XContentFactory.jsonBuilder().startObject()
						//.field("TestSuite_diff_In_Hours", SuitediffMinutes)
						.field(key, value)
						.endObject())
						.setIndex("twoxmlfiles")
						.setType("doc")
						;

			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			indexRequestBuilder.execute().actionGet();*/
         
		}
        mymap.put("day", day);
        mymap.put("source_start_date", "04-08-2019");
      
        /*else if((day=="Day2")||(day=="Day4")) {
        	mymap.put("cpu_utilized_date", "23-07-2019");
        }
        else if((day=="Day6")||(day=="Day5")) {
        	mymap.put("cpu_utilized_date", "25-07-2019");
        }
        else if((day=="Day1")) {
        	mymap.put("cpu_utilized_date", "24-07-2019");
        }*/
                //mymap.put("cpu_utilized_date", day);
        
        
        IndexResponse response = client.prepareIndex("ssis_unique_id", "doc")
    	        .setSource(mymap, XContentType.JSON)
    	        .get();
         
    }
}}}