package com.otsi.ApacheKafka;

import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Properties;

import org.apache.kafka.clients.producer.KafkaProducer;
import org.apache.kafka.clients.producer.ProducerRecord;
import org.json.JSONObject;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.opencsv.CSVReader;



public class App 
{
	public static void main(String[] args)  {
		
		

		    Properties props = new Properties();
		    props.put("bootstrap.servers", "10.80.15.65:9093");
		    props.put("acks", "all");
		    props.put("retries", 0);
		    props.put("key.serializer", "org.apache.kafka.common.serialization.ByteArraySerializer");
		    props.put("value.serializer", "org.apache.kafka.connect.json.JsonSerializer");

		    KafkaProducer producer = new KafkaProducer(props);

		    try {
		        producer = new KafkaProducer<String, JsonNode>(props);
		    } catch (Exception e) {
		        e.printStackTrace();
		    }
		   
		    String csvFile = "C:\\Users\\madhu.akula\\Desktop\\log files\\simulate1.csv";

	        CSVReader reader = null;
	        try {
	            reader = new CSVReader(new FileReader(csvFile));
	            String[] line;
	            JsonData jsondata=new JsonData();
	            while ((line = reader.readNext()) != null) {
	               // System.out.println("Country [id= " + line[0] + ", code= " + line[1] + " , name=" + line[2] + "]");
	            	jsondata.setCust_id(Long.parseLong(line[0]));
	                jsondata.setMobile_number(line[1]);
	                jsondata.setItem_count(Integer.parseInt(line[2]));
	                jsondata.setBill_amount(Double.parseDouble(line[3]));
	                jsondata.setBilling_time(Long.parseLong(line[4]));
	                jsondata.setDiscount(Double.parseDouble(line[5]));
	                jsondata.setPayment_mode(line[6]);
	                jsondata.setRating(Integer.parseInt(line[7]));
	                
	                jsondata.setTimestamp(line[8]);
	                jsondata.setGeo_points(line[9]);
	                jsondata.setLocation(line[10]);
	               JSONObject result = new JSONObject();
				
				    ObjectMapper objectMapper = new ObjectMapper();
				    JsonNode  jsonNode = objectMapper.valueToTree(jsondata);
				
		            ProducerRecord<String, JsonNode> record = new ProducerRecord<String, JsonNode>("demouser-easy",jsonNode);
				  if (producer != null) {
				        try {
				        	 producer.send(record);
				        	 Thread.sleep(30000);
				        	 System.out.println(jsonNode.toString());
				        //	RecordMetadata> future =
				          //  RecordMetadata metadata = future.get();
				        } catch (Exception e) {
				            System.err.println(e.getMessage());
				            e.printStackTrace();
				        }
				    }
				   
			
 }
	            
	        } catch (IOException e) {
	            e.printStackTrace();
	        }
		    
producer.close();

	}}

