package com.otsi.ApacheKafka;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.Calendar;
import java.util.Map;

import scala.collection.immutable.HashMap;

public class Logstashcode {
public static void main(String[] args) throws  IOException{

	Process cpu = null;
	
    try
    {
   String s = "";
   String [] cmd=null;
   int lines = 0;
   cmd = new String[] { "D:\\new\\logstash-7.1.1\\bin\\logstash.bat","--pipeline.workers","1","--pipeline.batch.size","1","-f", "D:\\new\\logstash-7.1.1\\bin\\cpu_usage_1.conf"};
   cpu = Runtime.getRuntime().exec(cmd);
   BufferedReader stdInput = new BufferedReader(new InputStreamReader(cpu.getInputStream()));
  	while ((s = stdInput.readLine()) != null)
   {
  		System.out.println(s);
     System.out.println("within the loop");
     
      File f=new File("D:\\new\\logstash-7.1.1\\data\\plugins\\inputs\\file");
      	File[] listFiles = f.listFiles();
      	for(File file:listFiles) {
      	System.out.println(file.getAbsolutePath());
      	BufferedReader reader = new BufferedReader(new FileReader(file.getAbsolutePath()));
      	Thread.sleep(30000);
      	while (reader.readLine() != null) {
      		
      		lines++;
      		//System.out.println(lines);
      	}
      	reader.close();
       }
     	  System.out.println("Total count"+lines);
     	  if(lines==1) {
     		  System.out.println("logstash was going to shut down");
     		  System.out.println("ok need to shut");
     		
     		 // Thread.sleep(60000);
     		  System.out.println("ok");
     		//Thread.sleep(60000);
     		  
     		 Process p = Runtime.getRuntime().exec( 
     				  new String[]{"cmd", "/c", "running.bat"},
     				  null, 
     				  new File("C:\\Users\\madhu.akula\\Documents\\Elastic\\aaa\\bat"));
     		  BufferedReader stdInput7 = new BufferedReader(new InputStreamReader(p.getInputStream()));
     		  String s1 = "";
     		  
     	   	while ((s1 = stdInput7.readLine()) != null)
     	    {
     	   		if(s1.contains("TCP")) {
     	   			s1=s1.substring(s1.lastIndexOf("LISTENING       ")+16,s1.length());
     	   			System.out.println("process id"+s1);
     	   			
     	   			System.out.println("here i nedd to write the shut down the logictaskkill  /F  /PID  "+s1);
     	   			Process kill=Runtime.getRuntime().exec("taskkill  /F  /PID  "+s1);
     	   		BufferedReader std = new BufferedReader(new InputStreamReader(kill.getInputStream()));
     	   	String s2 = "";
     	  while ((s2 = std.readLine()) != null)
     	    {
     	   		System.out.println(s2);
     	   		}
     	   		}
     	    }
     		  
     	  }
     	 
  
   }
  	
   System.out.println("processed CPU Log files completed");
   File directory = new File("D:\\new\\logstash-7.1.1\\data\\plugins\\inputs\\file");
 	 
 	 File[] files = directory.listFiles();
 	 
 	 for (File file : files){
 	 file.delete();
 	 }
}catch(Exception e ) {
System.out.println("error");
}
            
	/* File directory = new File("D:\\new\\logstash-7.1.1\\data\\plugins\\inputs\\file");
	 
	 File[] files = directory.listFiles();
	 
	 for (File file : files){
	 file.delete();
	 }*/
   	
    
    /*Process cpu = null;
	
	             try
	             {
	            String s = "";
	            String [] cmd=null;
	            int lines = 0;
	            cmd = new String[] { "D:\\new\\logstash-7.1.1\\bin\\logstash.bat","--pipeline.workers","1","--pipeline.batch.size","1","-f", "D:\\new\\logstash-7.1.1\\bin\\update_new_1.conf"};
	            cpu = Runtime.getRuntime().exec(cmd);
	            BufferedReader stdInput = new BufferedReader(new InputStreamReader(cpu.getInputStream()));
	           	while ((s = stdInput.readLine()) != null)
	            {
	           		System.out.println(s);
	              System.out.println("within the loop");
	              
		           File f=new File("D:\\new\\logstash-7.1.1\\data\\plugins\\inputs\\file");
		           	File[] listFiles = f.listFiles();
		           	for(File file:listFiles) {
		           	System.out.println(file.getAbsolutePath());
		           	BufferedReader reader = new BufferedReader(new FileReader(file.getAbsolutePath()));
		           	String readdata;
		           	while ((readdata=reader.readLine()) != null) {
		           		
		           		lines++;
		           		System.out.println(readdata);
		           	}
		           	reader.close();
		            }
	              	  System.out.println("Total count"+lines);
	              	  if(lines==8) {
	              		Thread.sleep(30000);
	              		  System.out.println("logstash was going to shut down");
	              		  System.out.println("ok need to shut");
	              		
	              		 // Thread.sleep(60000);
	              		  System.out.println("ok");
	              		//Thread.sleep(60000);
	              		  
	              		 Process p = Runtime.getRuntime().exec( 
	              				  new String[]{"cmd", "/c", "running.bat"},
	              				  null, 
	              				  new File("C:\\Users\\madhu.akula\\Documents\\Elastic\\aaa\\bat"));
	              		  BufferedReader stdInput7 = new BufferedReader(new InputStreamReader(p.getInputStream()));
	              		  String s1 = "";
	              		  
	              	   	while ((s1 = stdInput7.readLine()) != null)
	              	    {
	              	   		if(s1.contains("TCP")) {
	              	   			s1=s1.substring(s1.lastIndexOf("LISTENING       ")+16,s1.length());
	              	   			System.out.println("process id"+s1);
	              	   			
	              	   			System.out.println("here i nedd to write the shut down the logictaskkill  /F  /PID  "+s1);
	              	   			Process kill=Runtime.getRuntime().exec("taskkill  /F  /PID  "+s1);
	              	   		BufferedReader std = new BufferedReader(new InputStreamReader(kill.getInputStream()));
	              	   	String s2 = "";
	              	  while ((s2 = std.readLine()) != null)
	              	    {
	              	   		System.out.println(s2);
	              	   		}
	              	   		}
	              	    }
	              		  
	              	  }
	              	 
	           
	            }
	           	
	            System.out.println("processed CPU Log files completed");
	    }catch(Exception e ) {
	    	System.out.println("error");
	    }*/

	}
}
