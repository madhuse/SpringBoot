package com.otsi.ApacheKafka;



import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Map;
import java.util.Properties;
import java.util.concurrent.ExecutionException;

import org.apache.kafka.clients.consumer.ConsumerRecord;
import org.apache.kafka.clients.consumer.ConsumerRecords;
import org.apache.kafka.clients.consumer.KafkaConsumer;
import org.apache.kafka.common.errors.WakeupException;
import org.elasticsearch.action.index.IndexAction;
import org.elasticsearch.action.index.IndexRequestBuilder;
import org.elasticsearch.client.Client;
import org.elasticsearch.common.xcontent.XContentFactory;
import org.json.JSONObject;

import com.fasterxml.jackson.core.JsonProcessingException;

import io.krakens.grok.api.Grok;
import io.krakens.grok.api.GrokCompiler;
import io.krakens.grok.api.Match;
import io.krakens.grok.api.exception.GrokException;
import scala.Option;


/**
 * Hello world!
 *
 */
public class Log 
{
	public static void main(String[] args)  throws GrokException, IOException,ParseException {
		
		
Client client = ESConnection.getConnection();
		
		Properties properties = new Properties();
		InputStream inputStream;
		inputStream = new FileInputStream("D:\\pdf workspace\\ApacheKafka\\src\\main\\java\\config.properties");
		properties.load(inputStream);
		properties.put("bootstrap.servers", properties.getProperty("kafkahost"));
		properties.put("key.deserializer", properties.getProperty("keydeserializer"));
		properties.put("value.deserializer", properties.getProperty("valuedeserializer"));
		properties.put("group.id", properties.getProperty("groupid"));
		properties.put("auto.offset.reset", properties.getProperty("autooffsetreset"));
		
		KafkaConsumer kafkaConsumer = new KafkaConsumer<String, String>(properties);
		//Map<String,List> m= (Map<String, List>) kafkaConsumer.listTopics().keySet();

		List topics = new ArrayList();
		// topics.add("FilebeatTopic");
		topics.add("demoeasylogs");
		kafkaConsumer.subscribe(topics);
       System.out.println("hhhhhhhh");
       // String type="otsieasy6logs";
		try {
			while (true) {
				//System.out.println("......"+count++);
				ConsumerRecords<String, String> records = kafkaConsumer.poll(100);
				
				//BulkRequestBuilder bulkRequest = client.prepareBulk();
				for (ConsumerRecord<String, String> record : records) {
					
					//System.out.println(record.value());
					JSONObject jsonObj = new JSONObject(record.value());
					
					String message = (String) jsonObj.get("message");
			System.out.println(message);
		GrokCompiler grokCompiler = GrokCompiler.newInstance();
		grokCompiler.registerDefaultPatterns();
	    Grok grok=null;
	    Match gm=null;
	    Map<String, Object> capture=null;
	    String level=null;
		String requestdate=null;
		String classname=null;
		String method=null;
		String text=null;
		String localIp=null;
		String externalIp=null;
	    //String message="[2018-08-09T12:47:51,655][WARN ][o.e.t.n.Netty4Transport  ] [6viEJOp] exception caught on transport layer [NettyTcpChannel{localAddress=/192.168.1.101:9300, remoteAddress=/192.168.1.101:59537}], closing connection";
	    
	       	 grok=   grokCompiler.compile("%{DATA:level} %{TIMESTAMP_ISO8601:date} %{DATA:classname} %{DATA:method} - %{GREEDYDATA:text}");
	       	 gm = grok.match(message);
	         capture =  gm.capture();
	         if(!capture.isEmpty()) {
	        	 
	        	 if((String)capture.get("level")!=null) {
						level=(String) capture.get("level");
					}
					if((String)capture.get("classname")!=null) {
						classname=(String) capture.get("classname");
					}
					if((String)capture.get("method")!=null) {
						method=(String) capture.get("method");
					}
					if((String)capture.get("date")!=null) {
						requestdate=(String) capture.get("date");
					}
					if((String)capture.get("text")!=null) {
						text=(String) capture.get("text");
					}
					if((String)capture.get("localip")!=null) {
						localIp=(String) capture.get("localip");
					}
					if((String)capture.get("externalip")!=null) {
						externalIp=(String) capture.get("externalip");
					}
					System.out.println(requestdate);
					//2019-03-12 16:33:38,392
					SimpleDateFormat isoFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss,SSS");
					
					Date date = null;
					
					date = isoFormat.parse(requestdate);
					IndexRequestBuilder indexRequestBuilder=new IndexRequestBuilder(client, IndexAction.INSTANCE);
					try {
						indexRequestBuilder.setSource(XContentFactory.jsonBuilder()
						         .startObject()
						         
						         .field("level",level)
							         .field("classname", classname)
							         .field("method", method)
							         .field("message", text)
							         .field("date", date)
							         .field("locallIpAddress", localIp)
							         .field("exteranlIpAddress", externalIp)
							         
						         .endObject()
						         
								   )
						.setIndex("demoeasylogs")
						.setPipeline("easylogs_geoip")
						.setType("easylogs");
						
						
					} catch (IOException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
					indexRequestBuilder.execute().actionGet();
				
	         }
	         
	         
	         else if(capture.isEmpty()) {/*
		    	   grok=  grokCompiler.compile("\\[%{DATA:level}\\] %{TIMESTAMP_ISO8601:date} %{DATA:classname} %{DATA:method} - %{GREEDYDATA:text}");
		    		 gm = grok.match(message);
		    	     capture  =  gm.capture();
		    	     if((String)capture.get("level")!=null) {
							level=(String) capture.get("level");
						}
						if((String)capture.get("classname")!=null) {
							classname=(String) capture.get("classname");
						}
						if((String)capture.get("method")!=null) {
							method=(String) capture.get("method");
						}
						if((String)capture.get("date")!=null) {
							requestdate=(String) capture.get("date");
						}
						if((String)capture.get("text")!=null) {
							text=(String) capture.get("text");
						}
						SimpleDateFormat isoFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss,SSS");
						
						Date date = null;
						
						date = isoFormat.parse(requestdate);
						IndexRequestBuilder indexRequestBuilder=new IndexRequestBuilder(client, IndexAction.INSTANCE);
						try {
							indexRequestBuilder.setSource(XContentFactory.jsonBuilder()
							         .startObject()
							         
							         .field("level",level)
								         .field("classname", classname)
								         .field("method", method)
								         .field("message", text)
								         .field("date", date)
								        
								         
							         .endObject()
							         
									   )
							.setIndex("otsieasy6logs")
							.setPipeline("easylogs_geoip")
							.setType("doc");
							
							
						} catch (IOException e) {
							// TODO Auto-generated catch block
							e.printStackTrace();
						}
						indexRequestBuilder.execute().actionGet();
					
		       */}
		        
	          
	       }
				}
				} catch (WakeupException e) {
					// ignore for shutdown
				} finally {
					kafkaConsumer.close();
				}
	       
	}
}


