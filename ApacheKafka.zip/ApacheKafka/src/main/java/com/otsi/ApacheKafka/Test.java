package com.otsi.ApacheKafka;

import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Map;
import java.util.Properties;
import java.util.concurrent.ExecutionException;

import org.apache.kafka.clients.consumer.ConsumerRecord;
import org.apache.kafka.clients.consumer.ConsumerRecords;
import org.apache.kafka.clients.consumer.KafkaConsumer;
import org.apache.kafka.common.errors.WakeupException;
import org.elasticsearch.action.index.IndexAction;
import org.elasticsearch.action.index.IndexRequestBuilder;
import org.elasticsearch.client.Client;
import org.elasticsearch.common.xcontent.XContentFactory;
import org.json.JSONObject;

import com.fasterxml.jackson.core.JsonProcessingException;
import io.krakens.grok.api.Grok;
import io.krakens.grok.api.GrokCompiler;
import io.krakens.grok.api.Match;

///https://stackoverflow.com/questions/40952714/filebeat-5-0-output-to-kafka-multiple-topics
public class Test {
	public static void main(String[] args) throws JsonProcessingException, IOException, ParseException {
		Client client = ESConnection.getConnection();

		Properties properties = new Properties();
		InputStream inputStream;
		inputStream = new FileInputStream("D:\\pdf workspace\\ApacheKafka\\src\\main\\java\\config.properties");
		properties.load(inputStream);
		properties.put("bootstrap.servers", properties.getProperty("kafkahost"));
		properties.put("key.deserializer", properties.getProperty("keydeserializer"));
		properties.put("value.deserializer", properties.getProperty("valuedeserializer"));
		properties.put("group.id", properties.getProperty("groupid"));
		properties.put("auto.offset.reset", properties.getProperty("autooffsetreset"));

		
		
		
		
		
		
		KafkaConsumer kafkaConsumer = new KafkaConsumer<String, String>(properties);
		// Map<String,List> m= (Map<String, List>) kafkaConsumer.listTopics().keySet();

		List topics = new ArrayList();
		// topics.add("FilebeatTopic");
		topics.add("event-orsted-v1");
		kafkaConsumer.subscribe(topics);
		
		System.out.println("hhhhhhhh");
		String type = "Apachelogs";
		try {
			while (true) {
				// System.out.println("......"+count++);
				ConsumerRecords<String, String> records = kafkaConsumer.poll(100);
				System.out.println("true" + records.count());
				// BulkRequestBuilder bulkRequest = client.prepareBulk();
				for (ConsumerRecord<String, String> record : records) {
					System.out.println("inside for");
					// System.out.println(record.value());
					JSONObject jsonObj = new JSONObject(record.value());
					System.out.println(jsonObj);
				String message=jsonObj.getString("targetFileInfo");
					System.out.println(jsonObj);
					// System.out.println(kk);
					if (type == "otsieasy6logs") {

						GrokCompiler grokCompiler = GrokCompiler.newInstance();

						grokCompiler.registerDefaultPatterns();

						System.out.println(message);

						/* Grok pattern to compile, here httpd logs */
						final Grok grok = grokCompiler.compile(
								"%{DATA:level} %{TIMESTAMP_ISO8601:date} %{DATA:classname} %{DATA:method} - %{GREEDYDATA:text}");

						Match gm = grok.match(message);
						final Map<String, Object> capture = gm.capture();
						String level = null;
						String requestdate = null;
						String classname = null;
						String method = null;
						String text = null;

						if ((String) capture.get("level") != null) {
							level = (String) capture.get("level");
						}
						if ((String) capture.get("classname") != null) {
							classname = (String) capture.get("classname");
						}
						if ((String) capture.get("method") != null) {
							method = (String) capture.get("method");
						}
						if ((String) capture.get("date") != null) {
							requestdate = (String) capture.get("date");
						}
						if ((String) capture.get("text") != null) {
							text = (String) capture.get("text");
						}

						System.out.println(requestdate);
						// 2019-03-12 16:33:38,392
						SimpleDateFormat isoFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss,SSS");

						Date date = null;

						date = isoFormat.parse(requestdate);

						IndexRequestBuilder indexRequestBuilder = new IndexRequestBuilder(client, IndexAction.INSTANCE);
						try {
							indexRequestBuilder.setSource(XContentFactory.jsonBuilder().startObject()
									

									.field("level", level).field("classname", classname).field("method", method)
									.field("message", text).field("date", date)

									.endObject()

							).setIndex("demoeasylogs")

									.setType("easylogs");

						} catch (IOException e) {
							// TODO Auto-generated catch block
							e.printStackTrace();
						}
						indexRequestBuilder.execute().actionGet();

					} // end of if condition
					if (type == "elasticlogs") {
						System.out.println(message);
						GrokCompiler grokCompiler = GrokCompiler.newInstance();

						grokCompiler.registerDefaultPatterns();
						final Grok grok = grokCompiler.compile(
								"\\[%{DATA:date}\\]\\[%{DATA:loglevel}%{SPACE}\\]\\[%{DATA:class}] \\[%{DATA:nodename}\\] %{GREEDYDATA:text}");

						Match gm = grok.match(message);
						final Map<String, Object> capture = gm.capture();
						// 2018-08-09T12:18:06,065

						String level = null;
						String requestdate = null;
						String classname = null;
						String nodename = null;
						String text = null;
						if ((String) capture.get("loglevel") != null) {
							level = (String) capture.get("loglevel");
						}
						if ((String) capture.get("date") != null) {
							requestdate = (String) capture.get("date");
						}
						if ((String) capture.get("class") != null) {
							classname = (String) capture.get("class");
						}
						if ((String) capture.get("nodename") != null) {
							nodename = (String) capture.get("nodename");
						}
						if ((String) capture.get("text") != null) {
							text = (String) capture.get("text");
						}

						SimpleDateFormat isoFormat = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss,SSS");

						Date date = null;

						date = isoFormat.parse(requestdate);

						IndexRequestBuilder indexRequestBuilder = new IndexRequestBuilder(client, IndexAction.INSTANCE);
						try {
							indexRequestBuilder.setSource(XContentFactory.jsonBuilder().startObject()

									.field("level", level).field("classname", classname).field("nodename", nodename)
									.field("text", text).field("date", date)

									.endObject()

							).setIndex(type).setType("doc");

						} catch (IOException e) {
							// TODO Auto-generated catch block
							e.printStackTrace();
						}
						indexRequestBuilder.execute().actionGet();

					}

					else if (type == "Apachelogs") {
						GrokCompiler grokCompiler = GrokCompiler.newInstance();
						grokCompiler.registerDefaultPatterns();

						/* Grok pattern to compile, here httpd logs */
						final Grok grok = grokCompiler.compile(
								"%{HOSTNAME:clientip} - - \\[%{DATA:requestdate}\\] \"%{WORD:requestmethodtype} /imagerec/%{DATA:requesturl} %{DATA:protocal}/%{NUMBER:protocalversion}\" %{INT:responsecode} %{DATA:responsetime}");

						System.out.println("message" + message);
						Match gm = grok.match(message);
						if (gm != Match.EMPTY) {

							final Map<String, Object> capture = gm.capture();
							String clientip = null;
							String requestdate = null;
							String requestmethodtype = null;
							String requesturl = null;
							String protocal = null;
							String responsecode = null;
							String protocalversion = null;
							String responsetime = null;
							if ((String) capture.get("clientip") != null) {
								clientip = (String) capture.get("clientip");
							}
							if ((String) capture.get("requestdate") != null) {
								requestdate = (String) capture.get("requestdate");
							}
							if ((String) capture.get("requestmethodtype") != null) {
								requestmethodtype = (String) capture.get("requestmethodtype");
							}
							if ((String) capture.get("requesturl") != null) {
								requesturl = (String) capture.get("requesturl");
								requesturl = "/imagerec/" + requesturl;
							}
							if ((String) capture.get("protocal") != null) {
								protocal = (String) capture.get("protocal");
							}

							if ((String) capture.get("protocalversion") != null) {
								protocalversion = (String) capture.get("protocalversion");
							}
							if ((String) capture.get("responsecode") != null) {
								responsecode = (String) capture.get("responsecode");
							}
							if ((String) capture.get("responsetime") != null) {
								responsetime = (String) capture.get("responsetime");
							}
							System.out.println("clientip" + clientip);
							System.out.println("responsetime" + responsetime);
							System.out.println("responsecode" + responsecode);
							System.out.println("protocalversion" + protocalversion);
							System.out.println("protocal" + protocal);
							System.out.println("requesturl" + requesturl);
							System.out.println("requestmethodtype" + requestmethodtype);
							System.out.println("requestdate" + requestdate);
							// System.out.println("requesturl"+requesturl);
							SimpleDateFormat isoFormat = new SimpleDateFormat("dd/MMM/yyyy:HH:mm:ss Z");
							// 07/May/2018:13:05:41 +0530
							Date date = null;
							if (requestdate != null) {
								date = isoFormat.parse(requestdate);
							}
							IndexRequestBuilder indexRequestBuilder = new IndexRequestBuilder(client,
									IndexAction.INSTANCE);
							try {
								indexRequestBuilder.setSource(XContentFactory.jsonBuilder().startObject()

										.field("Ipaddress", clientip).field("methodType", requestmethodtype)
										.field("responseCode", responsecode).field("protocoal", protocal)
										.field("requestdate", date).field("responsetime", responsetime)
										.field("requesturl", requesturl).field("protocalversion", protocalversion)

										.endObject()

								).setIndex("accesslogs");

							} catch (IOException e) {
								// TODO Auto-generated catch block
								e.printStackTrace();
							}
							indexRequestBuilder.execute().actionGet();

						} // else if condition
					}
				} // for loop close

			} // end of while

		} catch (WakeupException e) {
			// ignore for shutdown
		} finally {
			kafkaConsumer.close();
		}
	}

}
