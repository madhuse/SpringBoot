package com.otsi.ApacheKafka;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;

import org.elasticsearch.action.search.SearchRequestBuilder;
import org.elasticsearch.action.search.SearchResponse;
import org.elasticsearch.client.Client;
import org.elasticsearch.index.query.QueryBuilders;
import org.elasticsearch.index.reindex.BulkByScrollResponse;
import org.elasticsearch.index.reindex.DeleteByQueryAction;
import org.elasticsearch.index.reindex.DeleteByQueryRequestBuilder;
import org.elasticsearch.index.reindex.ReindexAction;
import org.elasticsearch.index.reindex.ReindexRequestBuilder;
import org.elasticsearch.index.reindex.UpdateByQueryAction;
import org.elasticsearch.index.reindex.UpdateByQueryRequestBuilder;
import org.elasticsearch.script.Script;
import org.elasticsearch.search.aggregations.AggregationBuilders;
import org.elasticsearch.search.aggregations.bucket.histogram.DateHistogramAggregationBuilder;
import org.elasticsearch.search.aggregations.bucket.histogram.DateHistogramInterval;
import org.elasticsearch.search.aggregations.bucket.histogram.Histogram;
import org.elasticsearch.search.aggregations.metrics.max.Max;
import org.elasticsearch.search.aggregations.metrics.max.MaxAggregationBuilder;
import org.joda.time.DateTime;

public class BeforeDayRun 
{
	
public static void main(String[] args) throws Exception{
	Client client = ESConnection.getConnection();
	BulkByScrollResponse response1 =
			  new DeleteByQueryRequestBuilder(client, DeleteByQueryAction.INSTANCE)
			    .filter(QueryBuilders.matchAllQuery()) 
			    .source("forecasteddata")                         
			    .get();                                             
			long deleted1 = response1.getDeleted();  
			System.out.println(deleted1);
			Thread.sleep(60000);
			System.out.println("Updating Forecasted Data");
			
			
			
			SearchRequestBuilder searchbuilder=client.prepareSearch("xyz_new_backupdata");
		    MaxAggregationBuilder aggregation =
				        AggregationBuilders
				        .max("maxdate").field("source_start_date");
				        
		    
			searchbuilder.addAggregation(aggregation);
	        SearchResponse searchResponse=searchbuilder.execute().actionGet();
	        Max agg = searchResponse.getAggregations().get("maxdate");
	        String name = agg.getValueAsString();
	        System.out.println(name);
	        
	        Date presentdate = new Date();
	    	//Date daysAgo14 = new DateTime(presentdate).minusDays(1).toDate();
	    	//Date extra30 = new DateTime(date).plusDays(extradate).toDate();
	    	DateFormat dateFormat1 = new SimpleDateFormat("dd-MM-YYYY");
	    	//Date parse = dateFormat1.parse(name);
	    	System.out.println("nnn"+dateFormat1.parse(name));
	    	//System.out.println("Changed Date"+dateFormat1.format(daysAgo14));
	    	System.out.println("Changed to"+dateFormat1.format(presentdate));
	    	
			 if (name.compareTo(dateFormat1.format(presentdate)) == 0)  {
	    	    System.out.println(" same day");
	    	    System.out.println("condition was matched");
	    	    
	    	    BulkByScrollResponse response =
	  				  new DeleteByQueryRequestBuilder(client, DeleteByQueryAction.INSTANCE)
	  				    .filter(QueryBuilders.matchAllQuery()) 
	  				    .source("currentdaydata")                         
	  				    .get();                                             
	  				long deleted = response.getDeleted();  
	  				System.out.println(deleted);
	  		
	  				
	  				Thread.sleep(60000);
	  				SearchRequestBuilder searchprevious=client.prepareSearch("previousdaydata");
				    DateHistogramAggregationBuilder aggregationprevious =
						        AggregationBuilders
						        .dateHistogram("agg")
						        .dateHistogramInterval(DateHistogramInterval.DAY)
						        
				    .field("source_start_date");
				    searchprevious.addAggregation(aggregationprevious);
				    
			        SearchResponse searchResponseprevious=searchprevious.execute().actionGet();
					
					
			        Histogram aggprevious = searchResponseprevious.getAggregations().get("agg");
			        for (Histogram.Bucket entry : aggprevious.getBuckets()) {
			              // Key
			            String keyAsString = entry.getKeyAsString();
			            Date date = new Date();
			           // Date extra30 = new DateTime(date).minus(1).toDate();
			           // DateFormat dateFormat1 = new SimpleDateFormat("dd-MM-YYYY");
					UpdateByQueryRequestBuilder ssislive = UpdateByQueryAction.INSTANCE.newRequestBuilder(client);
			        
					Script script1 = new Script("ctx._source.source_start_date = '"+dateFormat1.format(date)+"'");

					BulkByScrollResponse r1 = ssislive.source("previousdaydata")
					                                       //min date
					    .filter(QueryBuilders.termQuery("source_start_date", keyAsString))
					    .script(script1)  
					    .get();
					System.out.println(r1);
			        }

			        Thread.sleep(60000);
	  				
	  				
	  				BulkByScrollResponse finalres =
	  					  new ReindexRequestBuilder(client, ReindexAction.INSTANCE)
	  					    .source("previousdaydata")
	  					    .destination("currentdaydata")
	  					    .filter(QueryBuilders.matchAllQuery())
	  					    .get();
	  			System.out.println(finalres);
	  			Thread.sleep(60000);
	    	}
			 else {
				 System.out.println("condition was not matched");
				 SearchRequestBuilder searchprevious=client.prepareSearch("currentdaydata");
				    DateHistogramAggregationBuilder aggregationprevious =
						        AggregationBuilders
						        .dateHistogram("agg")
						        .dateHistogramInterval(DateHistogramInterval.DAY)
						        
				    .field("source_start_date");
				    searchprevious.addAggregation(aggregationprevious);
				    
			        SearchResponse searchResponseprevious=searchprevious.execute().actionGet();
					
					
			        Histogram aggprevious = searchResponseprevious.getAggregations().get("agg");
			        for (Histogram.Bucket entry : aggprevious.getBuckets()) {
			              // Key
			            String keyAsString = entry.getKeyAsString();
				 Date date = new Date();
				 UpdateByQueryRequestBuilder ssislive = UpdateByQueryAction.INSTANCE.newRequestBuilder(client);
			        
					Script script1 = new Script("ctx._source.source_start_date = '"+dateFormat1.format(date)+"'");

					BulkByScrollResponse r1 = ssislive.source("currentdaydata")
					                                       //min date
					    .filter(QueryBuilders.termQuery("source_start_date", keyAsString))
					    .script(script1)  
					    .get();
					System.out.println(r1);
			        }
			 }
			Thread.sleep(60000);
			 Date date = new Date();
			
			 BulkByScrollResponse response11 =
					  new DeleteByQueryRequestBuilder(client, DeleteByQueryAction.INSTANCE)
					    .filter(QueryBuilders.matchQuery("source_start_date", dateFormat1.format(date))) 
					    .source("xyz_new_backupdata")                         
					    .get();                                             
					long deleted11 = response11.getDeleted();  
					System.out.println(deleted11); 
					Thread.sleep(60000);
	
	System.out.println("hello world");
	}
}