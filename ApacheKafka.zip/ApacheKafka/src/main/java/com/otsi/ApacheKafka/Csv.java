package com.otsi.ApacheKafka;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.net.URLEncoder;
import java.nio.file.Files;
import java.nio.file.attribute.BasicFileAttributes;
import java.nio.file.attribute.FileOwnerAttributeView;
import java.nio.file.attribute.FileTime;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;

import org.apache.commons.io.FilenameUtils;
import org.elasticsearch.action.search.SearchRequestBuilder;
import org.elasticsearch.action.search.SearchResponse;
import org.elasticsearch.client.Client;
import org.elasticsearch.index.query.QueryBuilders;
import org.elasticsearch.search.SearchHit;
import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;

import lombok.Data;
import lombok.Getter;
import lombok.Setter;


public class Csv {
public static void main(String[] args) throws Exception{
	//String urlnew="http://10.80.2.9:1234/elapsed_time/["+table_name_new+","+recordscount+","+cpudata+","+memorydata+"]";
	//https://stackoverflow.com/questions/11202934/get-latitude-longitude-from-given-address-name-not-geocoder
	//System.out.println(URLEncoder.encode(inputdata.toString(), "UTF-8"));
	//String table_name_new=;
	//table_name_new=table_name_new.replaceAll("_", "%20");
	/*String url1="Telanaga&key=AIzaSyBvwHBPcyxDRh0NA0l4Ih4eNuT0Ce_4dfw";
	URLEncoder.encode(url1, "UTF-8");
	url1=url1.replaceAll(" ", "%23");
	URL url = new URL(
            "https://maps.googleapis.com/maps/api/geocode/json?address="+url1);
        HttpURLConnection conn = (HttpURLConnection) url.openConnection();
        
        conn.setRequestMethod("GET");
        
        conn.setDoOutput(true);
        
        InputStreamReader in = new InputStreamReader(conn.getInputStream());
       String output=null;
        BufferedReader br = new BufferedReader(in);
        while ((output = br.readLine()) != null) {
        	System.out.println(output);*/
	
	
        	/*JSONParser parser = new JSONParser();
            JSONObject json = (JSONObject) parser.parse(output);
            JSONArray arr=(JSONArray) json.get("results");
            JSONObject object = (JSONObject) arr.get(0);
            JSONObject tt= (JSONObject) object.get("geometry");
            JSONObject location=(JSONObject) tt.get("location");
            Double lng=(Double) location.get("lng");
            Double lat=(Double) location.get("lat");
            System.out.println(lng);
            System.out.println(lat);*/
     //   }
       // }
        
        /*String output="{\r\n" + 
        		"   \"results\" : [\r\n" + 
        		"      {\r\n" + 
        		"         \"address_components\" : [\r\n" + 
        		"            {\r\n" + 
        		"               \"long_name\" : \"Sanjeeva Reddy Nagar\",\r\n" + 
        		"               \"short_name\" : \"SR Nagar\",\r\n" + 
        		"               \"types\" : [ \"political\", \"sublocality\", \"sublocality_level_1\" ]\r\n" + 
        		"            },\r\n" + 
        		"            {\r\n" + 
        		"               \"long_name\" : \"Hyderabad\",\r\n" + 
        		"               \"short_name\" : \"Hyderabad\",\r\n" + 
        		"               \"types\" : [ \"locality\", \"political\" ]\r\n" + 
        		"            },\r\n" + 
        		"            {\r\n" + 
        		"               \"long_name\" : \"Hyderabad\",\r\n" + 
        		"               \"short_name\" : \"Hyderabad\",\r\n" + 
        		"               \"types\" : [ \"administrative_area_level_2\", \"political\" ]\r\n" + 
        		"            },\r\n" + 
        		"            {\r\n" + 
        		"               \"long_name\" : \"Telangana\",\r\n" + 
        		"               \"short_name\" : \"Telangana\",\r\n" + 
        		"               \"types\" : [ \"administrative_area_level_1\", \"political\" ]\r\n" + 
        		"            },\r\n" + 
        		"            {\r\n" + 
        		"               \"long_name\" : \"India\",\r\n" + 
        		"               \"short_name\" : \"IN\",\r\n" + 
        		"               \"types\" : [ \"country\", \"political\" ]\r\n" + 
        		"            },\r\n" + 
        		"            {\r\n" + 
        		"               \"long_name\" : \"500038\",\r\n" + 
        		"               \"short_name\" : \"500038\",\r\n" + 
        		"               \"types\" : [ \"postal_code\" ]\r\n" + 
        		"            }\r\n" + 
        		"         ],\r\n" + 
        		"         \"formatted_address\" : \"Sanjeeva Reddy Nagar, Hyderabad, Telangana 500038, India\",\r\n" + 
        		"         \"geometry\" : {\r\n" + 
        		"            \"bounds\" : {\r\n" + 
        		"               \"northeast\" : {\r\n" + 
        		"                  \"lat\" : 17.451547,\r\n" + 
        		"                  \"lng\" : 78.449641\r\n" + 
        		"               },\r\n" + 
        		"               \"southwest\" : {\r\n" + 
        		"                  \"lat\" : 17.4406011,\r\n" + 
        		"                  \"lng\" : 78.438318\r\n" + 
        		"               }\r\n" + 
        		"            },\r\n" + 
        		"            \"location\" : {\r\n" + 
        		"               \"lat\" : 17.4436497,\r\n" + 
        		"               \"lng\" : 78.4458259\r\n" + 
        		"            },\r\n" + 
        		"            \"location_type\" : \"APPROXIMATE\",\r\n" + 
        		"            \"viewport\" : {\r\n" + 
        		"               \"northeast\" : {\r\n" + 
        		"                  \"lat\" : 17.451547,\r\n" + 
        		"                  \"lng\" : 78.449641\r\n" + 
        		"               },\r\n" + 
        		"               \"southwest\" : {\r\n" + 
        		"                  \"lat\" : 17.4406011,\r\n" + 
        		"                  \"lng\" : 78.438318\r\n" + 
        		"               }\r\n" + 
        		"            }\r\n" + 
        		"         },\r\n" + 
        		"         \"place_id\" : \"ChIJxWJma-eQyzsRjst3sJVs2Zo\",\r\n" + 
        		"         \"types\" : [ \"political\", \"sublocality\", \"sublocality_level_1\" ]\r\n" + 
        		"      }\r\n" + 
        		"   ],\r\n" + 
        		"   \"status\" : \"OK\"\r\n" + 
        		"}\r\n" + 
        		"";
       
       System.out.println(output);
       JSONParser parser = new JSONParser();
       JSONObject json = (JSONObject) parser.parse(output);
       JSONArray arr=(JSONArray) json.get("results");
       JSONObject object = (JSONObject) arr.get(0);
       JSONObject tt= (JSONObject) object.get("geometry");
       JSONObject location=(JSONObject) tt.get("location");
       Double lng=(Double) location.get("lng");
       Double lat=(Double) location.get("lat");
       System.out.println(lng);
       System.out.println(lat);*/
       
       
//}
       // }
	
/*Client client = ESConnection.getConnection();
SearchRequestBuilder searchbuilder=client.prepareSearch("slanumbers");
searchbuilder.setQuery(QueryBuilders.matchQuery("table.keyword", "order"));
searchbuilder.setSize(1);
SearchResponse searchResponse=searchbuilder.execute().actionGet();

SearchHit[] searchHits = searchResponse.getHits().getHits();
for (SearchHit searchHit : searchHits) {
      String hitJson = searchHit.getSourceAsString();
      JSONParser parser = new JSONParser(); 
      JSONObject json = (JSONObject) parser.parse(hitJson);
      Double slatimefromindex=(Double) json.get("slatime");
      System.out.println(slatimefromindex);
}
String table="customer";
if(table=="customer") {
	System.out.println("0000000000000000");
}*/
/*DateFormat dateFormat = new SimpleDateFormat("dd-MM-YYYY");
Date date = new Date();
System.out.println(dateFormat.format(date));
File f=new File("\\\\192.168.1.33\\Datasets_For_ETL_Logs\\SSRS_Day21\\SSRS Logs");
File[] listFiles = f.listFiles();
for(File onefile:listFiles) {
if(onefile.isFile()) {
File  dir=new File("D:\\new\\logstash-7.1.1\\"+dateFormat.format(date)+"_ssis110");

dir.mkdir();

Process processes = null;
 try
{

        String s = "";
        String[] cmd=null;
         cmd = new String[] { "D:\\new\\logstash-7.1.1\\bin\\logstash.bat","--path.data",dir.getAbsolutePath(),"--pipeline.workers","1","--pipeline.batch.size","1","-f", "D:\\new\\logstash-7.1.1\\bin\\update_new_1.conf", "<", onefile.getAbsolutePath()};
        processes = Runtime.getRuntime().exec(cmd);
       	            BufferedReader stdInput = new BufferedReader(new InputStreamReader(processes.getInputStream()));
        while ((s = stdInput.readLine()) != null)
        {
               System.out.println(s);
        }

        System.out.println("processing completed for"+onefile.getAbsolutePath());
        //onefile.deleteOnExit();
}catch(Exception e ) {
	System.out.println("error");
}
	} //if condition

	} //for condition
System.out.println("Processed all the SSIS log files");
*/	
	
	//String xlfile="C:\\POLING DATA\\EG\\AC035\\excel files\\S01A035P001.PDF.xls";
	//File file = new File("C:\\Users\\madhu.akula\\Desktop\\Book1.xlsx");
	String csvFile = "C:\\Users\\madhu.akula\\Downloads\\Both-20.CSV";
	
    BufferedReader br = null;
    String line = "";
   // String cvsSplitBy = ",";
    String contents=null;

    try {

        br = new BufferedReader(new FileReader(csvFile));
        while ((line = br.readLine()) != null) {
System.out.println(line);
contents=line;
//contents+=line;
//System.out.println(contents);
            // use comma as separator
           // String[] country = line.split("/n");

            //for(String csvdata:country) {
            //	System.out.println(csvdata);
            ///}

        }

    } catch (FileNotFoundException e) {
        e.printStackTrace();
    } catch (IOException e) {
        e.printStackTrace();
    } finally {
        if (br != null) {
            try {
                br.close();
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
    }
}}
