package com.otsi.ApacheKafka;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;

public class CpuReading {
public static void main(String[] args)throws FileNotFoundException,IOException {
	int count=0;
	 File f=new File("D:\\new\\logstash-7.1.1\\data\\plugins\\inputs\\file");
		File[] listFiles = f.listFiles();
		for(File file:listFiles) {
			//InputStreamReader r=new InputStreamReader(new File(InputStreamReader.));    
	     BufferedReader br=new BufferedReader(new FileReader(file.getAbsolutePath()));
	     System.out.println("file path is"+file.getAbsolutePath());
	  String strCurrentLine;
	  System.out.println("reading data"+br.readLine().length());
	  while ((strCurrentLine = br.readLine()) != null) {
		count++;
	    System.out.println("files read count"+count);
	 System.out.println("message"+strCurrentLine);
	   }
	  br.close();
		}
	/*File f=new File("D:\\new\\logstash-7.1.1\\data\\plugins\\inputs\\file");
	File[] listFiles = f.listFiles();
	for(File file:listFiles) {
	
	BufferedReader reader = new BufferedReader(new FileReader(file.getAbsolutePath()));
	int lines = 0;
	while (reader.readLine() != null) {
		
		lines++;
		System.out.println(lines);
	}
	reader.close();*/
//}
}
}
