package com.otsi.ApacheKafka;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;
import java.nio.file.Files;
import java.nio.file.attribute.BasicFileAttributes;
import java.nio.file.attribute.FileOwnerAttributeView;
import java.nio.file.attribute.FileTime;
import java.nio.file.attribute.UserPrincipal;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.List;
import java.nio.file.LinkOption;
import org.apache.commons.io.FilenameUtils;
import org.elasticsearch.action.index.IndexResponse;
import org.elasticsearch.client.Client;
import org.elasticsearch.common.xcontent.XContentType;
import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;


import com.opencsv.CSVReader;

public class CsvReader 
{
	public static void main(String[] args)  {
		Client client = ESConnection.getConnection();
		String csvFile = "C:\\Users\\madhu.akula\\Downloads\\Both-20.CSV";
        Csv csvObj=new Csv();
        CSVReader reader = null;
        String statename="JHARKHAND";
        String sdtcode=null;
        String tvcode=null;
        String districtName=null;
        String subDistrictName=null;
        String villageName=null;
        try {
            reader = new CSVReader(new FileReader(csvFile));
            String[] line;
           
            
            while ((line = reader.readNext()) != null) {
            	//System.out.println(line.length);
            //	System.out.println(line[0]+" "+line[1]+" "+line[2]+" "+line[3]+" "+line[4]+" "+line[5]+" "+line[6]);
                //System.out.println("Country [id= " + line[0] + ", code= " + line[1] + " , name=" + line[2] + "]");
            	//csvObj.setStateName("JHARKHAND");
            	/*districtName=line[2];
            	districtName = districtName.replaceAll("\'","");
            	sdtcode=line[3];
            	sdtcode = sdtcode.replaceAll("\'","");
            	System.out.println(sdtcode);
            	subDistrictName=line[4];
            	subDistrictName = subDistrictName.replaceAll("\'","");
            	tvcode=line[5];
            	tvcode = tvcode.replaceAll("\'","");
            	System.out.println(tvcode);
            	villageName=line[6];
            	villageName = villageName.replaceAll("\'","");*/
            	
/*            	try {
            		
            		
            	 URL url=null;
            	 if(districtName.equals(subDistrictName)&&districtName.equals(villageName)) {
            		String url1=statename+"&key=AIzaSyBvwHBPcyxDRh0NA0l4Ih4eNuT0Ce_4dfw";
            		URLEncoder.encode(url1, "UTF-8");
            		url1=url1.replaceAll(" ", "%23");
            		 url = new URL(url1);
            	}
            	else if(sdtcode.equals("00000")&&tvcode.equals("000000")) {
            		String url1=statename+" "+districtName+"&key=AIzaSyBvwHBPcyxDRh0NA0l4Ih4eNuT0Ce_4dfw";
            		URLEncoder.encode(url1, "UTF-8");
            		url1=url1.replaceAll(" ", "%23");
            		 url = new URL(url1);
                	System.out.println("send state and district names only");
                	
                	
                }
                else if(tvcode.equals("000000")) {
                	String url11=statename+" "+districtName+" "+subDistrictName+"&key=AIzaSyBvwHBPcyxDRh0NA0l4Ih4eNuT0Ce_4dfw";
                	url11=url11.replaceAll(" ", "%23");
                	url = new URL(url11);
                	
                	System.out.println("send state and district and sub district only");
                	
                }
                else {
                	String url11=statename+" "+districtName+" "+subDistrictName+" "+villageName+"&key=AIzaSyBvwHBPcyxDRh0NA0l4Ih4eNuT0Ce_4dfw";
                	URLEncoder.encode(url11, "UTF-8");
                	url11=url11.replaceAll(" ", "%23");
                	url = new URL(url11);
                	System.out.println("send all the parameters");
                	
                	
                	
                }
            	
          	  JSONObject json = null;
          	
          		
                //your url i.e fetch data from .
                  HttpURLConnection conn = (HttpURLConnection) url.openConnection();
                  conn.setRequestMethod("GET");
                  conn.setRequestProperty("Accept", "application/json");
                  System.out.println(conn.getResponseCode());
                  System.out.println(conn.getResponseMessage());
                  if (conn.getResponseCode() != 200) {
                      throw new RuntimeException("Failed : HTTP Error code : "
                              + conn.getResponseCode());
                  }
                  InputStreamReader in = new InputStreamReader(conn.getInputStream());
                  BufferedReader br = new BufferedReader(in);
                  String output;
                  while ((output = br.readLine()) != null) {
                      System.out.println(output);
                      JSONParser parser = new JSONParser();
                      JSONArray jsonArray = (JSONArray) parser.parse(output);
                      
                      json = (JSONObject) jsonArray.get(0);
          		    System.out.println( json .get("lat"));
                      System.out.println(json.get("lan"));
                      IndexResponse response = client.prepareIndex("pythonstreaming", "doc")
                  	        .setSource(json, XContentType.JSON)
                  	        .get();
                      System.out.println(response.getId());
                       }
                  conn.disconnect();

              } catch (Exception e) {
                  System.out.println("Exception in getting data- " + e);
              }*/
            	
            	
                
	}
        
	 } catch (IOException e) {
         e.printStackTrace();
     }
        
        
        String contents=null;
        try { 
        	File csvFileinput=new File(csvFile);
        	BasicFileAttributes attr = Files.readAttributes(csvFileinput.toPath(), BasicFileAttributes.class,
					LinkOption.values());
			FileTime lastmodified = attr.lastModifiedTime();
			FileTime creationTime = attr.creationTime();
			SimpleDateFormat sdf = new SimpleDateFormat("EEE MMM dd HH:mm:ss +0530 yyyy");
			String modifiedDate = sdf.format(Long.valueOf(lastmodified.toMillis()));
			System.out.println("modifiedDate" + modifiedDate);
			String createdDate = sdf.format(Long.valueOf(creationTime.toMillis()));
			System.out.println("createdDate" + createdDate);
			String fileExtension = FilenameUtils.getExtension(csvFileinput.getName());
			System.out.println("fileExtension::" + fileExtension);
			FileOwnerAttributeView foav = Files.getFileAttributeView(csvFileinput.toPath(), FileOwnerAttributeView.class);
			UserPrincipal owner = foav.getOwner();
			System.out.format("Original owner" + owner.getName());

        	
            FileReader filereader = new FileReader(csvFileinput); 
      
           
            CSVReader csvReader = new CSVReader(filereader); 
            String[] nextRecord; 
            
            
            while ((nextRecord = csvReader.readNext()) != null) { 
            	 for (String cell : nextRecord) { 
            		 contents=cell+"\t";
            		 System.out.println(cell);
                 } 
                 
            } 
            csvReader.close();
        } 
        catch (Exception e) { 
            e.printStackTrace(); 
        } 
	}
	}