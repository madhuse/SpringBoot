package com.otsi.ApacheKafka;

import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.text.ParseException;
import java.util.ArrayList;
import java.util.List;
import java.util.Properties;

import org.apache.kafka.clients.consumer.ConsumerRecord;
import org.apache.kafka.clients.consumer.ConsumerRecords;
import org.apache.kafka.clients.consumer.KafkaConsumer;
import org.apache.kafka.common.TopicPartition;
import org.apache.kafka.common.errors.WakeupException;
import org.elasticsearch.action.index.IndexAction;
import org.elasticsearch.action.index.IndexRequest;
import org.elasticsearch.action.index.IndexRequestBuilder;
import org.elasticsearch.action.index.IndexResponse;
import org.elasticsearch.client.Client;
import org.elasticsearch.common.xcontent.XContentFactory;
import org.elasticsearch.common.xcontent.XContentType;
import org.json.JSONObject;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;

public class Pipeline {
	public static void main(String[] args) throws JsonProcessingException, IOException, ParseException {
		Client client = ESConnection.getConnection();

		Properties properties = new Properties();
		InputStream inputStream;
		inputStream = new FileInputStream("D:\\pdf workspace\\ApacheKafka\\src\\main\\java\\config.properties");
		properties.load(inputStream);
		properties.put("bootstrap.servers", properties.getProperty("kafkahost"));
		properties.put("key.deserializer", properties.getProperty("keydeserializer"));
		properties.put("value.deserializer", properties.getProperty("valuedeserializer"));
		properties.put("group.id", properties.getProperty("groupid"));
		properties.put("auto.offset.reset", properties.getProperty("autooffsetreset"));
		properties.put("enable.auto.commit", false);

		
		
		
		
		
		
		KafkaConsumer kafkaConsumer = new KafkaConsumer<String, String>(properties);
		// Map<String,List> m= (Map<String, List>) kafkaConsumer.listTopics().keySet();

		List topics = new ArrayList();
		// topics.add("FilebeatTopic");
		topics.add("parsing_task");
		kafkaConsumer.subscribe(topics);
		//https://towardsdatascience.com/kafka-python-explained-in-10-lines-of-code-800e3e07dad1
		
		System.out.println("hhhhhhhh");
		String type = "ots";
		try {
			while (true) {
				// System.out.println("......"+count++);
				ConsumerRecords<String, JsonNode> records = kafkaConsumer.poll(100);
				System.out.println("count" + records.count());
				/*if(records.count()<1) {
					kafkaConsumer.unsubscribe();
				}*/
				// BulkRequestBuilder bulkRequest = client.prepareBulk();
				//TopicPartition p0 = new TopicPartition(topicName, 0);
				for (ConsumerRecord<String, JsonNode> record : records) {
					System.out.println("inside for");
					
					 System.out.println(record.value());
					 ObjectMapper objectMapper = new ObjectMapper();
						String stringifiedJson = objectMapper.writeValueAsString(record.value());
						IndexRequestBuilder indexRequestBuilder = new IndexRequestBuilder(client, IndexAction.INSTANCE);
						
								indexRequestBuilder.setSource(stringifiedJson,XContentType.JSON
								).setIndex("twitter")

										.setType("tweet");
                             IndexResponse response = indexRequestBuilder.execute().actionGet();
							 System.out.println(response);
							
							 
					}
				// kafkaConsumer.commitAsync();
				}
			} catch (WakeupException e) {
				// ignore for shutdown
			} finally {
				kafkaConsumer.close();
				kafkaConsumer.commitSync();
			}
			
		}
	}
