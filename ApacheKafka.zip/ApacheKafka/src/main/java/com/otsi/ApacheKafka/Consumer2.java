package com.otsi.ApacheKafka;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Properties;
import java.util.concurrent.ExecutionException;

import org.apache.kafka.clients.consumer.ConsumerRecord;
import org.apache.kafka.clients.consumer.ConsumerRecords;
import org.apache.kafka.clients.consumer.KafkaConsumer;
import org.apache.kafka.common.TopicPartition;
import org.apache.kafka.common.errors.WakeupException;

import com.fasterxml.jackson.core.JsonProcessingException;

public class Consumer2 
{
	public static void main(String[] args)  throws JsonProcessingException, ExecutionException, InterruptedException, IOException{
		
		Properties properties = new Properties();
		properties.put("bootstrap.servers", "localhost:9092");
		properties.put("key.deserializer", "org.apache.kafka.common.serialization.StringDeserializer");
		properties.put("value.deserializer", "org.apache.kafka.common.serialization.StringDeserializer");
		properties.put("group.id", "partition-group");
		properties.put("auto.offset.reset", "latest");
		KafkaConsumer kafkaConsumer = new KafkaConsumer<String, String>(properties);
		/* String topic = "partition";
	     TopicPartition partition0 = new TopicPartition(topic, 0);
	     TopicPartition partition1 = new TopicPartition(topic, 1);
	     kafkaConsumer.assign(Arrays.asList(partition0,partition1));
	     System.out.println(kafkaConsumer.assignment());*/
	 
		List topics = new ArrayList();
		// topics.add("FilebeatTopic");
		topics.add("partition");
		kafkaConsumer.subscribe(topics);
        int count=0;
		try {
			while (true) {
				//System.out.println("......"+count++);
				ConsumerRecords<String, String> records = kafkaConsumer.poll(100);
				
					
				
				
				for (ConsumerRecord<String, String> record : records) {
					System.out.printf("offset = %d, key = %s, value = %s%n", record.offset(), record.key(), record.value());
					
					System.out.println("Partiotion number"+record.partition());
					
				
				}
		
				}

		} catch (WakeupException e) {
			// ignore for shutdown
		} finally {
			kafkaConsumer.close();
		}
		}
}