package com.otsi.ApacheKafka;

import java.util.Date;

import lombok.Data;
import lombok.Getter;
import lombok.Setter;
@Data
@Setter
@Getter
public class JsonData
{
	
	
	
	private String payment_mode;
    private String item_name;
	private String location;
	private String amount;
}