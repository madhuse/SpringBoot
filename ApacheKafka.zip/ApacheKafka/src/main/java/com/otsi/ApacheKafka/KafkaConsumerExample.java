package com.otsi.ApacheKafka;

import java.io.IOException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Properties;
import java.util.Set;
import java.util.TimeZone;
import java.util.concurrent.ExecutionException;

import org.I0Itec.zkclient.ZkClient;
import org.apache.kafka.clients.consumer.ConsumerRecord;
import org.apache.kafka.clients.consumer.ConsumerRecords;
import org.apache.kafka.clients.consumer.KafkaConsumer;
import org.apache.kafka.common.errors.WakeupException;
import org.elasticsearch.action.bulk.BulkRequestBuilder;
import org.elasticsearch.action.bulk.BulkResponse;
import org.elasticsearch.action.index.IndexAction;
import org.elasticsearch.action.index.IndexRequestBuilder;
import org.elasticsearch.action.index.IndexResponse;
import org.elasticsearch.client.Client;
import org.elasticsearch.common.xcontent.XContentFactory;
import org.json.JSONObject;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.*;

import io.krakens.grok.api.Grok;
import io.krakens.grok.api.GrokCompiler;
import io.krakens.grok.api.Match;
import io.netty.handler.codec.http.HttpVersion;
import kafka.consumer.Consumer;
import kafka.consumer.ConsumerConfig;
import kafka.utils.ZkUtils;
import scala.concurrent.JavaConversions;
///https://stackoverflow.com/questions/40952714/filebeat-5-0-output-to-kafka-multiple-topics
public class KafkaConsumerExample {
	public static void main(String[] args) throws JsonProcessingException, ExecutionException, InterruptedException, IOException {
		Client client = ESConnection.getConnection();
		Properties properties = new Properties();
		properties.put("bootstrap.servers", "localhost:9092");
		properties.put("key.deserializer", "org.apache.kafka.common.serialization.StringDeserializer");
		properties.put("value.deserializer", "org.apache.kafka.common.serialization.StringDeserializer");
		properties.put("group.id", "test-group");
		properties.put("auto.offset.reset", "latest");
		KafkaConsumer kafkaConsumer = new KafkaConsumer<String, String>(properties);
		List topics = new ArrayList();
		// topics.add("FilebeatTopic");
		topics.add("kafkatest");
		kafkaConsumer.subscribe(topics);
        int count=0;
		try {
			while (true) {
				//System.out.println("......"+count++);
				ConsumerRecords<String, String> records = kafkaConsumer.poll(100);
				//if(!records.isEmpty()) {
				

				/*ZkClient zkClient = new ZkClient("zkHost:zkPort");
				List<String> topics2 = JavaConversions.asJavaList(ZkUtils.getAllTopics(zkClient));*/
				
				BulkRequestBuilder bulkRequest = client.prepareBulk();
				for (ConsumerRecord<String, String> record : records) {
					JSONObject jsonObj = new JSONObject(record.value());
					String message = (String) jsonObj.get("message");
					
					GrokCompiler grokCompiler = GrokCompiler.newInstance();
					grokCompiler.registerDefaultPatterns();

					/* Grok pattern to compile, here httpd logs */
					final Grok grok = grokCompiler.compile("%{HOSTNAME:clientip} - - \\[%{HTTPDATE:requestdate}\\] \"%{WORD:requestmethodtype} %{URIPATH:requesturl} %{USERNAME:protocal}/%{NUMBER:protocalversion}\" %{INT:responsecode} %{INT:responsetime}");

					/* Line of log to match */
					String log = message;

					Match gm = grok.match(message);
					final Map<String, Object> capture =  gm.capture();
					
					String clientip=(String) capture.get("clientip");
					String requestdate=(String) capture.get("requestdate");
					String requestmethodtype=(String) capture.get("requestmethodtype");
					String requesturl=(String) capture.get("requesturl");
					String protocal=(String) capture.get("protocal");
					String protocalversion=(String) capture.get("protocalversion");
					String responsecode=(String) capture.get("responsecode");
					String responsetime=(String) capture.get("responsetime");
					
					
					System.out.println("clientip"+clientip);
					System.out.println("requestdate"+requestdate);
					System.out.println("requestmethodtype"+requestmethodtype);
					System.out.println("requesturl"+requesturl);
					System.out.println("protocal"+protocal);
					System.out.println("protocalversion"+protocalversion);
					System.out.println("responsecode"+responsecode);
					System.out.println("responsetime"+responsetime);
					
					/*
					IndexRequestBuilder indexRequestBuilder=new IndexRequestBuilder(client, IndexAction.INSTANCE);
					try {
						indexRequestBuilder.setSource(XContentFactory.jsonBuilder()
						         .startObject()
						         
						         .field("Ipaddress",clientip)
						         .field("methodType", requestmethodtype)
						         .field("responseCode", responsecode)
						         .field("protocoal", protocal)
						         .field("date", requestdate)
						         .field("responsetime", responsetime)
						          .field("requesturl", requesturl)
						         .field("protocalversion", protocalversion)
						         .endObject()
						         
								   )
						.setIndex("kafkalogs")
						.setType("logs");
						
						
					} catch (IOException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
					indexRequestBuilder.execute().actionGet();
				
				*/
					
					bulkRequest.add(new IndexRequestBuilder(client, IndexAction.INSTANCE)
					        .setSource(XContentFactory.jsonBuilder()
							        .startObject()
					        		.field("Ipaddress",clientip)
							         .field("methodType", requestmethodtype)
							         .field("responseCode", responsecode)
							         .field("protocoal", protocal)
							         .field("date", requestdate)
							         .field("responsetime", responsetime)
							          .field("requesturl", requesturl)
							         .field("protocalversion", protocalversion)
							        
							         
					                    .endObject()
					                  )
					        .setIndex("kafkalogs")
					        .setType("logs")
					        );
					
				}// end of for loop
				
				bulkRequest.execute().actionGet();
				
			//}
			BulkResponse bulkResponse = bulkRequest.get();
			if (bulkResponse.hasFailures()) {
			    // process failures by iterating through each bulk response item
			}
			}
		//	}
		} catch (WakeupException e) {
			// ignore for shutdown
		} finally {
			kafkaConsumer.close();
		}

	} //main method
}  //class
