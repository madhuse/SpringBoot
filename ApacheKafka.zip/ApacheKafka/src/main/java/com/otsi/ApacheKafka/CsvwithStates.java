package com.otsi.ApacheKafka;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;
import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;

public class CsvwithStates {
public static void main(String[] args) throws Exception{
	
	String url1="Telanaga&key=AIzaSyBvwHBPcyxDRh0NA0l4Ih4eNuT0Ce_4dfw";
	URLEncoder.encode(url1, "UTF-8");
	url1=url1.replaceAll(" ", "%23");
	URL url = new URL(
            "https://maps.googleapis.com/maps/api/geocode/json?address="+url1);
        HttpURLConnection conn = (HttpURLConnection) url.openConnection();
        
        conn.setRequestMethod("GET");
        
        conn.setDoOutput(true);
        
        InputStreamReader in = new InputStreamReader(conn.getInputStream());
       String output=null;
        BufferedReader br = new BufferedReader(in);
        while ((output = br.readLine()) != null) {
        	System.out.println(output);
        	JSONParser parser = new JSONParser();
        	JSONObject json = (JSONObject) parser.parse(output);
            JSONArray arr=(JSONArray) json.get("results");
            JSONObject object = (JSONObject) arr.get(0);
            JSONObject tt= (JSONObject) object.get("geometry");
            JSONObject location=(JSONObject) tt.get("location");
            Double lng=(Double) location.get("lng");
            Double lat=(Double) location.get("lat");
            System.out.println(lng);
            System.out.println(lat);
        }
}}
