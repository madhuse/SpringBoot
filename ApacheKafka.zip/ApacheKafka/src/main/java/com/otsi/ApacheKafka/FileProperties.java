package com.otsi.ApacheKafka;

import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.LinkOption;
import java.nio.file.attribute.BasicFileAttributes;
import java.nio.file.attribute.FileOwnerAttributeView;
import java.nio.file.attribute.FileTime;
import java.nio.file.attribute.UserPrincipal;
import java.text.SimpleDateFormat;

import org.apache.commons.io.FilenameUtils;
import org.apache.pdfbox.pdmodel.PDDocument;
import org.apache.pdfbox.text.PDFTextStripper;



public class FileProperties {
	public static void main(String[] args) throws IOException{
		
	
	File f=new File("C:\\Users\\madhu.akula\\Desktop\\myprojects.txt");

	
	BasicFileAttributes attr = Files.readAttributes(f.toPath(), BasicFileAttributes.class, LinkOption.values());
    FileTime lastmodified = attr.lastModifiedTime();
    FileTime creationTime = attr.creationTime();
    SimpleDateFormat sdf = new SimpleDateFormat("EEE MMM dd HH:mm:ss +0530 yyyy");
    String modifiedDate = sdf.format(Long.valueOf(lastmodified.toMillis()));
    System.out.println("modifiedDate"+modifiedDate);
    String createdDate = sdf.format(Long.valueOf(creationTime.toMillis()));
    System.out.println("createdDate"+createdDate);
    String fileExtension = FilenameUtils.getExtension(f.getName());
    System.out.println("fileExtension"+fileExtension);
    FileOwnerAttributeView foav = Files.getFileAttributeView(f.toPath(),
            FileOwnerAttributeView.class);

        UserPrincipal owner = foav.getOwner();
       // System.out.format("owner of file"+owner.getName());
        if(fileExtension.equals("txt")) {
        	System.out.println("text file was uploaded");
        	
        }
        
        File file = new File(filepath);
  	  try {
        PDDocument document = PDDocument.load(file);

        //Instantiate PDFTextStripper class
        PDFTextStripper pdfStripper = new PDFTextStripper();
        pdfStripper.setSortByPosition(true);
        //Retrieving text from PDF document
        fileContents = pdfStripper.getText(document);
        //System.out.println(text);

        //Closing the document
        document.close();
  	  }catch(Exception e) {
  		  System.out.println("error while reading the pdf file");
  	  }
}}
