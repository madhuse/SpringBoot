package com.otsi.ApacheKafka;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.util.Iterator;

import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

import com.fasterxml.jackson.core.JsonProcessingException;

public class Consumer1 
{
	public static void main(String[] args)  throws JsonProcessingException, InterruptedException, IOException{
		
		FileInputStream fis=new FileInputStream(new File("C:\\POLING DATA\\EG\\AC035\\excel files\\S01A035P001.PDF.xls"));  
		 
		HSSFWorkbook wb=new HSSFWorkbook(fis);   
		
		HSSFSheet sheet=wb.getSheetAt(0);  
		String contents="";
		for(Row row: sheet){  
		for(Cell cell: row)    //iteration over cell using for each loop  
			{ 
			contents+=","+cell.toString();
		}  
			contents += "\n" ;
		}
		
		System.out.println(contents);
		/*String contents=null;
		
		File file = new File("C:\\Users\\madhu.akula\\Desktop\\Book1.xlsx");   //creating a new file instance  
		FileInputStream fis = new FileInputStream(file);   //obtaining bytes from the file  
		//creating Workbook instance that refers to .xlsx file  
		XSSFWorkbook wb = new XSSFWorkbook(fis);   
		XSSFSheet sheet = wb.getSheetAt(0);     //creating a Sheet object to retrieve object  
		Iterator<Row> itr = sheet.iterator();    //iterating over excel file  
		while (itr.hasNext())                 
		{  
		Row row = itr.next(); 
		
		Iterator<Cell> cellIterator = row.cellIterator();   //iterating over each column  
		while (cellIterator.hasNext())   
		{  
		Cell cell = cellIterator.next();  
		contents=cell.toString();
		System.out.println(contents);
		}  
		//System.out.println("");  
		}  */
		
		
		
		}
}