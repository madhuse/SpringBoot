package com.otsi.ApacheKafka;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Properties;
import java.util.concurrent.ExecutionException;

import org.apache.kafka.clients.consumer.ConsumerRecord;
import org.apache.kafka.clients.consumer.ConsumerRecords;
import org.apache.kafka.clients.consumer.KafkaConsumer;
import org.apache.kafka.common.errors.WakeupException;
import org.elasticsearch.action.index.IndexAction;
import org.elasticsearch.action.index.IndexRequestBuilder;
import org.elasticsearch.action.index.IndexResponse;
import org.elasticsearch.client.Client;
import org.elasticsearch.common.xcontent.XContentFactory;
import org.elasticsearch.common.xcontent.XContentType;
import org.json.JSONObject;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.opencsv.CSVReader;

import java.io.FileReader;
import java.io.IOException;
///https://stackoverflow.com/questions/40952714/filebeat-5-0-output-to-kafka-multiple-topics
public class WinlogBeat {
	public static void main(String[] args)  throws InterruptedException{
		Client client = ESConnection.getConnection();
		String csvFile = "C:\\Users\\madhu.akula\\Desktop\\log files\\simulate2.csv";

        CSVReader reader = null;
        try {
            reader = new CSVReader(new FileReader(csvFile));
            String[] line;
            JsonData jsondata=new JsonData();
            int i = 0;
            while ((line = reader.readNext()) != null) {
               // System.out.println("Country [id= " + line[0] + ", code= " + line[1] + " , name=" + line[2] + "]");
             System.out.println(i);
             if(i!= 0) {
            	if(i%10 != 0) {
            	jsondata.setCust_id(Long.parseLong(line[0]));
                jsondata.setMobile_number(line[1]);
                jsondata.setItem_count(Integer.parseInt(line[2]));
                jsondata.setBill_amount(Double.parseDouble(line[3]));
                jsondata.setBilling_time(Long.parseLong(line[4]));
                jsondata.setDiscount(Double.parseDouble(line[5]));
                jsondata.setPayment_mode(line[6]);
                jsondata.setRating(Integer.parseInt(line[7]));
                
                jsondata.setTimestamp(line[8]);
                jsondata.setGeo_points(line[9]);
                jsondata.setLocation(line[10]);
                System.out.println(jsondata);
                
                IndexRequestBuilder indexRequestBuilder=new IndexRequestBuilder(client, IndexAction.INSTANCE);
				try {
					indexRequestBuilder.setSource(XContentFactory.jsonBuilder()
					         .startObject()
					         
					         .field("cust_id",jsondata.getCust_id())
						         .field("mobile_number", jsondata.getMobile_number())
						         .field("Item_count", jsondata.getItem_count())
						         .field("bill_amount", jsondata.getBill_amount())
						         .field("billing_time", jsondata.getBilling_time())
						         .field("discount", jsondata.getDiscount())
						         .field("rating", jsondata.getRating())
						         .field("payment_mode", jsondata.getPayment_mode())
						         .field("geo_points", jsondata.getGeo_points())
						         .field("location", jsondata.getLocation())
						         
					         .endObject()
					         
							   )
					.setIndex("demouser-easy_retail_data")
					
					.setType("demouser-easy_retail_data");
					
					
				} catch (IOException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				indexRequestBuilder.execute().actionGet();
			
            }else {
            	 Thread.sleep(60000);

            }
             }
               i++;
                               
            }
            
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

}